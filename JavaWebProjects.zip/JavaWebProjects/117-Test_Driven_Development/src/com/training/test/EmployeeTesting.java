package com.training.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.training.model.Employee;

public class EmployeeTesting {
	Employee employee;
	
	@BeforeEach
	public void setup() {
		employee = new Employee();
	}
	
	@AfterEach
	public void tearDown() {
		employee = null;
	}
	
	@Test
	@DisplayName("A Grade Employee Testing")
	public void testAGradeEmp() {
		employee.setGrade('A');
		int expected = 40;
		int actual = employee.incentivePercentage();
		assertEquals(expected, actual);
	}
	
	@Test
	@DisplayName("B Grade Employee Testing")
	public void testBGradeEmp() {
		employee.setGrade('B');
		int expected = 30;
		int actual = employee.incentivePercentage();
		assertEquals(expected, actual);
	}
	
	@Test
	@DisplayName("C Grade Employee Testing")
	public void testCGradeEmp() {
		employee.setGrade('C');
		int expected = 20;
		int actual = employee.incentivePercentage();
		assertEquals(expected, actual);
	}
	
	@Test
	@DisplayName("D Grade Employee Testing")
	public void testDGradeEmp() {
		employee.setGrade('D');
		int expected = 10;
		int actual = employee.incentivePercentage();
		assertEquals(expected, actual);
	}
}
