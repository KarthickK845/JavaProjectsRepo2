package com.training.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.training.model.Course;

public class CourseTesting {
	Course course;
	
	@BeforeEach
	public void setup() {
		course = new Course();
	}
	
	@AfterEach
	public void tearDown() {
		course = null;
	}
	
	//test getCourseItemsCount()
	@Test
	@DisplayName("Testing Course Items Count")
	public void testGetCourseItemsCount() {
		course.setCourseCode("101A");
		course.setCourseName("Web Developer Course");
		course.addCourseItem("HTML", 20, 1000.00);
		course.addCourseItem("CSS", 10, 700.00);
		course.addCourseItem("JAVA", 50, 9000.00);
		int expected = 3;
		int actual = course.getCourseItemsCount();
		assertEquals(expected, actual);	
	}
	
	//test getCourseTotalDuration()
	@Test
	@DisplayName("Testing Course Total Duration")
	public void testGetCourseTotalDuration() {
		course.setCourseCode("101A");
		course.setCourseName("Web Developer Course");
		course.addCourseItem("HTML", 20, 1000.00);
		course.addCourseItem("CSS", 10, 700.00);
		course.addCourseItem("JAVA", 50, 9000.00);
		int expected = 80;
		int actual = course.getCourseTotalDuration();
		assertEquals(expected, actual);	
	}
	
	//test getTotalFees()
	@Test
	@DisplayName("Testing Course Total Fees")
	public void testGetCourseTotalFees() {
		course.setCourseCode("101A");
		course.setCourseName("Web Developer Course");
		course.addCourseItem("HTML", 20, 1000.00);
		course.addCourseItem("CSS", 10, 700.00);
		course.addCourseItem("JAVA", 50, 9000.00);
		double expected = 10700.00;
		double actual = course.getTotalFees();
		assertEquals(expected, actual);	
	}
	
	
}
