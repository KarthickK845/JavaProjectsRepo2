package com.training.model;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class Course {
	String courseCode;
	String courseName;
	Set<CourseItem> courseItems = new HashSet<>();
	public String getCourseCode() {
		return courseCode;
	}
	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	
	public int getCourseItemsCount() {
		return this.courseItems.size();
	}
	
	public void addCourseItem(String courseItemName, int duration, double fees) {
		CourseItem item = new CourseItem(courseItemName, duration, fees);
		this.courseItems.add(item);
	}
	
	public int getCourseTotalDuration() {
		return this.courseItems.stream().map(ci -> ci.getDuration()).reduce(0, (d1,d2)->d1+d2);
		//return this.courseItems.stream().mapToInt(ci-> ci.getDuration()).sum();
	}
	
	public double getTotalFees() {
		return this.courseItems.stream().collect(Collectors.summingDouble(ci->ci.getFees()));
	}
}
