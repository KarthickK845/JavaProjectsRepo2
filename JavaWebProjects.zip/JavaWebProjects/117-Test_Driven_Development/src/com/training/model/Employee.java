package com.training.model;

public class Employee {
	char grade;

	public char getGrade() {
		return grade;
	}

	public void setGrade(char grade) {
		this.grade = grade;
	}

	public int incentivePercentage() {
		// A Grade - 40%
		// B Grade - 30%
		// C Grade - 20%
		// D Grade - 10%

		if (grade == 'A')
			return 40;
		else if (grade == 'B')
			return 30;
		else if (grade == 'C')
			return 20;
		else
			return 10;

	}
}
