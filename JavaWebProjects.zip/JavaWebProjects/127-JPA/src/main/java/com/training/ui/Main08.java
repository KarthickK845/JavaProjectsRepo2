package com.training.ui;

import java.time.LocalDate;
import java.util.List;

import com.training.model.Bill;
import com.training.model.BillItem;
import com.training.model.Category;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main08 {
	
	private static void insert() {
//		Bill bill = new Bill("Keerthi", LocalDate.of(2024, 12, 10));
//		BillItem billItem1 = new BillItem(1, "DELL", 2, 40000.00);
//		BillItem billItem2 = new BillItem(2, "IPhone", 1, 80000.00);
//		BillItem billItem3 = new BillItem(3, "Logitech Mouse", 10, 400.00);
//		bill.addBillItem(billItem1);
//		bill.addBillItem(billItem2);
//		bill.addBillItem(billItem3);
		
		Bill bill1 = new Bill("Malathi", LocalDate.of(2023, 02, 14));
		BillItem billItemb1 = new BillItem(1, "Zebronics Mouse", 2, 400.00);
		BillItem billItemb2 = new BillItem(2, "BOAT earpods", 2, 2000.00);
		bill1.addBillItem(billItemb1);
		bill1.addBillItem(billItemb2);
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(bill1);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}

	private static void read() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Bill bill = em.find(Bill.class, 1);
		System.out.println(bill);
		
		em.close();
		emf.close();
	}
	
	private static void readAll() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		String qry = "from Bill";
		Query query = em.createQuery(qry);
		List<Bill> bills = query.getResultList();
		System.out.println(bills);
		
		em.close();
		emf.close();
	}
	
	private static void update() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Bill bill = em.find(Bill.class, 1);
		
		bill.getBillItems().remove(0);
		bill.addBillItem(new BillItem(1, "SONY", 2, 50000.00));
		
		em.getTransaction().begin();
		em.merge(bill);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void delete() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Bill bill = em.find(Bill.class, 2);
		
		em.getTransaction().begin();
		em.remove(bill);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	public static void main(String[] args) {
		//insert();
		//read();
		//update();
		readAll();
		//delete();
		
	}

}
