package com.training.ui;

import java.util.List;

import com.training.model.Book;
import com.training.model.Category;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main07 {
	
	private static void insert() {
//		Category category = new Category("Web Technologies");
//		category.add("HTML");
//		category.add("CSS");
//		category.add("JS");
//		category.add("Angular");
//		category.add("React");
		//insertion order is not followed
		
		Category category = new Category("DevOps");
		category.add("CI/CD");
		category.add("Docker");
		category.add("Kubernetes");
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(category);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void update() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Category category = em.find(Category.class, 1);
		category.remove("HTML");
		category.add("Type Script");
		category.add("BootStrap");
		
		em.getTransaction().begin();
		em.merge(category);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void read() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Category category = em.find(Category.class, 1);
		System.out.println(category);
		
		em.close();
		emf.close();
	}
	
	private static void readAll() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		String qry = "from Category";
		Query query = em.createQuery(qry);
		List<Category> categories = query.getResultList();
		System.out.println(categories);
		
		em.close();
		emf.close();
	}
	
	private static void delete() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Category category = em.find(Category.class, 2);
		
		em.getTransaction().begin();
		em.remove(category);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}

	public static void main(String[] args) {
		//insert();
		//update();
		//read();
		//readAll();
		delete();
	}

}
