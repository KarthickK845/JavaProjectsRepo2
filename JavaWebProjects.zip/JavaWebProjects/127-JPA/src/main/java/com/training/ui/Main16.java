package com.training.ui;

import java.util.List;

import com.training.model.Loan;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

//Test NAMED Queries
public class Main16 {
	
	// test Named Query - Find All Loans
	private static void test1() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();

		Query query = em.createNamedQuery("findAllLoans");
		List<Loan> allLoans = query.getResultList();
		System.out.println(allLoans);

		em.close();
		emf.close();
	}

	// test Named Query - Find Loan By Id
	private static void test2() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();

		Query query = em.createNamedQuery("findLoanById");
		query.setParameter("searchId", 2);

		Loan loan = (Loan) query.getSingleResult();
		System.out.println(loan);

		em.close();
		emf.close();
	}

	// test Named Query - Update Tenure
	private static void test3() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();

		Query query = em.createNamedQuery("updateTenure");

		em.getTransaction().begin();
		int r = query.executeUpdate();
		em.getTransaction().commit();

		System.out.println(r + " records updated");

		em.close();
		emf.close();
	}

	// test Named Query - delete loan Based On Loan Amount
	private static void test4() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();

		Query query = em.createNamedQuery("deleteBasedOnLoanAmount");
		query.setParameter("amount", 100000);
		
		em.getTransaction().begin();
		int r = query.executeUpdate();
		em.getTransaction().commit();

		System.out.println(r + " records deleted");

		em.close();
		emf.close();
	}

	public static void main(String[] args) {
		test4();

	}

}
