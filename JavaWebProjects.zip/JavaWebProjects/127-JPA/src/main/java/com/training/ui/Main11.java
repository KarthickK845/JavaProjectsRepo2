package com.training.ui;

import java.time.LocalDate;

import com.training.model.Doctor;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main11 {

	public static void main(String[] args) {
		Doctor doctor1 = new Doctor("Santosh",500,"MALE",LocalDate.of(2006, 12, 15));
		Doctor doctor2 = new Doctor("Abhi",1000,"FEMALE",LocalDate.of(1998, 5, 24));
		Doctor doctor3 = new Doctor("Sheela", 800, "FEMALE",LocalDate.of(1995, 3, 6));
		Doctor doctor4 = new Doctor("Mala",400,"FEMALE",LocalDate.of(2000, 7, 27));
		Doctor doctor5 = new Doctor("Gopal", 700, "MALE",LocalDate.of(2007, 2, 10));
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		em.persist(doctor1);
		em.persist(doctor2);
		em.persist(doctor3);
		em.persist(doctor4);
		em.persist(doctor5);
		
		em.getTransaction().commit();
		
		em.close();
		emf.close();

	}

}
