package com.training.ui;

import java.util.List;
import java.util.Set;

import com.training.model.Course;
import com.training.model.Subject;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main10 {
	
	private static void insert() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
//		Course course = new Course("Diploma in Web Technologies", 40000.00);
//		Subject subject1 = new Subject("HTML",40);
//		Subject subject2 = new Subject("CSS",20);
//		Subject subject3 = new Subject("Java Script",50);
//		Subject subject4 = new Subject("React",60);
		
//		course.addSubject(subject1);
//		course.addSubject(subject2);
//		course.addSubject(subject3);
//		course.addSubject(subject4);
		
		Course course1 = new Course("Diploma in Mobile App Development", 50000.00);
		Subject subject5 = new Subject("Java",90);
		Subject subject6 = new Subject("UI/UX Design",50);
		
		course1.addSubject(subject5);
		course1.addSubject(subject6);

		em.getTransaction().begin();
		em.persist(course1);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}

	private static void read() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Course course = 
				em.find(Course.class, 1);
		System.out.println(course);
		
		em.close();
		emf.close();
	}
	
	private static void update() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Course course = em.find(Course.class, 1);
		course.addSubject(new Subject("Angular",40));
		
		Subject subject = new Subject();
		Set<Subject> subjects= course.getSubjects();
		
		for(Subject s:subjects) {
			if(s.getSubjectId()==3)
				subject = s;
		}
		
		course.removeSubject(subject);
		
		em.getTransaction().begin();
		em.merge(course);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
		
	}
	
	private static void delete() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Course course = em.find(Course.class, 2);
		
		em.getTransaction().begin();
		em.remove(course);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void readAll() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		String qry = "from Course";
		Query query = em.createQuery(qry);
		List<Course> courses = query.getResultList();
		System.out.println(courses);
		
		em.close();
		emf.close();
		
	}
	
	public static void main(String[] args) {
	read();
	}

}
