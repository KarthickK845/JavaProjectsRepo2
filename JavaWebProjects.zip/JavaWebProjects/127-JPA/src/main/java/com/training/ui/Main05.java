package com.training.ui;

import java.util.List;

import com.training.model.Address;
import com.training.model.Employee;
import com.training.model.Player;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main05 {

	private static void insert() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Address address = new Address("D-20", "Saligramam", "Chennai", "600110");
		Employee employee = new Employee("Rani", address, 7000.00);
		
		em.getTransaction().begin();
		em.persist(employee);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void update() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Employee employee = em.find(Employee.class, 2);
		employee.getAddress().setDoorNo("A-23");
		employee.setBasicSalary(12120);
		
		em.getTransaction().begin();
		em.merge(employee);
		em.getTransaction().commit();
		
		em.close();
		emf.close();	
		
	}
	
	private static void read() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Employee employee = em.find(Employee.class, 3);
		System.out.println(employee);
		
		em.close();
		emf.close();
	}
	
	private static void readAll() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		String qry = "from Employee";
		Query query = em.createQuery(qry);
		List<Employee> employees = query.getResultList();
		System.out.println(employees);
		
		em.close();
		emf.close();
	}
	
	private static void delete() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Employee employee = em.find(Employee.class, 3);
		
		
		em.getTransaction().begin();
		em.remove(employee);
		em.getTransaction().commit();
		
		em.close();
		emf.close();	
		
	}
	
	public static void main(String[] args) {
		//insert();
		//read();
		readAll();
		//update();
		//delete();
	}

}
