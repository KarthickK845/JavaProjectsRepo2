package com.training.ui;

import java.util.List;

import com.training.model.Player;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main02 {
	//CRUD for Player
	private static void insert() {
		Player player = new Player(205,"Smith","All-Rounder",38,1);
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(player);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void read() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Player player = em.find(Player.class, 202);
		System.out.println(player);
		
		em.close();
		emf.close();
	}
	
	private static void update() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Player player = em.find(Player.class, 201);
		player.setTypeOfPlayer("Bowler");
		
		em.getTransaction().begin();
		em.merge(player);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void readAll() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		String qry = "from Player";
		Query query = em.createQuery(qry);
		List<Player> players = query.getResultList();
		System.out.println(players);
		
		em.close();
		emf.close();
	}

	private static void delete() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Player player = em.find(Player.class, 203);
		
		em.getTransaction().begin();
		em.remove(player);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	public static void main(String[] args) {
		//insert();
		//read();
		readAll();
		//update();
		//delete();
	}

}
