package com.training.ui;

import java.util.List;

import com.training.model.Loan;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

//Test NATIVE Queries
public class Main15 {

	// insert records
	private static void test1() {

		Loan loan1 = new Loan("Mahesh", 100000, 12);
		Loan loan2 = new Loan("Suresh", 500000, 6);
		Loan loan3 = new Loan("John", 190000, 18);
		Loan loan4 = new Loan("George", 200000, 15);
		Loan loan5 = new Loan("Kutty", 700000, 24);

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();

		em.persist(loan1);
		em.persist(loan2);
		em.persist(loan3);
		em.persist(loan4);
		em.persist(loan5);

		em.getTransaction().commit();

		em.close();
		emf.close();

	}

	// test Native query
	// find All Records
	private static void test2() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();

		String nsql = "select * from loans";
		Query query = em.createNativeQuery(nsql, Loan.class);
		List<Loan> results = query.getResultList();

		System.out.println(results);

		em.close();
		emf.close();
	}

	// test Native query
	// find only customerName, loanAmount
	private static void test3() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();

		String nsql = "select customerName, loanAmount from loans";
		Query query = em.createNativeQuery(nsql);

		List<Object[]> results = query.getResultList();

		for (Object[] cols : results) {
			System.out.println(cols[0] + "\t\t" + cols[1]);
		}

		em.close();
		emf.close();
	}

	// test Native query
	// update loanAmount
	private static void test4() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		String qry = "update loans set loanAmount=loanAmount+3000 where id=3";
		
		
		Query query = em.createNativeQuery(qry);
		em.getTransaction().begin();
		int r = query.executeUpdate();
		em.getTransaction().commit();

		System.out.println(r + " records updated");
		
		em.close();
		emf.close();
	}

	public static void main(String[] args) {
		test4();
	}

}
