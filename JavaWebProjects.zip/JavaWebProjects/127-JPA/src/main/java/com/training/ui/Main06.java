package com.training.ui;

import java.util.List;

import com.training.model.Book;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main06 {
	private static void insert() {
		Book book = new Book("SCJP", "Kathy Sierra");
		book.addTopic("Java Introduction");
		book.addTopic("OOPS Introduction");
		book.addTopic("Multi Threading");
		book.addTopic("Collection API");
		
//		Book book = new Book("C Programming", "Balaguru");
//		book.addTopic("C Introduction");
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(book);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void read() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Book book = em.find(Book.class, 1);
		System.out.println(book);
		
		em.close();
		emf.close();
	}
	
	private static void readAll() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		String qry = "from Book";
		Query query = em.createQuery(qry);
		List<Book> books = query.getResultList();
		System.out.println(books);
		
		em.close();
		emf.close();
	}
	
	private static void update() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Book book = em.find(Book.class, 2);
		//book.setBookName("Sun Certified Java Prog");
		book.getTopics().add(1, "C Features");
		
		em.getTransaction().begin();
		em.merge(book);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}

	private static void delete() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		
		Book book = em.find(Book.class, 1);
		
		em.getTransaction().begin();
		em.remove(book);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	public static void main(String[] args) {
		//insert();
		//read();
		readAll();
		//update();
		//delete();
	}

}
