package com.training.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class BillItem {
	
	@Column
	int slno;  //not using @Id as BillITem is not an Entity, its an Embeddable
	
	@Column
	String itemName;
	
	@Column
	int quantity;
	
	@Column
	double price;

	public BillItem(int slno, String itemName, int quantity, double price) {
		super();
		this.slno = slno;
		this.itemName = itemName;
		this.quantity = quantity;
		this.price = price;
	}

	public BillItem() {
		super();
	}

	public int getSlno() {
		return slno;
	}

	public void setSlno(int slno) {
		this.slno = slno;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "\nBillItem [slno=" + slno + ", itemName=" + itemName + ", quantity=" + quantity + ", price=" + price
				+ "]";
	}
	
	
}
