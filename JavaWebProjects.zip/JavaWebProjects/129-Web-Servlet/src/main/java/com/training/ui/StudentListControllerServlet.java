package com.training.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.training.model.Student;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class StudentListControllerServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Student student1 = new Student(1088, "Ramesh", "Male", 90, 80);
		Student student2 = new Student(1089,"Saritha","Female",67,79);
		Student student3 = new Student(1090,"Mahesh","Male",98,100);
		Student student4 = new Student(1091,"Sumesh","Male",59,89);
		Student student5 = new Student(1092,"Kartikeyan","Male",100,100);
		
		List<Student> students = new ArrayList<>();
		students.add(student1);
		students.add(student2);
		students.add(student3);
		students.add(student4);
		students.add(student5);
		
		request.setAttribute("studs", students);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("StudentList.jsp");
		dispatcher.forward(request, response);
	}

}
