package com.training.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Main08 {

	public static void main(String[] args) {
		// Step 1
		// Load a Driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Loaded Successfully");
		} catch (ClassNotFoundException e) {
			System.err.println(e);
		}

		// Step 2
		// Establish a connection to a database
		Connection connection = null;
		String dburl = "jdbc:mysql://localhost:3306/trainingdb19?useSSL=false";
		String userName = "root";
		String password = "root";

		try {
			connection = DriverManager.getConnection(dburl, userName, password);
			System.out.println("Connected to Database");
		} catch (SQLException e) {
			System.err.println(e);
		}

		// Step 3
		// Execute Queries
		String query = "delete from products where pid=?";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			System.out.println("Statement Created Successfully");
			Scanner scanner = new Scanner(System.in);

			int pid;

			System.out.print("Enter ID to Delete : ");
			pid = Integer.parseInt(scanner.nextLine());

			// fill the parameters
			statement.setInt(1, pid);

			int r = statement.executeUpdate();
			System.out.println(r + " row(s) deleted");

		} catch (SQLException e) {
			System.err.println(e);
		}

		// Step 4
		// Close the connection
		try {
			connection.close();
			System.out.println("Connection closed successfully");
		} catch (SQLException e) {
			System.err.println(e);
		}

	}

}
