package com.training.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Main02 {

	public static void main(String[] args) {
		// Step 1
		// Load a Driver

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			// Class.forName("java.lang.String"); //to load any class structure into memory
			System.out.println("Driver Loaded Successfully");
		} catch (ClassNotFoundException e) {
			System.err.println(e);
		}

		// Step 2
		// Establish a connection to a database
		Connection connection = null;
		String dburl = "jdbc:mysql://localhost:3306/trainingdb19?useSSL=false";
		String userName = "root";
		String password = "root";

		try {
			connection = DriverManager.getConnection(dburl, userName, password);
			System.out.println("Connected to Database");
		} catch (SQLException e) {
			System.err.println(e);
		}

		// Step 3
		// Execute Queries
		String query = "update products set pprice=60000.00 where pid = 1002";
		try {
			Statement statement = connection.createStatement();
			System.out.println("Statement Created Successfully");
			int r = statement.executeUpdate(query); // call this method whenever we need to insert records/update the table
			System.out.println(r + " row(s) updated");
		} catch (SQLException e) {
			System.err.println(e);
		}

		// Step 4
		// Close the connection
		try {
			connection.close();
			System.out.println("Connection closed successfully");
		} catch (SQLException e) {
			System.err.println(e);
		}
	}

}
