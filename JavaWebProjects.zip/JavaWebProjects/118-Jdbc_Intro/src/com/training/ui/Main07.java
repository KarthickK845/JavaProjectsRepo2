package com.training.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Main07 {

	public static void main(String[] args) {
		// Step 1
		// Load a Driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Loaded Successfully");
		} catch (ClassNotFoundException e) {
			System.err.println(e);
		}

		// Step 2
		// Establish a connection to a database
		Connection connection = null;
		String dburl = "jdbc:mysql://localhost:3306/trainingdb19?useSSL=false";
		String userName = "root";
		String password = "root";

		try {
			connection = DriverManager.getConnection(dburl, userName, password);
			System.out.println("Connected to Database");
		} catch (SQLException e) {
			System.err.println(e);
		}

		// Step 3
		// Execute Queries
		String query = "update products set pname=?, pprice=?, pcategory=? where pid=?";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			System.out.println("Statement Created Successfully");

			Scanner scanner = new Scanner(System.in);

			int pid;
			String pname;
			double price;
			String category;

			System.out.print("Enter ID to Update : ");
			pid = Integer.parseInt(scanner.nextLine());

			System.out.println("Enter Name : ");
			pname = scanner.nextLine();

			System.out.println("Enter Price : ");
			price = Double.parseDouble(scanner.nextLine());

			System.out.println("Enter Category : ");
			category = scanner.nextLine();

			// fill the parameters
			statement.setString(1, pname);
			statement.setDouble(2, price);
			statement.setString(3, category);
			statement.setInt(4, pid);

			int r = statement.executeUpdate();
			System.out.println(r + " row(s) updated");

		} catch (SQLException e) {
			System.err.println(e);
		}

		// Step 4
		// Close the connection
		try {
			connection.close();
			System.out.println("Connection closed successfully");
		} catch (SQLException e) {
			System.err.println(e);
		}

	}

}
