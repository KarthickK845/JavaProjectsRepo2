package com.training.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main05 {

	public static void main(String[] args) {
		// Step 1
		// Load a Driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Loaded Successfully");
		} catch (ClassNotFoundException e) {
			System.err.println(e);
		}

		// Step 2
		// Establish a connection to a database
		Connection connection = null;
		String dburl = "jdbc:mysql://localhost:3306/trainingdb19?useSSL=false";
		String userName = "root";
		String password = "root";

		try {
			connection = DriverManager.getConnection(dburl, userName, password);
			System.out.println("Connected to Database");
		} catch (SQLException e) {
			System.err.println(e);
		}

		// Step 3
		// Execute Queries
		String query = "select * from products where pid=1002";
		try {
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(query);
			if(rs.next()) {
			int pid=rs.getInt(1);
			String pname=rs.getString(2);
			double price=rs.getDouble(3);
			String category=rs.getString(4);
			System.out.printf("%d %-20s %10.2f %-20s \n",
					pid,
					pname,
					price,
					category);
			}
			else {
				System.out.println("Record Not found !!!");
			}
			rs.close();
		} catch (SQLException e) {
			System.err.println(e);
		}

		// Step 4
		// Close the connection
		try {
			connection.close();
			System.out.println("Connection closed successfully");
		} catch (SQLException e) {
			System.err.println(e);
		}
	}

}
