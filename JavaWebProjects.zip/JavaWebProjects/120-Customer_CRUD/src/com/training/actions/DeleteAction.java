package com.training.actions;

import com.training.service.CustomerService;
import com.training.service.CustomerServiceImpl;
import com.training.ui.util.ConsoleIO;

public class DeleteAction extends Action{
	boolean status;
	
	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Delete customer");
		System.out.println("\t\t -----------------------");
	}

	@Override
	public void execute() {
		int idToDelete;
		
		ConsoleIO.prompt("Enter ID To Delete ");
		idToDelete = ConsoleIO.intInput();
		
		CustomerService service=new CustomerServiceImpl();
		status=service.deleteCustomer(idToDelete);
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		if(status==true)
			System.out.println("\t\t Deleting customer Completed Successfully.");
		else
			System.out.println("\t\t Deleting customer Failed.");
		System.out.println("\n\n");
	}
}
