package com.training.actions;

import com.training.model.Customer;
import com.training.service.CustomerService;
import com.training.service.CustomerServiceImpl;
import com.training.ui.util.ConsoleIO;

public class AddAction extends Action {
	
	boolean status;

	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Add New Customer");
		System.out.println("\t\t -----------------------");
	}

	@Override
	public void execute() {
		int id;
		String name;
		double balance;
		String email,phone;
		
		try {
			ConsoleIO.prompt("Enter Customer ID");
			id = ConsoleIO.intInput();
			if (id < 0)
				throw new Exception("Customer ID cannot be negative");

			ConsoleIO.prompt("Enter Name ");
			name = ConsoleIO.stringInput();
			if (name.equals("") || name.equals(null))
				throw new Exception("Name cannot be Empty or NULL");

			ConsoleIO.prompt("Enter Balance ");
			balance = ConsoleIO.doubleInput();
			if (balance <= 0.0)
				throw new Exception("Balance cannot be negative or zero");

			ConsoleIO.prompt("Enter Email ");
			email = ConsoleIO.stringInput();
			if (email.equals("") || email.equals(null))
				throw new Exception("Email cannot be Empty or NULL");

			ConsoleIO.prompt("Enter Phone ");
			phone = ConsoleIO.stringInput();
			if (phone.equals("") || phone.equals(null))
				throw new Exception("Phone cannot be Empty or NULL");

			Customer customer = new Customer(id, name, balance, email, phone);
			CustomerService service = new CustomerServiceImpl();
			status=service.addCustomer(customer);
			
			
			
		} catch (Exception e) {
			System.err.println("\t\t "+e.getMessage());
			execute();
		}
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		if(status==true)
			System.out.println("\t\t Adding customer Completed Successfully");
		else
			System.out.println("\t\t Adding customer Failed");
		System.out.println("\n\n");
	}

}
