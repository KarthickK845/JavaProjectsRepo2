package com.training.actions;

import com.training.model.Customer;
import com.training.service.CustomerService;
import com.training.service.CustomerServiceImpl;
import com.training.ui.util.ConsoleIO;

public class SearchAction extends Action{

	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Search Customer");
		System.out.println("\t\t -----------------------");
	}

	@Override
	public void execute() {
		int searchId;
		
		ConsoleIO.prompt("Enter Customer ID to search ");
		searchId=ConsoleIO.intInput();
		
		CustomerService service = new CustomerServiceImpl();
		Customer customer = service.searchCustomer(searchId);
		if(customer != null) {
			System.out.println("\t\t Customer ID : "+customer.getId());
			System.out.println("\t\t Name        : "+customer.getName());
			System.out.println("\t\t Balance     : "+customer.getBalance());
			System.out.println("\t\t Email       : "+customer.getEmail());
			System.out.println("\t\t Phone       : "+customer.getPhone());
		}
		else {
			System.out.println("\n\n\t\t Customer Not Found !!!");
		}
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		System.out.println("\t\t Searching Customer Completed.");
		System.out.println("\n\n");
	}

}
