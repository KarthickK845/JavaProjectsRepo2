package com.training.actions;

import java.util.List;

import com.training.model.Customer;
import com.training.service.CustomerService;
import com.training.service.CustomerServiceImpl;

public class ListAction extends Action{

	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t List of Customers");
		System.out.println("\t\t -----------------------");
	}

	@Override
	public void execute() {
		CustomerService service = new CustomerServiceImpl();
		List<Customer> customerList = service.getAllCustomers();
		if(customerList==null || customerList.isEmpty()) {
			System.out.println("\n\n\t\t No customers Found !!!");
		}
		else {
			System.out.println("\t\t CustomerId  \t Name     \t\t Balance \t Email      \t\t  Phone");
			
			System.out.println("\t\t --------------------------------------------------------------------------------------------");
			customerList.stream().forEach( (s) -> {
			
			System.out.printf("\t\t %d \t\t %-20s \t %10.2f \t %-20s \t %-15s \n",
					s.getId(),
					s.getName(),
					s.getBalance(),
					s.getEmail(),
					s.getPhone()
					
					);
			});
		}
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		System.out.println("\t\t Listing Customers Completed.");
		System.out.println("\n\n");
	}

}
