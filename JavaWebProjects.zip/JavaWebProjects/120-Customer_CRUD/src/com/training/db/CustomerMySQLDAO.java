package com.training.db;

import java.sql.Connection;
import java.util.List;

import com.training.model.Customer;

public interface CustomerMySQLDAO {
	//since the variables are final, we give variable name in CAPITAL Letters
	String INSERT_QRY="insert into customers_1 values(?,?,?,?,?)";
	String UPDATE_QRY="update customers_1 set customer_name=?, balance=?, email=?, phone_number=? where customer_id=?";
	String DELETE_QRY="delete from customers_1 where customer_id=?";
	String SEARCH_QRY="select * from customers_1 where customer_id=?";
	String FINDALL_QRY="select * from customers_1";
	
	boolean insertCustomer(Connection connection, Customer customer);
	boolean updateCustomer(Connection connection, Customer customer);
	boolean deleteCustomer(Connection connection, Customer customer);
	Customer findCustomerById(Connection connection,int id);
	List<Customer> findAllCustomers(Connection connection);
}
