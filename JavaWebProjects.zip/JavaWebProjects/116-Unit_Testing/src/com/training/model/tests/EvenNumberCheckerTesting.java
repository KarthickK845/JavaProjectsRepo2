package com.training.model.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.training.model.EvenNumberChecker;

public class EvenNumberCheckerTesting {	
	
	@ParameterizedTest(name = "Testing if a number {0} is Even number")
	@ValueSource(ints = {2,4,6,8,10})
	public void testEvenNumber(int number) {
		boolean expected = true;
		boolean actual = EvenNumberChecker.compute(number);
		assertEquals(expected, actual);
		
	}
}
