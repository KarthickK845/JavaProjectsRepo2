package com.training.model.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.training.model.Calculator;

public class CalculatorTest {
	Calculator calculator;
	
	@BeforeEach     // must be called before each Test case
	public void init() {  //method name can be anything  
		calculator = new Calculator(10, 5);
	}
	
	@AfterEach
	public void destroy() {
		calculator = null;
	}
	
	@Test
	@DisplayName("Testing Add Method of Calculator")
	public void testingAdd() {
		//Calculator calculator = new Calculator(10, 5); //being repetitive, we use init() method
		
		int expected = 15;
		int actual = calculator.add();
		assertEquals(expected, actual);
		//if this is success, code is correct else if fails, some error with the code
	}
	
	@Test
	@DisplayName("Testing Subtract Method of Calculator")
	public void testingSubtract() {
		
		int expected = 5;
		int actual = calculator.subtract();
		assertEquals(expected, actual);
		
	}
	
	@Test
	@DisplayName("Testing Multiply Method of Calculator")
	public void testingMultiply() {
		
		int expected = 50;
		int actual = calculator.multiply();
		assertEquals(expected, actual);
		
	}
	
	@Test
	@DisplayName("Testing Divide Method of Calculator")
	public void testingDivide() {
			//Calculator calculator = new Calculator(5, 5);
		int expected = 2;
		int actual = calculator.divide();
		assertEquals(expected, actual);
			//calculator=null;
	}
}
