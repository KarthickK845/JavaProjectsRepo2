package com.training.model.tests;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.training.model.OddNumberChecker;

public class OddNumberCheckerTesting {
	
	@ParameterizedTest(name = "Testing if a number {0} is Odd number")   
	//to give the parameter value in place of 0 for each test case
	@ValueSource(ints = {3,5,7,9,11})  //to test for the different values
	public void test(int number) {
		assertTrue(OddNumberChecker.isOdd(number));
	}
}
