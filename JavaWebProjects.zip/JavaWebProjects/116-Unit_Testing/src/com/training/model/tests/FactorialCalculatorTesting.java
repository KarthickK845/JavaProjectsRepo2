package com.training.model.tests;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.training.model.FactorialCalculator;

public class FactorialCalculatorTesting {
	//test the calculate method
	//3 test cases
	//1 test to check for any number between 1 to 10
	//1 test to check for any number between 11 to 15
	//1 test to check for any number between 16 to 20
	
	FactorialCalculator fCalculator;
	
	@BeforeEach
	public void init() {
		fCalculator = new FactorialCalculator();
	}
	
	@AfterEach
	public void destroy() {
		fCalculator = null;
	}
	
	@Test
	@DisplayName("Testing Factorial for a number between 1 to 10")
	public void testingFactCalc1() {
		fCalculator.setNum(5);
		long expected = 120;
		long actual = fCalculator.calculate();
		assertEquals(expected, actual);
	}
	
	@Test
	@DisplayName("Testing Factorial for a number between 11 to 15")
	public void testingFactCalc2() {
		fCalculator.setNum(12);
		long expected = 479001600;
		long actual = fCalculator.calculate();
		assertEquals(expected, actual);
	}
	
	@Test
	@DisplayName("Testing Factorial for a number between 16 to 20")
	public void testingFactCalc3() {
		fCalculator.setNum(17);
		long expected = 355687428096000L;
		long actual = fCalculator.calculate();
		assertEquals(expected, actual);
	}
	
	
}
