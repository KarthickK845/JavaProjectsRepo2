package com.training.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class EmployeeTesting {
	Employee employee;
	
	@BeforeEach
	public void init() {
		employee = new Employee();
	}
	
	@AfterEach
	public void clean() {
		employee = null;
	}
	
	@Test
	@DisplayName("Testing Positive Value for setting BasicSalary")
	public void testBasicSalaryForPositiveData() {
		try {
			employee.setBasicSalary(1000.00);
			double expected = 1000.00;
			double actual = employee.getBasicSalary();
			assertEquals(expected, actual);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	@DisplayName("Testing Negative Value for setting BasicSalary")
	public void testBasicSalaryForNegativeData() {
		Exception e = assertThrows(Exception.class, ()->{
			employee.setBasicSalary(-1000.00);
		});
		
		String expectedMessage="Negative Salary Not Acceptable";
		String actualMessage = e.getMessage();
		assertEquals(expectedMessage, actualMessage);
	}
	
	@Test
	@DisplayName("Testing Valid Data for setting Name")
	public void testNameForValidData() {
		try {
			employee.setName("Karthi");
			String expected = "Karthi";
			String actual = employee.getName();
			assertEquals(expected, actual);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	@DisplayName("Testing Null Value for setting Name")
	public void testNameForNullData() {
		Exception e = assertThrows(Exception.class, ()->{
			employee.setName(null);
		});
		
		String expectedMessage="Invalid Value for Name";
		String actualMessage = e.getMessage();
		assertEquals(expectedMessage, actualMessage);
	}
	
	@Test
	@DisplayName("Testing Empty Value for setting Name")
	public void testNameForEmptyData() {
		Exception e = assertThrows(Exception.class, ()->{
			employee.setName("");
		});
		
		String expectedMessage="Invalid Value for Name";
		String actualMessage = e.getMessage();
		assertEquals(expectedMessage, actualMessage);
	}
}
