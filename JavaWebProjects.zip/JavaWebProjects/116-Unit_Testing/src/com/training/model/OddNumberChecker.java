package com.training.model;

public class OddNumberChecker {

	public static boolean isOdd(int number) {
		if(number%2==0)
			return false;
		else
			return true;
	}
}
