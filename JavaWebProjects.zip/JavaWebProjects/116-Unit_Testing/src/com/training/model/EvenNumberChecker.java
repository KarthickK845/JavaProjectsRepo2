package com.training.model;

public class EvenNumberChecker {
	
	public static boolean compute(int number) {
		if(number%2==0)
			return true;
		else
			return false;
	}
}
