package com.training.ui;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;

@WebServlet(name = "FrontController", urlPatterns = { "*.do" })
public class FrontControllerServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String requestedurl = request.getRequestURI();
		System.out.println("-----------------------");
		System.out.println(requestedurl);
		System.out.println("-----------------------");
		
		int positionofslash = requestedurl.lastIndexOf("/");
		System.out.println(positionofslash);
		
		String s1 = requestedurl.substring(positionofslash+1);
		int positionofdot = s1.lastIndexOf(".");
		String s2 = s1.substring(0,positionofdot);
		System.out.println(s2);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(s2);
		dispatcher.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
