package com.training.ui;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main2 {

	public static void main(String[] args) {
		// Step 1
		// Load a Driver

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Loaded Successfully");
		} catch (ClassNotFoundException e) {
			System.err.println(e);
		}

		// Step 2
		// Establish a connection to a database
		Connection connection = null;
		String dburl = "jdbc:mysql://localhost:3306/trainingdb19?useSSL=false";
		String userName = "root";
		String password = "root";

		try {
			connection = DriverManager.getConnection(dburl, userName, password);
			System.out.println("Connected to Database");
		} catch (SQLException e) {
			System.err.println(e);
		}

		// Step 3
		// calling stored procedures
		try {
			CallableStatement statement = connection.prepareCall("{call incrementSalary(?,?,?)}");
			statement.setString(1, "USA");
			statement.setInt(2, 5);
			// registering the out parameter variable thru which we expect an Integer value
			statement.registerOutParameter(3, java.sql.Types.DOUBLE);
			statement.execute();
			System.out.println(statement.getInt(3));
		} catch (SQLException e1) {
			System.err.println(e1);
		}

		// Step 4
		// close the connection
		try {
			connection.close();
			System.out.println("Connection closed successfully");
		} catch (SQLException e) {
			System.err.println(e);
		}

	}

}
