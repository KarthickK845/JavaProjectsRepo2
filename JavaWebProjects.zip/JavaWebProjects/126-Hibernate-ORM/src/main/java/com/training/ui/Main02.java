package com.training.ui;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.training.model.Product;

public class Main02 {

	private static void insert() {
		Product product = new Product(504,"Leather Shoes",1000.00,"Accessories");
		
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		session.getTransaction().begin();
		session.persist(product);
		session.getTransaction().commit();
		
		session.close();
		sessionFactory.close();
		
	}
	
	private static void read() {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		Product product;
		product=session.find(Product.class, 502);
		
		System.out.println(product);
		
		session.close();
		sessionFactory.close();
	}
	
	private static void update() {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		Product product = session.find(Product.class, 502);
		product.setPrice(product.getPrice()+120);
		
		session.getTransaction().begin();
		session.merge(product);
		session.getTransaction().commit();
		
		session.close();
		sessionFactory.close();
	}
	
	private static void readAll() {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		String str = "from Product";
		Query<Product> qry = session.createQuery(str, Product.class);
		
		List<Product> productsList = qry.getResultList();
		System.out.println(productsList);
		
		session.close();
		sessionFactory.close();
		
	}
	
	private static void delete() {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		Product product=session.find(Product.class, 503);
		
		session.getTransaction().begin();
		session.remove(product);
		session.getTransaction().commit();
		
		session.close();
		sessionFactory.close();
	}
	
	public static void main(String[] args) {
		//insert();
		//readAll();
		update();
		//delete();
		//read();
	}

}
