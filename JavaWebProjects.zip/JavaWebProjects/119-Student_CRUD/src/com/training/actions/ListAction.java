package com.training.actions;

import java.util.List;

import com.training.model.Student;
import com.training.service.StudentService;
import com.training.service.StudentServiceImpl;

public class ListAction extends Action{

	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t List of Students");
		System.out.println("\t\t -----------------------");
	}

	@Override
	public void execute() {
		//we will replace below 
		StudentService service = new StudentServiceImpl();
		List<Student> studentList = service.getAllStudents();
		if(studentList==null || studentList.isEmpty()) {
			System.out.println("\n\n\t\t No Students Found !!!");
		}
		else {
			System.out.println("\t\t RollNo  Name     \t\t Gender  Mark1   Mark2	  Total     Average");
			
			System.out.println("\t\t --------------------------------------------------------------------------");
			studentList.stream().forEach( (s) -> {
			
			System.out.printf("\t\t %d \t %-20s \t %s \t %d \t %d \t %d \t %10.2f \n",
					s.getRollNumber(),
					s.getName(),
					s.getGender()+"",
					s.getMark1(),
					s.getMark2(),
					s.getTotal(),
					s.getAverage()
					);
			});
		}
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		System.out.println("\t\t Listing Students Completed.");
		System.out.println("\n\n");
	}

}
