package com.training.actions;

import com.training.model.Student;
import com.training.service.StudentService;
import com.training.service.StudentServiceImpl;
import com.training.ui.util.ConsoleIO;

public class UpdateAction extends Action {
	boolean status;

	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Update Student");
		System.out.println("\t\t -----------------------");
	}

	@Override
	public void execute() {
		int rollNumber;
		String name;
		char gender;
		int mark1, mark2;
		try {
			ConsoleIO.prompt("Enter Roll Number To Update ");
			rollNumber = ConsoleIO.intInput();
			if (rollNumber < 0)
				throw new Exception("Roll Number cannot be negative");

			ConsoleIO.prompt("Enter Name ");
			name = ConsoleIO.stringInput();
			if (name.equals("") || name.equals(null))
				throw new Exception("Name cannot be Empty or NULL");

			ConsoleIO.prompt("Enter Gender (M/F) ");
			gender = ConsoleIO.charInput();
			if (gender != 'M' && gender != 'F')
				throw new Exception("Gender must be M or F only");

			ConsoleIO.prompt("Enter Mark 1 ");
			mark1 = ConsoleIO.intInput();
			if (mark1 < 0 || mark1 > 100)
				throw new Exception("Please enter valid mark 1");

			ConsoleIO.prompt("Enter Mark 2 ");
			mark2 = ConsoleIO.intInput();
			if (mark2 < 0 || mark2 > 100)
				throw new Exception("Please enter valid mark 2");

			Student student = new Student(rollNumber, name, gender, mark1, mark2);
			
			StudentService service = new StudentServiceImpl();
			status = service.updateStudent(student);
			
		} catch (Exception e) {
			System.err.println(e);
			execute();
		}
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		if(status==true)
			System.out.println("\t\t Update Student Completed Successfully.");
		else
			System.out.println("\t\t Updating Student Failed.");
		System.out.println("\n\n");
	}

}
