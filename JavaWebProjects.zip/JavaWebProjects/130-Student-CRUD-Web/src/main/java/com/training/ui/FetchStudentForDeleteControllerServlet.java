package com.training.ui;

import java.io.IOException;

import com.training.model.Student;
import com.training.service.StudentService;
import com.training.service.StudentServiceImpl;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "FetchStudentForDeleteController", urlPatterns = { "/DeleteStudent2" })
public class FetchStudentForDeleteControllerServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String str_rollNumber = request.getParameter("txt_rollnumber");
		int rollNumber = Integer.parseInt(str_rollNumber);
		
		StudentService service = new StudentServiceImpl();
		Student student = service.searchStudent(rollNumber);
		
		request.setAttribute("stud", student);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("DeleteStudent.jsp");
		dispatcher.forward(request, response);
	}

}
