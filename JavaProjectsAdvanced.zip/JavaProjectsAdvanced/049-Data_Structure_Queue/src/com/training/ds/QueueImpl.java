package com.training.ds;

public class QueueImpl<T> implements Queue<T>{ //class must also specify generics

	@Override
	public void enQueue(T object) throws Throwable {
		// TODO Auto-generated method stub
		
	}

	@Override
	public T deQueue() throws Throwable {
		// TODO Auto-generated method stub
		return null;
	}   
	
}
