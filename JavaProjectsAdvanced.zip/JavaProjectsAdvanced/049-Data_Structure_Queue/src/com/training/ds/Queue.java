package com.training.ds;

public interface Queue<T> {
	void enQueue(T object) throws Throwable;	//method to add element
	T deQueue() throws Throwable;			//method to remove element (removes first element)
}
