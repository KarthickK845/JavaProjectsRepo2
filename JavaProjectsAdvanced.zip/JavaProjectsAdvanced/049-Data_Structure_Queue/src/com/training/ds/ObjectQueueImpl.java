package com.training.ds;

public class ObjectQueueImpl implements Queue{   //simple interface and not Generic interface

	@Override
	public void enQueue(Object object) throws Throwable {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object deQueue() throws Throwable {
		// TODO Auto-generated method stub
		return null;
	}

}
