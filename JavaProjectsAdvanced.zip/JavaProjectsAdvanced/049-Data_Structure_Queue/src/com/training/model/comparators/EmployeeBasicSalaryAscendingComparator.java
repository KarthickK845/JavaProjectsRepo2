package com.training.model.comparators;

import java.util.Comparator;

import com.training.model.Employee;

public class EmployeeBasicSalaryAscendingComparator implements Comparator<Employee>{

	@Override
	public int compare(Employee e1, Employee e2) {
		
		if(e1.getBasic()<e2.getBasic())
			return -1;
		if(e1.getBasic()>e2.getBasic())
			return 1;
		return 0;
	}

}
