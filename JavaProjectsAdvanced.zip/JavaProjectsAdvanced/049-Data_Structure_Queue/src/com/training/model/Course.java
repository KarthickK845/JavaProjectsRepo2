package com.training.model;

public class Course implements Comparable<Course>{
	private String courseName;
	private int durationInMonths;
	private double fees;
	
	public Course(String courseName, int durationInMonths, double fees) {
		super();
		this.courseName = courseName;
		this.durationInMonths = durationInMonths;
		this.fees = fees;
	}

	public Course() {
		super();
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public int getDurationInMonths() {
		return durationInMonths;
	}

	public void setDurationInMonths(int durationInMonths) {
		this.durationInMonths = durationInMonths;
	}

	public double getFees() {
		return fees;
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

	@Override
	public int compareTo(Course o) {
		if(this.durationInMonths<o.durationInMonths)
			return -1;
		if(this.durationInMonths>o.durationInMonths)
			return 1;
		return 0;
	}

	@Override
	public String toString() {
		return "Course [getCourseName()=" + getCourseName() + ", getDurationInMonths()=" + getDurationInMonths()
				+ ", getFees()=" + getFees() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + durationInMonths;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Course))
			return false;
		Course other = (Course) obj;
		if (durationInMonths != other.durationInMonths)
			return false;
		return true;
	}
	
	
	
}
