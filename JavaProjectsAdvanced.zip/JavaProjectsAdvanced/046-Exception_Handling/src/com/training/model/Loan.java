package com.training.model;

public class Loan {
	private int loanId;
	private String customerName;
	private double loanAmount;
	private int tenure;
	
	
	
	public Loan() {
		super();
	}

	public Loan(int loanId, String customerName, double loanAmount, int tenure) throws InvalidLoanIdException, InvalidCustomerNameException {
		super();
		setLoanId(loanId);
		setCustomerName(customerName);
		setLoanAmount(loanAmount);
		setTenure(tenure);
	}
	
	public int getLoanId() {
		return loanId;
	}
	public void setLoanId(int loanId) throws InvalidLoanIdException {
		if(loanId<=0) {
			InvalidLoanIdException e = new InvalidLoanIdException("Incorrect Loan ID");
			throw e;
		}
		this.loanId = loanId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) throws InvalidCustomerNameException {
		if(customerName==null || customerName.length()==0) {
			InvalidCustomerNameException e = new InvalidCustomerNameException("Incorrect Name");
			throw e;
		}
		this.customerName = customerName;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		if(loanAmount<=0) {
			InvalidLoanAmountException e = new InvalidLoanAmountException(loanAmount+" : Loan Amount cannot be zero or negative");
			throw e;
		}
		this.loanAmount = loanAmount;
	}
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		if(tenure<=0) {
			InvalidTenureException e = new InvalidTenureException(tenure+" : Tenure cannot be zero or negative");
			throw e;
		}
		this.tenure = tenure;
	}
	
	
	
}
