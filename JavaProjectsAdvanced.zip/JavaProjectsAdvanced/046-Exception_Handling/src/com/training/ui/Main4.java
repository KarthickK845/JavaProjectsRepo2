package com.training.ui;

import java.util.Arrays;

public class Main4 {

	static void createArray(int size) {
		try {
			double[] arr = new double[size];
			System.out.println(Arrays.toString(arr));
		}
		catch(NegativeArraySizeException e)
		{
			System.out.println("Invalid Array Size");
			e.printStackTrace();
			System.out.println("Continuing...");
		}
	}

	public static void main(String[] args) {
		System.out.println("Program Begins...");

		createArray(10);
		createArray(5);
		createArray(0);
		createArray(-40);
		createArray(25);

		System.out.println("Program Ends...");

	}

}
