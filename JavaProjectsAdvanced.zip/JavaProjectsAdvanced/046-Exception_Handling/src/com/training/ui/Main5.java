package com.training.ui;

import com.training.model.InvalidCustomerNameException;
import com.training.model.InvalidLoanAmountException;
import com.training.model.InvalidLoanIdException;
import com.training.model.InvalidTenureException;
import com.training.model.Loan;

public class Main5 {

	public static void main(String[] args) throws InvalidLoanIdException, InvalidCustomerNameException {
		System.out.println("Program Begins");
		
		// create loan objects
		// handle exceptions after calling setters
		Loan loan = new Loan(-10,"Naren",1010,10);

//		try {
//			loan.setLoanId(-10);
//
//		} catch (InvalidLoanIdException e) {
//			e.printStackTrace();
//		}
//
//		try {
//			loan.setCustomerName(null);
//		} catch (InvalidCustomerNameException e) {
//			e.printStackTrace();
//		}

		//It is fine to call below RuntimeExceptions directly instead of try catch
		loan.setLoanAmount(10);
		loan.setTenure(10);
		
//		try {
//			
//		} catch (InvalidLoanAmountException e) {
//			e.printStackTrace();
//		}
//
//		try {
//			
//		} catch (InvalidTenureException e) {
//			e.printStackTrace();
//		}

		System.out.println("Program Ends");
	}

}
