package com.training.ui;

public class Main2 {
	
	public static void printLength(String str) {
		try {
			System.out.println(str.length());
		}
		catch(NullPointerException e)
		{
			e.printStackTrace();
		}
		finally
		{
			System.out.println("Have a nice day");
		}
	}

	public static void main(String[] args) {
		String s1="welcome";
		String s2 = null;
		String s3 = "UST";
		
		printLength(s1);
		printLength(s2);
		printLength(s3);

	}

}
