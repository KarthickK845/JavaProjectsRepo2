package com.training.model.pack2;

public class Welcome {
	public void sayWelcome() {
		System.out.println("Hi Welcome");
	}
}
