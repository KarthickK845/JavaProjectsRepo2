package com.training.model.pack1;

public class Subtraction {
	public static int subtract(int a, int b) {
		return a-b;
	}
}
