package com.training.model.pack1;

public class Addition {
	public static int add(int a, int b) {
		return a+b;
	}
}
