package com.training.ui;

import com.training.model.pack1.Addition;
import com.training.model.pack1.Multiplication;
import com.training.model.pack1.Subtraction;
import com.training.model.pack1.Task;

public class Main1 {

	public static void main(String[] args) {
		Task task;
		
		task = Addition::add; //Method Reference for static method
		System.out.println(task.execute(10, 20));

		task=Subtraction::subtract;  //Method Reference for static method
		System.out.println(task.execute(50, 10));
		
		task=Multiplication::multiply;  //Method Reference for static method
		System.out.println(task.execute(5, 25));
	}

}
