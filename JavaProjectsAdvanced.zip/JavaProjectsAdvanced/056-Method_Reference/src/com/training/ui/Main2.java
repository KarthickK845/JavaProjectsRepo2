package com.training.ui;

import com.training.model.pack2.GoodBye;
import com.training.model.pack2.Greet;
import com.training.model.pack2.Hello;
import com.training.model.pack2.Welcome;

public class Main2 {

	public static void main(String[] args) {
		Hello hello;
		
		//Method reference for non static methods
		Welcome w = new Welcome();
		hello = w::sayWelcome;
		hello.doIt();
		
		GoodBye gb = new GoodBye();
		hello = gb::sayGoodBye;
		hello.doIt();
		
		Greet g = new Greet();
		hello = g::greet;
		hello.doIt();
	}

}
