package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

public class Main4 {

	public static void main(String[] args) {
		List<String> names = new LinkedList<>();
		names.add("Karthi");
		names.add("Partha");
		names.add("Arthi");
		names.add("Manushi");
		
		Function<String, Integer> fn;
		//fn = (s) -> s.length();
		fn = String::length;   //method reference
		
		Integer r = fn.apply(names.get(3));
		System.out.println(r);
		
		Function<String, String> fn1;
		//fn1 = (s) -> s.toUpperCase();
		fn1 = String::toUpperCase;   //method reference
		String upperstr = fn1.apply(names.get(2));
		System.out.println(upperstr);
	}

}
