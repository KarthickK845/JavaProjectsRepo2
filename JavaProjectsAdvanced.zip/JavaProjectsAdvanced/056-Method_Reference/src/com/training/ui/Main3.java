package com.training.ui;

import com.training.model.pack3.Circle;
import com.training.model.pack3.Employee;
import com.training.model.pack3.Factory;

public class Main3 {

	public static void main(String[] args) {
		Factory<Circle> factory;
		
		factory = Circle::new; //Method Reference to a Constructor
		Circle c = factory.create(10);
		System.out.println(c);
		
		Factory<Employee> factory1;
		factory1 = Employee::new;  //Method Reference to a Constructor
		Employee e = factory1.create(1061);
		System.out.println(e);
	}

}
