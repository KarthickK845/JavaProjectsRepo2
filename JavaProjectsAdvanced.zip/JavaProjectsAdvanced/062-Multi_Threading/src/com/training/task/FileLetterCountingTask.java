package com.training.task;

import java.io.FileInputStream;
import java.io.InputStream;

public class FileLetterCountingTask implements Runnable {

	String fileName;
	
	
	
	public FileLetterCountingTask(String fileName) {
		super();
		this.fileName = fileName;
	}



	@Override
	public void run() { //run() cannot throw Throwable or any Exception
		int count=0;
		String name = Thread.currentThread().getName();
		
		try {
			InputStream is = new FileInputStream(fileName);
			while(true) {
				int i = is.read();
				if(i==-1)
					break;
				else {
					count++;
					System.out.println(name+" : "+fileName+" counting "+count);
					Thread.sleep(1000);
				}
			}
			System.out.println(name+" counted... length is : "+ count);
			is.close();
		} catch (Exception e) {
			System.err.println(e);
		}
		
	}

}
