package com.training.ui;

import com.training.model.Acceptor;

public class Main03 {

	public static void main(String[] args) {
		//instead of having separate classes (.java files) for each type of Acceptor
		//we use Anonymous class
		//since JAVA 1.5 we have a concept called 
		//Anonymous class
		Acceptor<String> acceptor1;
		acceptor1=new Acceptor<String>() {

			@Override
			public void accept(String obj) {
				System.out.println(obj.toUpperCase());
			}
			
		};

		acceptor1.accept("ust global");
		
		Acceptor<Integer> acceptor2;
		acceptor2 = new Acceptor<Integer>() {
			
			@Override
			public void accept(Integer obj) {
				System.out.println(obj.intValue()*obj.intValue());
			}
		};
		
		acceptor2.accept(400);
		
		Acceptor<Double> acceptor3;
		acceptor3 = new Acceptor<Double>() {
			
			@Override
			public void accept(Double obj) {
				System.out.println(obj.intValue()*obj.intValue()*obj.intValue());
			}
		};
		
		acceptor3.accept(20.0);
	}

}
