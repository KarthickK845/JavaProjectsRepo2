package com.training.ui;

import com.training.model.Acceptor;
import com.training.model.Account;
import com.training.model.AccountAcceptor;
import com.training.model.BillItem;
import com.training.model.BillItemAcceptor;
import com.training.model.Circle;
import com.training.model.CircleAcceptor;

public class Main02 {

	public static void main(String[] args) {
		Acceptor<Circle> acceptor1 = new CircleAcceptor();
		acceptor1.accept(new Circle(10));

		Acceptor<Account> acceptor2 = new AccountAcceptor();
		acceptor2.accept(new Account("Ram", 1000.00));
		
		Acceptor<BillItem> acceptor3 = new BillItemAcceptor();
		acceptor3.accept(new BillItem("Oppo", 5, 4000.00));
	}

}
