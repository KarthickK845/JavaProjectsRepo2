package com.training.ui;

import com.training.model.Acceptor;

public class Main05 {

	public static void main(String[] args) {
		//Lambda Expression
		
		Acceptor<String> acceptor1;
		acceptor1 = (String s)->{ //lambda
			System.out.println(s.length());
			System.out.println(s.toUpperCase());
		};
		
		acceptor1.accept("welcome");
		
		Acceptor<Integer> acceptor2;
		//single statement
		acceptor2 = i -> System.out.println(i.doubleValue());

		acceptor2.accept(120);
		
		Acceptor<Double> acceptor3;
		acceptor3 = d -> System.out.println(d.intValue());
		acceptor3.accept(500.00);
		
		Acceptor<StringBuffer> acceptor4;
		acceptor4 = sb -> System.out.println(sb.reverse());
		acceptor4.accept(new StringBuffer("morning"));
	}

}
