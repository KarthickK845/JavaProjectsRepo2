package com.training.ui;

import com.training.model.Account;
import com.training.model.Circle;
import com.training.model.Employee;
import com.training.model.Tester;

public class Main08 {

	public static void main(String[] args) {
		Tester<Circle> tester1;
		tester1 = c -> c.getArea()>=100;
		System.out.println(tester1.test(new Circle(3)));
		
		Tester<Account> tester2;
		tester2 = a -> a.getBalance()>10000.00;
		System.out.println(tester2.test(new Account("Ranjith", 3000.00)));
	
		Tester<Employee> tester3;
		Employee obj = new Employee(12, "Hari", "male", "mumbai", 300000.00);
		
		tester3 = e -> e.getCityName().equalsIgnoreCase("MUMBAI");
		System.out.println("From Mumbai ? "+ tester3.test(obj));
		
		tester3 = e -> e.getGender().equalsIgnoreCase("Female");
		System.out.println("Female ? "+tester3.test(obj));
		
		tester3 = e -> e.getNetSalary()>50000.00;
		System.out.println("Net Salary > 50K ? "+tester3.test(obj));
		
	}

}
