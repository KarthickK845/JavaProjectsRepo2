package com.training.model;

@FunctionalInterface
public interface Acceptor<T> {
	void accept(T obj);
	//Single abstract method
	//FunctionalInterface cannot have multiple abstract methods
	//can have default and static methods
}
