package com.training.model;

public class RewardPoints {
	int points;
	
	void purchase(double amt) {
		int r=(int) (amt/100);
		
	}
}
