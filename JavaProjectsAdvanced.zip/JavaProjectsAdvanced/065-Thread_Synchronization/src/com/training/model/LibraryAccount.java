package com.training.model;

public class LibraryAccount {
	int numOfBooksInAccount = 5;

	public synchronized void borrowBook(int numOfBooksToBorrow) {
		String tname = Thread.currentThread().getName();

		for (int i = 1; i <= numOfBooksToBorrow; i++) {
			this.numOfBooksInAccount++;
			if (this.numOfBooksInAccount >= 10) {
				try {
					notify();
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println(tname + ": Borrowing.." + this.numOfBooksInAccount);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		notify();
		System.out.println("Borrowing " + numOfBooksToBorrow + " books completed");
	}

	public synchronized void returnBook(int numOfBooksToReturn) {
		String tname = Thread.currentThread().getName();

		
		for (int i = 1; i <= numOfBooksToReturn; i++) {
			this.numOfBooksInAccount--;
			if (this.numOfBooksInAccount <= 5) {
				try {
					notify();
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println(tname + ": Returning.." + this.numOfBooksInAccount);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		notify();
		System.out.println("Returning " + numOfBooksToReturn + " books completed");
	}
}
