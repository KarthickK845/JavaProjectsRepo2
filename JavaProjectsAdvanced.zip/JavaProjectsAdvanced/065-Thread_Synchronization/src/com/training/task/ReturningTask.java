package com.training.task;

import com.training.model.LibraryAccount;

public class ReturningTask implements Runnable{
	LibraryAccount libAccount;

	public ReturningTask(LibraryAccount libAccount) {
		super();
		this.libAccount = libAccount;
	}

	@Override
	public void run() {
		libAccount.returnBook(5);
		
	}
	
	
}
