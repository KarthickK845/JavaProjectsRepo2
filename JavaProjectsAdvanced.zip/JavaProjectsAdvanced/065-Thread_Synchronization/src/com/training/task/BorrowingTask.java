package com.training.task;

import com.training.model.LibraryAccount;

public class BorrowingTask implements Runnable{
	LibraryAccount libAccount;
	
	

	public BorrowingTask(LibraryAccount libAccount) {
		super();
		this.libAccount = libAccount;
	}



	@Override
	public void run() {
		libAccount.borrowBook(10);
		
	}
	
	
}
