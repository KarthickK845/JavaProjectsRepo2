package com.training.task;

public class Counter {

	int count=0;
	
	public synchronized int getCount() {
		return count;
	}
	
	public synchronized void increment() {
		for(int i=1;i<=10;i++) {
			count++;
			String tname = Thread.currentThread().getName();
			System.out.println(tname+" : "+count);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
