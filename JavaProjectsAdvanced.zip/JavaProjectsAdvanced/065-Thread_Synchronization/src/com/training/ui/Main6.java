package com.training.ui;

import com.training.model.LibraryAccount;
import com.training.task.BorrowingTask;
import com.training.task.ReturningTask;

public class Main6 {

	public static void main(String[] args) {
		LibraryAccount libAccount = new LibraryAccount();
		
		Runnable runnable1 = new BorrowingTask(libAccount);
		Runnable runnable2 = new ReturningTask(libAccount);
		
		Thread t1 = new Thread(runnable1, "BT");
		Thread t2 = new Thread(runnable2, "RT");
		
		t1.start();
		t2.start();

	}

}
