package com.training.ui;

import java.util.Comparator;

import com.training.model.Account;
import com.training.model.comparators.AccountCustomerNameComparator;

public class Main7 {

	private static int searchNameEquals(Account[] arr, Account searchObject) {
		for (int i = 0; i < arr.length; i++) {
			if (arr[i].equals(searchObject)) {
				return i;
			}
		}
		return -1;
	}

	private static int searchNameCompare(Account[] arr, Account searchObject) {
		// Comparing by Comparator - will call compare method of the object created
		Comparator comparator = new AccountCustomerNameComparator();
		for (int i = 0; i < arr.length; i++) {
			int r = comparator.compare(arr[i], searchObject);
			if (r == 0)
				return i;
		}
		return -1;
	}

	private static int search(Account[] arr, Account searchObject) {
		// Comparing by calling overridden compareTo method of Comparable
		for (int i = 0; i < arr.length; i++) {
			if (searchObject instanceof Comparable) {
				Comparable searchData = searchObject;
				int r = arr[i].compareTo(searchData);
				if (r == 0)
					return i;
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		Account a1 = new Account("Reema", 200000.00);
		Account a2 = new Account("Kevin", 40000.00);

		Account[] accounts = { a1, a2, new Account("Melvin", 30000.00), new Account("Rahul", 50000.00) };

		Account searchObject = new Account("Melvin", 30000.00);
		int searchResult = search(accounts, searchObject);

		if (searchResult == -1)
			System.out.println("Search object was not found and the search result is  " + searchResult);
		else
			System.out.println("Search object " + searchObject + " is present at position " + searchResult);

		System.out.println("\n =============== Name Search Using Equals ==================");

		Account searchObject1 = new Account("Shahul", 30000.00);
		int nameSearchResult = searchNameEquals(accounts, searchObject1);

		if (nameSearchResult == -1)
			System.out.println("Search object was not found and the search result is  " + nameSearchResult);
		else
			System.out.println("Search object " + searchObject1 + " is present at position " + nameSearchResult);

		System.out.println("\n =============== Name Search Using Comparator ==================");

		Account searchObject2 = new Account("Kevin", 30000.00);
		int nameSearchResult1 = searchNameCompare(accounts, searchObject2);

		if (nameSearchResult1 == -1)
			System.out.println("Search object was not found and the search result is  " + nameSearchResult1);
		else
			System.out.println("Search object " + searchObject2 + " is present at position " + nameSearchResult1);
	}

}
