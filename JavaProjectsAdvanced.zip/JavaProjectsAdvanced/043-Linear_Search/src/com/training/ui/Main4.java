package com.training.ui;

import com.training.model.Square;

public class Main4 {

	private static int search(Square[] arr, Square searchObject) {

		for (int i = 0; i < arr.length; i++) {
			if (arr[i].equals(searchObject)) {
				return i;
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		Square s1 = new Square(10);
		Square s2 = new Square(13);

		Square[] circles = { s1, s2, new Square(2), new Square(25), new Square(15) };

		Square searchSquare = new Square(5);
		int searchResult = search(circles, searchSquare);

		if (searchResult == -1)
			System.out.println("Search object was not found and the search result is  " + searchResult);
		else
			System.out.println("Search object " + searchSquare + " is present at position " + searchResult);

	}

}
