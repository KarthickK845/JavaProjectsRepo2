package com.training.ui;

import java.util.Comparator;

import com.training.model.Person;
import com.training.model.comparators.PersonNameComparator;

public class Main9 {
	
	private static int searchCompare(Person[] arr, Person searchObject) {
		// Comparing by Comparator - will call compare method of the object created
		Comparator comparator = new PersonNameComparator();
		for (int i = 0; i < arr.length; i++) {
			int r = comparator.compare(arr[i], searchObject);
			if (r == 0)
				return i;
		}
		return -1;
	}

	private static int search(Person[] arr, Person searchObject) {
		// Comparing by calling overridden compareTo method of Comparable
		for (int i = 0; i < arr.length; i++) {
			if (searchObject instanceof Comparable) {
				Comparable searchData = searchObject;
				int r = arr[i].compareTo(searchData);
				if (r == 0)
					return i;
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		Person p1 = new Person("Karthi", 23);
		Person p2 = new Person("Ram", 30);
		
		Person[] persons = {p1, p2, new Person("Mustafa",33)};
		
		Person searchObject = new Person("Maaran", 33);
		int searchResult = search(persons, searchObject);

		if (searchResult == -1)
			System.out.println("Search object was not found and the search result is  " + searchResult);
		else
			System.out.println("Search object " + searchObject + " is present at position " + searchResult);

		System.out.println("\n =============== Name Search ==================");

		Person searchObject1 = new Person("Mustafa", 40);
		int nameSearchResult = searchCompare(persons, searchObject1);

		if (nameSearchResult == -1)
			System.out.println("Search object was not found and the search result is  " + nameSearchResult);
		else
			System.out.println("Search object " + searchObject1 + " is present at position " + nameSearchResult);
		}

	

}
