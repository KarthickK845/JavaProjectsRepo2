package com.training.ui;

import com.training.model.Circle;

public class Main3 {
	
	private static int search(Circle[] arr, Circle searchObject) {
		
		for(int i = 0; i < arr.length; i++) {
			if(arr[i].equals(searchObject)) {
				return i;
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		Circle c1 = new Circle(10);
		Circle c2 = new Circle(13);
		
		Circle[] circles = {c1, c2, new Circle(2), new Circle(5), new Circle(15)};
		
		Circle searchCircle = new Circle(5);
		int searchResult = search(circles,searchCircle); 
		
		if(searchResult==-1)
			System.out.println("Search object was not found and the search result is  "+searchResult);
		else
			System.out.println("Search object "+searchCircle+" is present at position "+searchResult);
	}

}
