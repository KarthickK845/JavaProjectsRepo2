package com.training.ui;

import com.training.model.BillItem;

public class Main5 {

	private static int search(BillItem[] arr, BillItem searchObject) {

		for (int i = 0; i < arr.length; i++) {
			if (arr[i].equals(searchObject)) {
				return i;
			}
		}
		return -1;
	}
	
	public static void main(String[] args) {
		BillItem b1 = new BillItem("OPPO",5,30000.00);
		BillItem b2 = new BillItem("Samsung",15,10000.00);

		BillItem[] objects = { b1, b2, new BillItem("iPhone",25,30000.00), new BillItem("vivo",50,30000.00) };

		BillItem searchObject = new BillItem("vivo",25,10000.00);
		int searchResult = search(objects, searchObject);
		
		if (searchResult == -1)
			System.out.println("Search object was not found and the search result is  " + searchResult);
		else
			System.out.println("Search object " + searchObject + " is present at position " + searchResult);

		
	}

}
