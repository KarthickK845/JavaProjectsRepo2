package com.training.ui;

import java.util.Comparator;

import com.training.model.Employee;
import com.training.model.Manager;
import com.training.model.SalesEmployee;
import com.training.model.comparators.EmployeeBasicSalaryAscendingComparator;
import com.training.model.comparators.EmployeeBasicSalaryDescendingComparator;

public class Main8 {
	
	private static int searchCompareAscending(Employee[] arr, Employee searchObject) {
		// Comparing by Comparator - will call compare method of the object created
		Comparator comparator = new EmployeeBasicSalaryAscendingComparator();
		for (int i = 0; i < arr.length; i++) {
			int r = comparator.compare(arr[i], searchObject);
			if (r == 0)
				return i;
		}
		return -1;
	}
	
	private static int searchCompareDescending(Employee[] arr, Employee searchObject) {
		// Comparing by Comparator - will call compare method of the object created
		Comparator comparator = new EmployeeBasicSalaryDescendingComparator();
		for (int i = 0; i < arr.length; i++) {
			int r = comparator.compare(arr[i], searchObject);
			if (r == 0)
				return i;
		}
		return -1;
	}

	private static int search(Employee[] arr, Employee searchObject) {
		// Comparing by calling overridden compareTo method of Comparable
		for (int i = 0; i < arr.length; i++) {
			if (searchObject instanceof Comparable) {
				Comparable searchData = searchObject;
				int r = arr[i].compareTo(searchData);
				if (r == 0)
					return i;
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		Employee emp = new Employee(101, "Rajni", "Female", "Calicut", 10000.00);
		Manager mgr = new Manager(103,"Mala","Female","Kochi",80000.00,10);
		SalesEmployee semp = new SalesEmployee(105, "Krishna", "Male", "Trichy", 3000.00, 200000.00);
		SalesEmployee semp1 = new SalesEmployee(102, "Varun", "Male", "Thrissur", 2500.00, 100000.00);

		Employee[] employees = {emp, mgr, semp, semp1};
		
		Employee searchObject = new Manager(113,"Mala","Female","Kochi",80000.00,10);
		int searchResult = search(employees, searchObject);

		if (searchResult == -1)
			System.out.println("Search object was not found and the search result is  " + searchResult);
		else
			System.out.println("Search object " + searchObject + " is present at position " + searchResult);

		System.out.println("\n =============== Basic Ascending Search ==================");

		int ascSearchResult = searchCompareAscending(employees, searchObject);

		if (ascSearchResult == -1)
			System.out.println("Search object was not found and the search result is  " + ascSearchResult);
		else
			System.out.println("Search object " + searchObject + " is present at position " + ascSearchResult);

		System.out.println("\n =============== Basic Descending Search ==================");

		Employee searchObject1 = new Manager(113,"Mala","Female","Kochi",70000.00,10);
		int ascSearchResult1 = searchCompareDescending(employees, searchObject1);

		if (ascSearchResult1 == -1)
			System.out.println("Search object was not found and the search result is  " + ascSearchResult1);
		else
			System.out.println("Search object " + searchObject1 + " is present at position " + ascSearchResult1);
	}

}
