package com.training.ui;

public class Main2 {
	
	private static int search(double[] arr, double searchData) {
		for(int i=0; i<arr.length; i++) {
			if(arr[i]==searchData)
				return i;
		}
		
		return -1;
	}

	public static void main(String[] args) {
		double[] arr = {70.0, 36.0, 12.0, 8.0, 17.0};
		double searchData = 22.0;
		int searchResult = search(arr,searchData); 
		if(searchResult==-1)
			System.out.println("The search data was not found and the search result is  "+searchResult);
		else
			System.out.println("Search data "+searchData+" is present at position "+searchResult);
	}

}
