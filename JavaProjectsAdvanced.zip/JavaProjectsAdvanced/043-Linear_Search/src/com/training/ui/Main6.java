package com.training.ui;

import java.util.Comparator;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;
import com.training.model.comparators.BillItemQuantityComparator;

public class Main6 {
	private static int priceSearch(BillItem[] arr, BillItem searchObject) {
		// Comparing by PriceComparator
		Comparator priceComparator = new BillItemPriceComparator();
		for (int i = 0; i < arr.length; i++) {
			int r = priceComparator.compare(arr[i], searchObject);
			if (r == 0)
				return i;
		}
		return -1;
	}
	
	private static int quantitySearch(BillItem[] arr, BillItem searchObject) {
		// Comparing by Comparator - will call compare method of the object created
		Comparator comparator = new BillItemQuantityComparator();
		for (int i = 0; i < arr.length; i++) {
			int r = comparator.compare(arr[i], searchObject);
			if (r == 0)
				return i;
		}
		return -1;
	}

	private static int search(BillItem[] arr, BillItem searchObject) {
		// Comparing by calling overridden compareTo method of Comparable
		for (int i = 0; i < arr.length; i++) {
			if (searchObject instanceof Comparable) {
				Comparable searchData = searchObject;
				int r = arr[i].compareTo(searchData);
				if (r == 0)
					return i;
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		BillItem b1 = new BillItem("OPPO", 5, 30000.00);
		BillItem b2 = new BillItem("Samsung", 15, 10000.00);

		BillItem[] objects = { b1, b2, new BillItem("iPhone", 25, 30000.00), new BillItem("vivo", 50, 30000.00) };

		BillItem searchObject = new BillItem("vivo", 25, 10000.00);
		int searchResult = search(objects, searchObject);

		if (searchResult == -1)
			System.out.println("Search object was not found and the search result is  " + searchResult);
		else
			System.out.println("Search object " + searchObject + " is present at position " + searchResult);

		System.out.println("\n =============== Quantity Search ==================");
		
		BillItem searchObject1 = new BillItem("Samsung", 2, 15000.00);
		int quantitySearchResult = quantitySearch(objects, searchObject1);

		if (quantitySearchResult == -1)
			System.out.println("Search quantity was not found and the search result is  " + quantitySearchResult);
		else
			System.out.println("Search quantity " + searchObject1 + " is present at position " + quantitySearchResult);

		System.out.println("\n =============== Price Search ==================");
		
		BillItem searchObject2 = new BillItem("iPhone", 25, 30000.00);
		int priceSearchResult = priceSearch(objects, searchObject2);

		if (priceSearchResult == -1)
			System.out.println("Search price was not found and the search result is  " + priceSearchResult);
		else
			System.out.println("Search price " + searchObject2 + " is present at position " + priceSearchResult);
	}

}
