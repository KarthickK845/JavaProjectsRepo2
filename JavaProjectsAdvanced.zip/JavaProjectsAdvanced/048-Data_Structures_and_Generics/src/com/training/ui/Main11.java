package com.training.ui;

import com.training.ds.Stack;
import com.training.ds.StackImpl;
import com.training.model.Account;

public class Main11 {

	public static void main(String[] args) {
		
		try {
			Stack<Account> stack = new StackImpl<>(15);
			stack.push(new Account("Manu",20000.00));
			stack.push(new Account("Nitya",30000.00));
			stack.push(new Account("Kumar",90000.00));
			stack.push(new Account("Krishna",190000.00));
			stack.push(new Account("Oviya",95000.00));
			
			System.out.println(stack);
			
			Account a = stack.pop();
			System.out.println(a.getCustomerName()+","+a.getBalance());

			a = stack.pop();
			System.out.println(a.getCustomerName()+","+a.getBalance());
			
			a = stack.pop();
			System.out.println(a.getCustomerName()+","+a.getBalance());
		}  catch (Throwable e) {
			System.err.println(e.getMessage());
		}
		
	}

}
