package com.training.ui;

import com.training.ds.LongStack;

public class Main2 {

	public static void main(String[] args) {
		byte v1 = 30;
		short v2 = 40;
		int v3 = 80;
		long v4 = 90;
		char v5 = 'A';
		
		LongStack stack = new LongStack(100);
		stack.push(v1);
		stack.push(v2);
		stack.push(v3);
		stack.push(v4);
		stack.push(v5);

		System.out.println(stack);
		
		long r = stack.pop();
		System.out.println(r);
		System.out.println(stack);
		
		r = stack.pop();
		System.out.println(r);
		System.out.println(stack);
		
		r = stack.pop();
		System.out.println(r);
		System.out.println(stack);
	}

}
