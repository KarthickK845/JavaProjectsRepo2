package com.training.ui;

import com.training.ds.StringStack;

public class Main4 {

	public static void main(String[] args) {
		StringStack stack = new StringStack(4);
		stack.push("Delhi");
		stack.push("Mumbai");
		stack.push("Pune");
		stack.push("Bangalore");
		
		System.out.println(stack);
		
		String r = stack.pop();
		System.out.println(r);
		System.out.println(stack);
		
		r = stack.pop();
		System.out.println(r);
		System.out.println(stack);
		
		r = stack.pop();
		System.out.println(r);
		System.out.println(stack);

	}

}
