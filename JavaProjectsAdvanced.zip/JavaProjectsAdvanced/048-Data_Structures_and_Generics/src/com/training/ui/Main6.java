package com.training.ui;

import com.training.ds.CircleStack;
import com.training.model.Circle;

public class Main6 {

	public static void main(String[] args) {
		CircleStack stack = new CircleStack(4);
		
		Circle c = new Circle(20);
		stack.push(c);
		stack.push(new Circle(10));
		stack.push(new Circle(30));
		stack.push(new Circle(28));

		System.out.println(stack);
		
		Circle r=stack.pop();
		System.out.println(r);
		System.out.println(stack);
		
		r = stack.pop();
		System.out.println(r);
		System.out.println(stack);
		
		r = stack.pop();
		System.out.println(r);
		System.out.println(stack);
	}

}
