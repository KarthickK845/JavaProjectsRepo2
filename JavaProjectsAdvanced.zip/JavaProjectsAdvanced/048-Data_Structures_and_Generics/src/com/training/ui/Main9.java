package com.training.ui;

import com.training.ds.StackImpl;
import com.training.model.Circle;
import com.training.model.Square;

public class Main9 {

	public static void main(String[] args) {
	//	try {
		StackImpl<Circle> stack1 = new StackImpl<>(20); 
		stack1.push(new Circle(12));
		stack1.push(new Circle(22));
		stack1.push(new Circle(32));
		stack1.push(new Circle(42));
		
		System.out.println(stack1);
		
		Circle r = stack1.pop();
		stack1.pop();
		stack1.pop();
		stack1.pop();
		stack1.pop();

		System.out.println(r);
		System.out.println(stack1);
		System.out.println(r.getRadius()+","+r.getArea());
		
		StackImpl<Square> stack2 = new StackImpl<>(5); 
		stack2.push(new Square(15));
		stack2.push(new Square(10));
		stack2.push(new Square(5));
		stack2.push(new Square(25));
		stack2.push(new Square(45));
		stack2.push(new Square(55));
		
		System.out.println(stack2);
		
		Square s = stack2.pop();
		System.out.println(s);
		System.out.println(stack2);
		System.out.println(s.getSize()+","+s.getArea());
//		}
//		catch(Exception e) {
//			//System.out.println(e.getMessage());  //error message should not be displayed using out object
//			System.err.println(e.getMessage());  //instead use err object
//		}
		
	}

}
