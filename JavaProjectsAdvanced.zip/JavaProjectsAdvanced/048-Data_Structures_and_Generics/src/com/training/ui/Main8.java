package com.training.ui;

import com.training.ds.ObjectStack;
import com.training.model.Account;
import com.training.model.BillItem;
import com.training.model.Circle;
import com.training.model.Employee;
import com.training.model.Manager;
import com.training.model.Person;
import com.training.model.SalesEmployee;
import com.training.model.Square;

public class Main8 {

	public static void main(String[] args) {
		Integer obj1 = Integer.valueOf(24);
		String obj2 = new String("Welcome");
		Circle obj3 = new Circle(14);
		Square obj4 = new Square(100);
		BillItem obj5 = new BillItem("Oppo", 5, 10000.00);
		Employee obj6 = new Employee(101, "Rajni", "Female", "Calicut", 10000.00);
		Manager obj7 = new Manager(103, "Mala", "Female", "Kochi", 80000.00, 10);
		SalesEmployee obj8 = new SalesEmployee(105, "Krishna", "Male", "Trichy", 3000.00, 200000.00);
		Account obj9 = new Account("Reema", 200000.00);
		Person obj10 = new Person("Karthi", 23);

		ObjectStack stack = new ObjectStack(20);
		stack.push(obj1);
		stack.push(obj2);
		stack.push(obj3);
		stack.push(obj4);
		stack.push(obj5);
		stack.push(obj6);
		stack.push(obj7);
		stack.push(obj8);
		stack.push(obj10);
		stack.push(obj9);

		System.out.println(stack);

		Object r = stack.pop();
		System.out.println(r);
		
		if(r instanceof Person) {
			Person p = (Person) r;
			System.out.println(p.getName()+":"+p.getAge());
			System.out.println(stack);
		}
		
		if(r instanceof Integer) {
			Integer temp = (Integer) r;
			System.out.println(temp.intValue());
			System.out.println(stack);
		}
		
		if(r instanceof String) {
			String temp = (String) r;
			System.out.println(temp.toUpperCase());
			System.out.println(stack);
		}
		
		if(r instanceof Circle) {
			Circle temp = (Circle) r;
			System.out.println(temp.getArea());
			System.out.println(stack);
		}
		
		if(r instanceof Square) {
			Square temp = (Square) r;
			System.out.println(temp.getArea());
			System.out.println(stack);
		}
		
		if(r instanceof Employee) {
			Employee temp = (Employee) r;
			System.out.println(temp.getId()+","+temp.getName()+","+temp.getNetSalary());
			System.out.println(stack);
		}
		
		if(r instanceof Manager) {
			Manager temp = (Manager) r;
			System.out.println(temp.getId()+","+temp.getName()+","+temp.getEmployeeCount());
			System.out.println(stack);
		}
		
		if(r instanceof SalesEmployee) {
			SalesEmployee temp = (SalesEmployee) r;
			System.out.println(temp.getId()+","+temp.getName()+","+temp.getSalesAmount());
			System.out.println(stack);
		}
		
		if(r instanceof BillItem) {
			BillItem temp = (BillItem) r;
			System.out.println(temp.getItemName()+","+temp.getPrice()+","+temp.getQuantity()+","+temp.getItemValue());
			System.out.println(stack);
		}
		
		if(r instanceof Account) {
			Account temp = (Account) r;
			System.out.println(temp.getCustomerName()+","+temp.getBalance());
			System.out.println(stack);
		}
	}

}
