package com.training.ui;

import com.training.ds.SquareStack;
import com.training.model.Square;

public class Main7 {

	public static void main(String[] args) {
		SquareStack stack = new SquareStack(4);

		Square s = new Square(25);
		stack.push(s);
		stack.push(new Square(15));
		stack.push(new Square(32));
		stack.push(new Square(27));

		System.out.println(stack);

		Square r = stack.pop();
		System.out.println(r);
		System.out.println(stack);

		r = stack.pop();
		System.out.println(r);
		System.out.println(stack);

	}

}
