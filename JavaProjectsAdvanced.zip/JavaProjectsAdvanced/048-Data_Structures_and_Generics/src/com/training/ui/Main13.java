package com.training.ui;

import com.training.ds.Stack;
import com.training.ds.StackImpl;
import com.training.model.Employee;
import com.training.model.Manager;
import com.training.model.SalesEmployee;

public class Main13 {

	public static void main(String[] args) {
		try {
		Stack<Employee> stack = new StackImpl<>(10);
		stack.push(new Employee(101, "Ranjani", "Female", "Calicut", 10000.00));
		stack.push(new Manager(103, "Mala", "Female", "Kochi", 80000.00, 10));
		stack.push(new SalesEmployee(105, "Krishna", "Male", "Trichy", 3000.00, 200000.00));
		
		System.out.println(stack);
		
		Employee e = stack.pop();
		System.out.println(e.getId()+","+e.getName()+","+e.getBasic()+","+e.getCityName()+","+e.getGender()+","+e.getNetSalary());

		e = stack.pop();
		System.out.println(e.getId()+","+e.getName()+","+e.getBasic()+","+e.getCityName()+","+e.getGender()+","+e.getNetSalary());
		
		e = stack.pop();
		System.out.println(e.getId()+","+e.getName()+","+e.getBasic()+","+e.getCityName()+","+e.getGender()+","+e.getNetSalary());
	
		System.out.println(stack);
	}
	catch (Throwable e) {
		System.err.println(e.getMessage());
	}
	}

}
