package com.training.ui;

import com.training.ds.Stack;
import com.training.ds.StackImpl;
import com.training.model.Person;

public class Main12 {

	public static void main(String[] args) {
		try {
		Stack<Person> stack = new StackImpl<>(15);
		stack.push(new Person("Rakshit", 30));
		stack.push(new Person("Raman", 25));
		stack.push(new Person("Karan", 33));
		stack.push(new Person("Seetha", 20));
		stack.push(new Person("Laksh", 31));

		System.out.println(stack);

		Person p = stack.pop();
		System.out.println(p.getName() + "," + p.getAge());

		p = stack.pop();
		System.out.println(p.getName() + "," + p.getAge());
		}
		catch (Throwable e) {
			System.err.println(e.getMessage());
		}
		
	} 

}
