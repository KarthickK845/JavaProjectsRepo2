package com.training.ui;

import com.training.ds.Stack;
import com.training.ds.StackImpl;
import com.training.model.BillItem;

public class Main10 {

	public static void main(String[] args) {
		try {
		Stack<BillItem> stack = new StackImpl<>(10);
		stack.push(new BillItem("Oppo", 5, 10000.00));
		stack.push(new BillItem("iPhone", 3, 75000.00));
		stack.push(new BillItem("Redmi", 50, 100000.00));
		stack.push(new BillItem("Lenovo", 25, 200000.00));

		System.out.println(stack);
		
		BillItem b = stack.pop();
		System.out.println(b.getItemName()+","+b.getQuantity()+","+b.getPrice()+","+b.getItemValue());

		b = stack.pop();
		System.out.println(b.getItemName()+","+b.getQuantity()+","+b.getPrice()+","+b.getItemValue());
		}
		catch(Exception e) {
			System.err.println(e.getMessage());
		}
		catch(Throwable e) {
			System.err.println(e.getMessage());
		}
	}

}
