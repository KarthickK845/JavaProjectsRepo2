package com.training.ds;

import com.training.model.Square;

public class SquareStack {
	Square[] arr;
	int index=0;
	
	public SquareStack(int size) {
		this.arr=new Square[size];
	}
	
	public void push(Square data) {
		this.arr[index]=data;
		index++;
	}
	
	public Square pop() {
		index--;
		Square r = this.arr[index];
		return r;
	}
	
	public String toString() {

		String str = "[";
		for(int i=0; i<index; i++) {
			if(i==index-1)
				str=str+this.arr[i];
			else
				str=str+this.arr[i]+",";
		}
		str+="]";
		return str;
	}
}
