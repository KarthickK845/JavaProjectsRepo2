package com.training.ds;

public interface Stack<T> {

	void push(T object) throws Exception;
	T pop() throws Throwable;
}
