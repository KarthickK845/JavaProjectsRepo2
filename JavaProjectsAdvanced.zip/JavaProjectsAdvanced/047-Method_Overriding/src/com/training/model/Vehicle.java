package com.training.model;

public class Vehicle {

}
