package com.training.model;

import java.io.IOException;
import java.sql.SQLException;

public class D extends C{

	@Override
	public void test1() {   
		//Rule 1 - zero exception than super class test1
		//Rule 2 - less than super class test2
	}

	@Override
	public void test2() throws InterruptedException, IOException{
		//Rule 3 - cannot throw checked not listed in super class
		
	}

	@Override
	public void test3() throws InterruptedException, NullPointerException, ArithmeticException{
		//Rule 4 - can throw any number of unchecked not listed in super
	}
	
	@Override
	public void test4() throws Exception {
		//Rule 5 - cannot throw narrow exception than super class
		
	}

	@Override
	public void test5() throws NullPointerException {
		//Rule 6 - can throw wider exception than super class
	}
	
	
	
	
	
	
}
