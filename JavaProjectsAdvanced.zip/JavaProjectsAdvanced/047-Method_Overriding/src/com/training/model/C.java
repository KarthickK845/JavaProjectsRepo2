package com.training.model;

import java.io.IOException;
import java.sql.SQLException;

public class C {
	public void test1() throws IOException, InterruptedException{

	}

	public void test2() throws SQLException, IOException{

	}

	public void test3() throws InterruptedException{

	}
	
	public void test4() throws RuntimeException{
		
	}
	
	public void test5() throws Throwable{
		
	}
}
