package com.training.model;

public class I {

	public Vehicle create() {
		return new Vehicle();
	}
}
