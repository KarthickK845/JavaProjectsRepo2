package com.training.model;

public class Car extends Vehicle{

}
