package com.training.model;

import java.sql.SQLException;

public class B extends A{

	@Override
	public void test1() throws SQLException, NullPointerException{
		
	}

	@Override
	public void test2() throws Exception {  //Exception is narrow than the SQLException (wider) listed in super class method
		
	}

}
