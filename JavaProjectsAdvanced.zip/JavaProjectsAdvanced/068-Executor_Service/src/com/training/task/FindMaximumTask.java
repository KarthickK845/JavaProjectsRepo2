package com.training.task;

import java.util.List;
import java.util.concurrent.Callable;

public class FindMaximumTask implements Callable<Double>{

	List<Double> dlist;
	
	public FindMaximumTask(List<Double> dlist) {
		super();
		this.dlist = dlist;
	}

	@Override
	public Double call() throws Exception {
		
		double max = 0.0;
		for(int i =0; i<dlist.size(); i++) {
			
			if(max<dlist.get(i))
				max=dlist.get(i);
			Thread.sleep(1000);
			String tname = Thread.currentThread().getName();
			System.out.println(tname+" : "+max);
		}
		return max;
	}

}
