package com.training.ui;

import java.util.Arrays;

import com.training.model.Square;

public class Main4 {
	
	private static int search(Square[] arr, Square searchElement) {

		int low = 0, high = arr.length - 1;
		while (low <= high) {
			int mid = low + (high - low) / 2;

			int r = arr[mid].compareTo(searchElement);
			if(r==0)
				return mid;
			
			if(r<0)
				low = mid + 1;

			else
				high = mid - 1;
		}
		return -1;
	}

	public static void main(String[] args) {
		Square s1 = new Square(110);
		Square s2 = new Square(103);
		
		Square[] squares = {s1, s2, new Square(210), new Square(155), new Square(105)};

		Square searchObject = new Square(200);
		
		Arrays.sort(squares);
		System.out.println(Arrays.toString(squares));
		
		int searchResult = search(squares, searchObject);

		if (searchResult == -1)
			System.out.println(searchObject + " not found in the array and result is " + searchResult);
		else
			System.out.println(searchObject + " found in the array and position is " + searchResult);
	}

}
