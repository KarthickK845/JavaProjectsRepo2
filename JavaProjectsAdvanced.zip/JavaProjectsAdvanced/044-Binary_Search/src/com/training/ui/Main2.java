package com.training.ui;

import java.util.Arrays;

public class Main2 {

	private static int search(double[] arr, double searchElement) {

		int low = 0, high = arr.length - 1;
		while (low <= high) {
			int mid = low + (high - low) / 2;

			if (arr[mid] == searchElement)
				return mid;

			if (arr[mid] < searchElement)
				low = mid + 1;

			else
				high = mid - 1;
		}
		return -1;
	}

	public static void main(String[] args) {
		double[] arr = { 9.0, 4.0, 6.0, 8.0, 1.8, 2.2 };

		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));

		double searchData = 61.0;

		int searchResult = search(arr, searchData);

		if (searchResult == -1)
			System.out.println(searchData + " not found in the array and result is " + searchResult);
		else
			System.out.println(searchData + " found in the array and position is " + searchResult);

	}

}
