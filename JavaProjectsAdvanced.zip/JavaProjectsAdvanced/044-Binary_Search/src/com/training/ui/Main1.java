package com.training.ui;

public class Main1 {
	
	private static int search(int[] arr, int searchElement) {
		
		int low = 0, high = arr.length - 1;
		while (low <= high) {
			int mid = low + (high - low) / 2;
			
			if(arr[mid] == searchElement)
				return mid;
			
			if(arr[mid] < searchElement)
				low = mid + 1;
			
			else
				high = mid - 1;
		}
		return -1;
	}

	public static void main(String[] args) {
		int arr[] = {2,4,6,8,10,11,12};
		int searchData = 11;
		
		int searchResult = search(arr, searchData);
		
		if(searchResult == -1)
			System.out.println(searchData + " not found in the array and result is "+searchResult);
		else
			System.out.println(searchData + " found in the array and position is "+searchResult);
	}

}
