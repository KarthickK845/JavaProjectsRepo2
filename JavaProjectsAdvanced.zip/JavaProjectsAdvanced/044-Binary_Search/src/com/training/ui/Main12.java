package com.training.ui;

import java.util.Arrays;
import java.util.Comparator;

import com.training.model.Employee;
import com.training.model.Manager;
import com.training.model.SalesEmployee;
import com.training.model.comparators.EmployeeBasicSalaryDescendingComparator;

public class Main12 {

	private static int search(Employee[] arr, Employee searchElement) {

		int low = 0, high = arr.length - 1;
		while (low <= high) {
			int mid = low + (high - low) / 2;
			
			Comparator comparator = new EmployeeBasicSalaryDescendingComparator();
			int r = comparator.compare(arr[mid], searchElement);
			if(r==0)
				return mid;
			
			if(r<0)
				low = mid + 1;

			else
				high = mid - 1;
		}
		return -1;
	}
	
	public static void main(String[] args) {
		Employee emp = new Employee(101, "Rajni", "Female", "Calicut", 10000.00);
		Manager mgr = new Manager(103,"Mala","Female","Kochi",80000.00,10);
		SalesEmployee semp = new SalesEmployee(105, "Krishna", "Male", "Trichy", 3000.00, 200000.00);
		SalesEmployee semp1 = new SalesEmployee(102, "Varun", "Male", "Thrissur", 2500.00, 100000.00);

		Employee[] employees = {emp, mgr, semp, semp1};
		
		Arrays.sort(employees,new EmployeeBasicSalaryDescendingComparator());
		System.out.println(Arrays.toString(employees));
		
		Employee searchObject = new Manager(103,"Mala","Female","Kochi",8000.00,10);
		int searchResult = search(employees, searchObject);

		if (searchResult == -1)
			System.out.println("Search object was not found and the search result is  " + searchResult);
		else
			System.out.println("Search object " + searchObject + " is present at position " + searchResult);

	}

}
