package com.training.ui;

import java.util.Arrays;

import com.training.model.Person;

public class Main13 {

	private static int search(Person[] arr, Person searchElement) {

		int low = 0, high = arr.length - 1;
		while (low <= high) {
			int mid = low + (high - low) / 2;
			
			int r = arr[mid].compareTo(searchElement);
			if(r==0)
				return mid;
			
			if(r<0)
				low = mid + 1;

			else
				high = mid - 1;
		}
		return -1;
	}
	
	public static void main(String[] args) {
		Person p1 = new Person("Karthi", 23);
		Person p2 = new Person("Ram", 30);
		
		Person[] persons = {p1, p2, new Person("Mustafa",33), new Person("Manu", 30)};
		
		Arrays.sort(persons);
		System.out.println(Arrays.toString(persons));
		
		Person searchObject = new Person("Maaran", 30);
		int searchResult = search(persons, searchObject);
		
		

		if (searchResult == -1)
			System.out.println("Search object was not found and the search result is  " + searchResult);
		else
			System.out.println("Search object " + searchObject + " is present at position " + searchResult);

	}

}
