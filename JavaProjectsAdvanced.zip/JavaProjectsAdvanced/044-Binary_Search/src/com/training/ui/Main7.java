package com.training.ui;

import java.util.Arrays;
import java.util.Comparator;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;

public class Main7 {
	
	private static int search(BillItem[] arr, BillItem searchElement) {

		int low = 0, high = arr.length - 1;
		while (low <= high) {
			int mid = low + (high - low) / 2;
			Comparator comparator = new BillItemPriceComparator();
			int r = comparator.compare(arr[mid], searchElement);
			if(r==0)
				return mid;
			
			if(r<0)
				low = mid + 1;

			else
				high = mid - 1;
		}
		return -1;
	}

	public static void main(String[] args) {
		BillItem b1 = new BillItem("OPPO",5,25000.00);
		BillItem b2 = new BillItem("Samsung",15,10000.00);

		BillItem[] billItems = { b1, b2, new BillItem("iPhone",25,3000.00), new BillItem("vivo",50,35000.00) };

		BillItem searchObject = new BillItem("imap",25,10000.00);
		
		Arrays.sort(billItems,new BillItemPriceComparator());
		System.out.println(Arrays.toString(billItems));
		
		int searchResult = search(billItems, searchObject);
		if (searchResult == -1)
			System.out.println(searchObject + " not found in the array and result is " + searchResult);
		else
			System.out.println(searchObject + " found in the array and position is " + searchResult);

	}

}
