package com.training.ui;

import java.util.Arrays;

import com.training.model.Circle;

public class Main3 {
	
	private static int search(Circle[] arr, Circle searchElement) {

		int low = 0, high = arr.length - 1;
		while (low <= high) {
			int mid = low + (high - low) / 2;

			int r = arr[mid].compareTo(searchElement);
			if(r==0)
				return mid;
			
			if(r<0)
				low = mid + 1;

			else
				high = mid - 1;
		}
		return -1;
	}

	public static void main(String[] args) {
		Circle c1 = new Circle(10);
		Circle c2 = new Circle(13);
		
		Circle[] circles = {c1, c2, new Circle(2), new Circle(5), new Circle(15)};

		Circle searchObject = new Circle(2);
		
		Arrays.sort(circles);
		System.out.println(Arrays.toString(circles));
		
		int searchResult = search(circles, searchObject);

		if (searchResult == -1)
			System.out.println(searchObject + " not found in the array and result is " + searchResult);
		else
			System.out.println(searchObject + " found in the array and position is " + searchResult);
	}

}
