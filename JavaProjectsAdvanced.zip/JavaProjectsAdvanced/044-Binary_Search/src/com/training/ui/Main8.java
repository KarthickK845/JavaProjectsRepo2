package com.training.ui;

import java.util.Arrays;

import com.training.model.Account;

public class Main8 {
	
	private static int search(Account[] arr, Account searchElement) {

		int low = 0, high = arr.length - 1;
		while (low <= high) {
			int mid = low + (high - low) / 2;
			
			int r = arr[mid].compareTo(searchElement);
			if(r==0)
				return mid;
			
			if(r<0)
				low = mid + 1;

			else
				high = mid - 1;
		}
		return -1;
	}

	public static void main(String[] args) {
		Account a1 = new Account("Reema", 200000.00);
		Account a2 = new Account("Kevin", 40000.00);

		Account[] accounts = { a1, a2, new Account("Melvin", 30000.00), new Account("Rahul", 50000.00) };
		
		Arrays.sort(accounts);
		System.out.println(Arrays.toString(accounts));
		
		Account searchObject = new Account("Melvin", 300000.00);
		int searchResult = search(accounts, searchObject);

		if (searchResult == -1)
			System.out.println("Search object was not found and the search result is  " + searchResult);
		else
			System.out.println("Search object " + searchObject + " is present at position " + searchResult);

	}

}
