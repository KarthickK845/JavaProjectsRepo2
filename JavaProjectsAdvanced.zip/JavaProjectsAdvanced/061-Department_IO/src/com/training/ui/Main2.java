package com.training.ui;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;

import com.training.model.Department;

public class Main2 {

	public static void main(String[] args) {
		try {
			Department department = null;
			// deserialize

			InputStream is = new FileInputStream("department.dat");
			ObjectInputStream ois = new ObjectInputStream(is);

			department = (Department) ois.readObject();

			department.printReport();

			ois.close();
			is.close();
		} catch (Exception e) {
			System.err.println(e);
			System.exit(0);
		}
	}

}
