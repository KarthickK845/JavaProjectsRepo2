package com.training.ui;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import com.training.model.Department;
import com.training.util.ConsoleIO;

public class Main1 {

	public static void main(String[] args) throws IOException {

		String name;
		String managerName;

		System.out.print("Enter Department Name : ");
		name = ConsoleIO.inputString();

		System.out.print("Enter Manager Name : ");
		managerName = ConsoleIO.inputString();

		char anymore;

		Department department = new Department(name, managerName);

		do {
			int id;
			String empname;
			String gender;
			String cityName;
			double basic;

			System.out.print("Enter employee ID : ");
			id = ConsoleIO.inputInt();

			System.out.print("Enter employee name : ");
			empname = ConsoleIO.inputString();

			System.out.print("Enter employee gender : ");
			gender = ConsoleIO.inputString();

			System.out.print("Enter employee city name : ");
			cityName = ConsoleIO.inputString();

			System.out.print("Enter basic salary : ");
			basic = ConsoleIO.inputDouble();

			department.addEmployee(id, empname, gender, cityName, basic);

			System.out.print("Add More Employees ? : ");
			anymore = ConsoleIO.inputChar();
		} while (anymore == 'Y' || anymore == 'y');

		department.printReport();

		// serialize the department object to a file
		OutputStream os = new FileOutputStream("department.dat");
		ObjectOutputStream oos = new ObjectOutputStream(os);

		oos.writeObject(department);

		oos.flush();
		oos.close();
		os.close();
	}

}
