package com.training.ui;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class Main01 {

	public static void main(String[] args) throws IOException {
		InputStream is;
		is = new FileInputStream("hello.txt");

		while (true) {
			int i = is.read();  //reads ASCII value of each character
			if (i == -1)
				break;
			char ch = (char) i; //converting ASCII into character
			System.out.print(ch);
		}
		
		//its important to close the File after reading
		is.close();
	}

}
