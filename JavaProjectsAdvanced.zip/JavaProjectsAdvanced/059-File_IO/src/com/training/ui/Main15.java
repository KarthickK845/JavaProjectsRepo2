package com.training.ui;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import com.training.model.CourseItem;

public class Main15 {

	public static void main(String[] args) {
		
		try {
		CourseItem courseItem = new CourseItem("HTML", 30, 1800);
		CourseItem courseItem1 = new CourseItem("JAVA",50,3000);
		CourseItem courseItem2 = new CourseItem("CSS", 20, 1000);
		
		List<CourseItem> courseItems = new ArrayList<>();
		
		courseItems.add(courseItem);
		courseItems.add(courseItem1);
		courseItems.add(courseItem2);
		
		
		
		//write the above object into a file
		OutputStream os = new FileOutputStream("courseitem.dat");
		ObjectOutputStream oos = new ObjectOutputStream(os);
		
		oos.writeObject(courseItems);
		
		oos.flush();
		oos.close();
		os.close();
	}
	catch(Throwable e) {
		System.err.println(e.getMessage());
		System.out.println(e);
		System.exit(0);
	}
		

	}

}
