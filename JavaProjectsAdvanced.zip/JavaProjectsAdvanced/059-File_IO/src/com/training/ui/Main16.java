package com.training.ui;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;

import com.training.model.CourseItem;

public class Main16 {

	public static void main(String[] args) {
		try {

			CourseItem courseItem = null;

			// read the object from file and print
			InputStream is = new FileInputStream("courseitem.dat");
			ObjectInputStream ois = new ObjectInputStream(is);
			
			courseItem = (CourseItem) ois.readObject();
			
			System.out.println(courseItem);

			ois.close();
			is.close();
		} catch (Exception e) {
			System.err.println(e);
			System.exit(0);
		}

	}

}
