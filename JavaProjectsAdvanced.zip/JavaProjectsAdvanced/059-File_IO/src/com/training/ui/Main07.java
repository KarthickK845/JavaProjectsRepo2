package com.training.ui;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class Main07 {

	public static void main(String[] args) throws IOException {
		InputStream is = null;
		Reader reader = null;
		BufferedReader br = null;

		try {
			is = new FileInputStream("hello.txt");
			reader = new InputStreamReader(is);
			br = new BufferedReader(reader);
		} catch (FileNotFoundException e) {
			System.err.println("Some Error while opening file");
			System.exit(0);
		} 
//		finally {
//			//to ensure proper closing of resources
//			if(is!=null) {
//				is.close();
//				
//			}
//			if(reader!=null) {
//				reader.close();
//				
//			}
//			if(br!=null) {
//				br.close();
//				
//			}
//		}

		while (true) {
			String str;
			try {
				str = br.readLine();  //reads a line of text
				if (str == null)
					break;
				System.out.println(str);
			} catch (IOException e) {
				System.err.println("Some Error while reading file");
				System.exit(0);
			} 

		}
		
		try {
			br.close();
			reader.close();
			is.close();
		} catch (IOException e) {
			System.err.println("Some Error while closing file");
			System.exit(0);
		}
		

	}

}
