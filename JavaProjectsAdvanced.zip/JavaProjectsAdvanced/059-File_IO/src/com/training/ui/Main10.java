package com.training.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.training.model.Employee;

public class Main10 {

	public static void main(String[] args) throws IOException {
		InputStream is = System.in;
		Reader reader = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(reader);
		
		int id;
		String name;
		String gender;
		String city;
		double basic;
		
		System.out.print("Enter your ID : ");
		String str = br.readLine();
		id = Integer.parseInt(str);
		
		System.out.print("Enter your name : ");
		name = br.readLine();
		
		System.out.print("Enter your gender : ");
		gender = br.readLine();
		
		System.out.print("Enter your city : ");
		city = br.readLine();
		
		System.out.print("Enter your basic : ");
		str = br.readLine();
		basic = Double.parseDouble(str);
		
		Employee emp = new Employee();
		emp.setId(id);
		emp.setName(name);
		emp.setGender(gender);
		emp.setCityName(city);
		emp.setBasic(basic);
		
		Double netSal = emp.getNetSalary();
		System.out.println("Net Salary of "+emp.getName()+" : "+netSal);
		
		System.out.println("Employee Details : \n"+ emp.toString());

	}

}
