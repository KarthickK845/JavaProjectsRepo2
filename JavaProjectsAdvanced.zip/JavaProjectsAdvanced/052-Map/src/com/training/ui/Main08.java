package com.training.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.training.model.Employee;

public class Main08 {

	public static void main(String[] args) {
		Employee e1 = new Employee(10, "Rama", "Male", "Bangalore", 10000.00);
		Employee e2 = new Employee(11, "Sumathi", "Female", "Chennai", 15000.00);
		Employee e3 = new Employee(12, "Pruthvi", "Male", "Bangalore", 11000.00);
		Employee e4 = new Employee(13, "Santhosh", "Male", "Bangalore", 32000.00);
		Employee e5 = new Employee(14, "Manu", "Female", "Mumbai", 23000.00);
		Employee e6 = new Employee(15, "Renu", "Female", "Mumbai", 14000.00);
		Employee e7 = new Employee(16, "Sundari", "Female", "Chennai", 16000.00);
		Employee e8 = new Employee(17, "Mahesh", "Male", "Bangalore", 20000.00);
		Employee e9 = new Employee(19, "Venky", "Male", "Chennai", 42000.00);
		Employee e10 = new Employee(18, "Vicky", "Male", "Mumbai", 41000.00);
		
		List<Employee> allEmployees = new LinkedList<>();
		allEmployees.add(e1);
		allEmployees.add(e2);
		allEmployees.add(e3);
		allEmployees.add(e4);
		allEmployees.add(e5);
		allEmployees.add(e6);
		allEmployees.add(e7);
		allEmployees.add(e8);
		allEmployees.add(e9);
		allEmployees.add(e10);
		
		Map<String, List<Employee>> map = new HashMap<>();
		
		for(Employee e:allEmployees) {
			String cityName = e.getCityName();
			if(map.containsKey(cityName)) {
				List<Employee> empList = map.get(cityName);
				empList.add(e);
				
			}
			else {
				map.put(cityName, new ArrayList<>());
				List<Employee> empList = map.get(cityName);
				empList.add(e);
			}
		}

		//System.out.println(map);
		
		for(Map.Entry<String, List<Employee>> entry:map.entrySet()) {
			System.out.println("City Name : "+entry.getKey());
			System.out.println("==================================================");
			System.out.println("SL NO	NAME     GENDER	 BASIC SALARY	NET SALARY");
			System.out.println("--------------------------------------------------");
			List<Employee> empList = entry.getValue();
			int slno = 1;
			double totalBasic = 0.0, totalNet = 0.0;
			for(Employee e:empList) {
				System.out.printf("%d.  %9s\t %6s %12.2f  %12.2f \n",
									slno++, 
									e.getName(), 
									e.getGender(), 
									e.getBasic(),
									e.getNetSalary());
				
				totalBasic+=e.getBasic();
				totalNet+=e.getNetSalary();
			}
			
			System.out.println("---------------------------------------------------");
			System.out.printf("Employee Count in City : %7d \n",empList.size());
			System.out.printf("Total Basic Salary     : %10.2f \n",totalBasic);
			System.out.printf("Total Net Salary       : %10.2f \n",totalNet);
			System.out.println("===================================================");
			System.out.println();
			System.out.println();
		}
	}

}
