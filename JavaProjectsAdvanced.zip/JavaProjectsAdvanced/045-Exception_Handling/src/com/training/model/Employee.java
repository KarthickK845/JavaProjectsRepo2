package com.training.model;

public class Employee {

	private double basicSalary;

	public double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(double basicSalary) throws Exception {
		if(basicSalary<0) {
		//	RuntimeException e = new RuntimeException("Incorrect basicSalary "+basicSalary);
			
			//add throws to method signature as we throw unchecked exception
			Exception e = new Exception("Incorrect basicSalary "+basicSalary);
			throw e;
			
		}
		this.basicSalary = basicSalary;
	}
	
	public double computeAllowance() {
		return this.basicSalary*0.35;
	}
}
