package com.training.ui;

public class Main07 {

	public static void main(String[] args) {

		System.out.println("Program Begins....");
		
		try {
			System.out.println(100/10);
			int[] arr = {1,2,3,4};
			System.out.println(arr[1]);
			System.out.println(Integer.parseInt("125"));
			String str = null;
			System.out.println(str.length());
			
		}
		catch(NumberFormatException e) {  //specific exception handler 
			e.printStackTrace();
		}
		catch(Throwable e) {		//called generic exception handler - parent of all Exception classes
			e.printStackTrace();
		}
		finally {
			System.out.println("Thank you");
		}
		
		System.out.println("Program Ends....");

	}

}
