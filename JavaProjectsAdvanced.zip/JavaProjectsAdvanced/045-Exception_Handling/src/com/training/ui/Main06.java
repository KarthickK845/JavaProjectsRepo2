package com.training.ui;

public class Main06 {

	public static void main(String[] args) {
		System.out.println("Program Begins....");
		
		try {
			System.out.println(100/10);
			int[] arr = {1,2,3,4};
			System.out.println(arr[1]);
			System.out.println(Integer.parseInt("125"));
			String str = null;
			System.out.println(str.length());
			
		}
		catch(NumberFormatException e) {
			e.printStackTrace();
		}
		
		catch(Throwable e) {		//parent of all Exception classes
			System.out.println("Some Error Occurred");
			System.out.println("Continuing...");
		}
		finally {
			System.out.println("Good Bye");
		}
		
		System.out.println("Program Ends....");

	}

}
