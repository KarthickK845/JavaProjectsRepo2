package com.training.ui;

import com.training.model.Student;

public class Main10 {

	public static void main(String[] args) throws Exception {
		// Task 2
		Student s = new Student();
		try {
			s.setMark(100);
			s.setName("Arjun");
			s.setGrade('E');
		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println(e);
		}
		System.out.println("Student mark : " + s.getMark());

		// s.setName(null); //compiler forces to add throws or handle using try catch

		System.out.println("Student name : " + s.getName());

		System.out.println("Student grade : " + s.getGrade());
	}

}
