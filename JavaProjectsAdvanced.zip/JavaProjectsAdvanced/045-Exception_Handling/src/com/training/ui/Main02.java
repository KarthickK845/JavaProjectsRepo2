package com.training.ui;

public class Main02 {

	public static void main(String[] args) {
		System.out.println("Program Begins....");

		int[] arr = {1,2,3,4,5};
		//System.out.println(arr[41]);  //java.lang.ArrayIndexOutOfBoundsException: Index 41 out of bounds for length 5

		//exception handling
		try {
			System.out.println(arr[41]);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Invalid index");
			System.out.println("Continuing....");
		}
		
		System.out.println("Program Ends....");
	}

}
