package com.training.ui;

public class Main08 {

	public static void main(String[] args) {
		System.out.println("Program Begins....");
		
		try {
			System.out.println(100/10);
			int[] arr = {1,2,3,4};
			System.out.println(arr[1]);
			System.out.println(Integer.parseInt("125"));
			String str = null;
			System.out.println(str.length());
			
		}
		catch(NumberFormatException | NullPointerException | ArrayIndexOutOfBoundsException | ArithmeticException e) {
			if(e instanceof NumberFormatException) {
				System.out.println("Number format is invalid");
			}
			if(e instanceof NullPointerException) {
				System.out.println("Null value encountered");
			}
			if(e instanceof ArrayIndexOutOfBoundsException) {
				System.out.println("Invalid Index");
			}
			if(e instanceof ArithmeticException) {
				System.out.println("Invalid Division");
			}
		}
		
		finally {
			System.out.println("Good Bye");
		}
		
		System.out.println("Program Ends....");

	}

}
