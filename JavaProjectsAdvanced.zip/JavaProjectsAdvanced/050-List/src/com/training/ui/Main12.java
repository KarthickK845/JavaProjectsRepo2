package com.training.ui;

import com.training.model.Department;

public class Main12 {

	public static void main(String[] args) {
		Department department = new Department("IT", "Leela");
		department.addEmployee(101, "Naina", "Female", "Delhi", 1000.00);
		department.addEmployee(103, "Deepa", "female", "Kochi", 2000.00);
		department.addEmployee(104, "Shreeman", "Male", "Chennai", 5000.00);
		department.addEmployee(102, "Ruban", "MALE", "Raichur", 4000.00);
		
		//System.out.println(department.isEmployeePresent(110));
		//System.out.println(department.findByEmployeeId(110));
		department.printReport();
		
		department.updateEmployee(102, "Sree Hari", "Male", "Cochin", 5000.00);
		department.printReport();
		
		department.deleteEmployee(102);
		department.printReport();
	}

}
