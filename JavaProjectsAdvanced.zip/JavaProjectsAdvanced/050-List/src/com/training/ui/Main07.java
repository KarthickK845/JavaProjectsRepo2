package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.Circle;

public class Main07 {

	public static void main(String[] args) {
		List<Circle> circles = new LinkedList<>();
		
		Circle c1 = new Circle(20);
		
		circles.add(c1);
		circles.add(new Circle(20));
		circles.add(new Circle(40));
		circles.add(new Circle(50));
		circles.add(new Circle(87));
		
		System.out.println(circles);
		//below returns true only if we had overridden equals method
		System.out.println(circles.contains(new Circle(40)));

		circles.set(1, new Circle(1000));
		circles.remove(new Circle(50));
		
		System.out.println(circles);
		
		Circle minCircle = circles.get(0);
		Circle maxCircle = circles.get(0);
		
		for(int i = 0; i<circles.size();i++) {
			int r = circles.get(i).getRadius();
			if(minCircle.getRadius()>r) {
				minCircle = circles.get(i);
			}
			
			if(maxCircle.getRadius()<r) {
				maxCircle = circles.get(i);
			}
		}
		
		System.out.println("Smallest Circle : "+minCircle);
		System.out.println("Largest Circle : "+maxCircle);
		System.out.println("=============================");
		for(Circle c : circles) {
			int r = c.compareTo(minCircle);
			if(r<0)
				minCircle = c;
			
			r = c.compareTo(maxCircle);
			if(r>0)
				maxCircle = c;
		}
		
		System.out.println("Smallest Circle : "+minCircle);
		System.out.println("Largest Circle : "+maxCircle);
	}

}
