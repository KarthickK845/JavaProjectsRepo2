package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.BillItem;

public class Main08 {

	public static void main(String[] args) {
		List<BillItem> billItems = new LinkedList<>();
		
		BillItem b1 = new BillItem("OPPO",5,25000.00);
		BillItem b2 = new BillItem("Samsung",15,10000.00);

		billItems.add(b1);
		billItems.add(b2); 
		billItems.add(new BillItem("iPhone",25,3000.00));
		billItems.add(new BillItem("vivo",50,35000.00));

		System.out.println("---------------------------------------------------------");
		System.out.println("Sl no\tItem Name\tQuantity  Price\t   \tValue");
		System.out.println("---------------------------------------------------------");
		
		int slNo = 1;
		double sum = 0.0;
		for(BillItem b : billItems) {
			System.out.println(slNo+".\t"+b.getItemName()+"\t\t"+b.getQuantity()+"\t  "+b.getPrice()+"\t"+b.getItemValue());
			sum+=b.getItemValue();
			slNo++;
		}
		
		System.out.println("----------------------------------------------------------");
		System.out.println("Total Number of items: "+billItems.size()+"\tBill Amount: "+sum);
		System.out.println("----------------------------------------------------------");
	}

}
