package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.Person;

public class Main09 {

	public static void main(String[] args) {
		List<Person> persons = new LinkedList<>();
		persons.add(new Person("Kiran",24));
		persons.add(new Person("Kamal",14));
		persons.add(new Person("Krishna",42));
		persons.add(new Person("Rishi",20));
		persons.add(new Person("Rukmini",74));

		System.out.println("---------------------");
		System.out.println("Sl no\tName\tAge");
		System.out.println("---------------------");
		
		int slNo = 1;
		Person youngPerson = persons.get(0);
		Person elderPerson = persons.get(0);
		
		for(Person p : persons) {
			System.out.println(slNo+".\t"+p.getName()+"\t"+p.getAge());
			
			int r = p.compareTo(youngPerson);
			if(r<0)
				youngPerson = p;
			
			r = p.compareTo(elderPerson);
			if(r>0)
				elderPerson = p;
			
			slNo++;
		}
		
		System.out.println("-----------------------");
		System.out.println("Youngest Person : "+youngPerson.getName());
		System.out.println("Eldest Person : "+elderPerson.getName());
		System.out.println("-----------------------");
	}

}
