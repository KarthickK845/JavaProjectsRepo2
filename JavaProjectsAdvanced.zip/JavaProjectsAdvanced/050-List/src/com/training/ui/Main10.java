package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.Account;

public class Main10 {

	public static void main(String[] args) {
		List<Account> accounts = new LinkedList<>();
		accounts.add(new Account("Ram", 1000.00));
		accounts.add(new Account("Meena", 2000.00));
		accounts.add(new Account("Ragu", 3000.00));
		accounts.add(new Account("Sheela", 4000.00));
		
		System.out.println(accounts.contains(new Account("Meena",1000.00)));
		
		System.out.println(accounts.contains(new Account("Reshmi",2000.00)));

	}

}
