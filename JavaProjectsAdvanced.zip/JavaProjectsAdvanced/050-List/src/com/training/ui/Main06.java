package com.training.ui;

import java.util.ArrayList;
import java.util.List;

public class Main06 {

	public static void main(String[] args) {
		List<Float> prices = new ArrayList<>();

		System.out.println(prices);
		System.out.println(prices.size());
		System.out.println(prices.isEmpty());

		prices.add(Float.valueOf(66.6f));
		prices.add(Float.valueOf(21.5f));
		prices.add(Float.valueOf(19.2f));
		prices.add(Float.valueOf(222.8f));
		prices.add(Float.valueOf(70.6f));
		prices.add(90.0f);
		prices.add(199.00f);
		
		Float min = prices.get(0);
		Float max = prices.get(0);
		for(int i = 0; i<prices.size();i++) {
			
			if(min>prices.get(i)) {
				min = prices.get(i);
			}
			
			if(max<prices.get(i)) {
				max = prices.get(i);
			}
		}

		System.out.println("Minimum value:"+min);
		System.out.println("Maximum value:"+max);
	}

}
