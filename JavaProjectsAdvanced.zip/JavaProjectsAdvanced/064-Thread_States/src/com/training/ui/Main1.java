package com.training.ui;

import com.training.task.OddNumberPrintingTask;
import com.training.workers.CityNamePrintingThread;
import com.training.workers.SumFindingThread;

public class Main1 {

	public static void main(String[] args) throws InterruptedException {
		Thread t1 = new CityNamePrintingThread();		//new state
		t1.setName("CNPT");
		t1.start();       //Runnable
		
		Runnable r1 = new OddNumberPrintingTask(30, 50);
		Thread t2 = new Thread(r1, "ONPT");
		t2.start();
		
		//Create a Thread (SumFindingThread) and start
		Runnable r2 = new SumFindingThread("SFT", 0, 20);
		Thread t3 = new Thread(r2,"SFT");
		t3.start();
		
		t1.join();   //let t1 complete execution and then let next thread (say main) join
		t2.join(); //inter thread communication
		
		//call join on thread t3
		t3.join();
		
		for(int i=1; i<=5; i++) {
			System.out.println(Thread.currentThread().getName()+" : "+i);
		}
		
		System.out.println(t1.isAlive());
		System.out.println(t2.isAlive());
		System.out.println(t3.isAlive());

	}

}
