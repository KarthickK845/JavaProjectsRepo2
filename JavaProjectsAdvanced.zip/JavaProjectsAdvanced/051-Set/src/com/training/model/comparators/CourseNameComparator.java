package com.training.model.comparators;

import java.util.Comparator;

import com.training.model.Course;

public class CourseNameComparator{
}
