package com.training.ui;

import java.util.Set;
import java.util.TreeSet;

public class Main6 {

	public static void main(String[] args) {
		Set<Integer> set = new TreeSet<>();
		//implementation of Binary sort
		//orders to ascending
		//can only add comparable objects as it does the sorting naturally
		set.add(Integer.valueOf(200));
		set.add(Integer.valueOf(10));
		set.add(Integer.valueOf(30));
		set.add(Integer.valueOf(400));
		set.add(Integer.valueOf(300));
		set.add(Integer.valueOf(20));

		System.out.println(set);
		
		
	}

}
