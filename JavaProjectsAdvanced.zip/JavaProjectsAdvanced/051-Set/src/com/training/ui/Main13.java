package com.training.ui;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.training.model.Square;
import com.training.model.comparators.SquareComparator;

public class Main13 {

	public static void main(String[] args) {
		SquareComparator comparator = new SquareComparator();
		
		Set<Square> squares = new TreeSet<>(comparator);
		// if HashSet then doesn't throw any exception
		squares.add(new Square(10)); //throws ClassCastException for TreeSet as it does not implement Comparable
		//so it cannot be compared
		squares.add(new Square(5));
		squares.add(new Square(20));
		squares.add(new Square(16));
		
		System.out.println(squares);
	
		System.out.println(squares.contains(new Square(20)));  //compareTo method is used for comparing the values(objects) in a Set to another object
		//whereas in HashSet - equals method is used for this comparison 
	}

}
