package com.training.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.training.model.Account;

public class Main4 {

	public static void main(String[] args) {
		Set<Account> accSet = new HashSet<>();
		accSet.add(new Account("Ramesh", 1000.00));
		accSet.add(new Account("Suresh", 2000.00));
		accSet.add(new Account("Rishi", 10000.00));
		accSet.add(new Account("Ragu", 3000.00));
		accSet.add(new Account("Sumathi", 5000.00));
		accSet.add(new Account("Rishi", 7000.00));
		
		System.out.println(accSet);
		
		Account searchAcc = new Account("Ragu", 4000.00);
		System.out.println(accSet.contains(searchAcc));
		
		accSet.remove(new Account("Suresh", 5000.00));
		System.out.println(accSet);
		
		double sum = 0.0;
		Iterator<Account> it = accSet.iterator();
		while(it.hasNext()) {
			Account acc = it.next();
			sum=sum+acc.getBalance();
		}
		
		System.out.println(sum);
		
		accSet.clear();
		System.out.println(accSet.size());
		System.out.println(accSet.isEmpty());
		System.out.println(accSet.size());
	}

}
