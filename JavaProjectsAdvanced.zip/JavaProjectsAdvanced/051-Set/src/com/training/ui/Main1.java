package com.training.ui;

import java.util.HashSet;
import java.util.Set;

public class Main1 {

	public static void main(String[] args) {
		Set<Integer> set = new HashSet<>();
		//does not maintain insertion order
		set.add(Integer.valueOf(200));
		set.add(Integer.valueOf(10));
		set.add(Integer.valueOf(30));
		set.add(Integer.valueOf(400));
		set.add(Integer.valueOf(300));
		set.add(Integer.valueOf(200));  //duplicate does not get added

		System.out.println(set);
		System.out.println(set.size());
		System.out.println("isEmpty ? "+set.isEmpty());
		System.out.println(set.contains(Integer.valueOf(200)));
		set.remove(Integer.valueOf(30));
		System.out.println(set);
		System.out.println(set.size());
		set.clear();
		System.out.println(set.isEmpty());
		System.out.println(set.size());

	}

}
