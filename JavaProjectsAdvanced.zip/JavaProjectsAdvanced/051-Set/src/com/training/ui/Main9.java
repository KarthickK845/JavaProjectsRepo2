package com.training.ui;

import java.util.Set;
import java.util.TreeSet;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemQuantityComparator;

public class Main9 {

	public static void main(String[] args) {
		BillItemQuantityComparator comparator = new BillItemQuantityComparator();
		Set<BillItem> billItemSet = new TreeSet<>(comparator);
		
		billItemSet.add(new BillItem("Redmi", 10, 10000.00));
		billItemSet.add(new BillItem("Oppo", 15, 15000.00));
		billItemSet.add(new BillItem("Lenovo", 12, 12000.00));
		billItemSet.add(new BillItem("Redmi", 20, 40000.00));
		billItemSet.add(new BillItem("OnePlus", 25, 50000.00));
		billItemSet.add(new BillItem("VIVO", 50, 25000.00));
		
		System.out.println(billItemSet.size());
		System.out.println(billItemSet);

	}

}
