package com.training.ui;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Main7 {

	public static void main(String[] args) {
		Set<String> set = new TreeSet<>();
		
		set.add("Ganesh");
		set.add("Ravi");
		set.add("Chandru");
		set.add("Munish");
		set.add("Sundar");
		set.add("Ravi");

		System.out.println(set);
		System.out.println("Contains ? "+set.contains("Chandru"));
		
		set.remove("Sundar");
		
		Iterator<String> it = set.iterator();
		while(it.hasNext()) {
			String s = it.next();
			System.out.println(s.toUpperCase()+"\t"+s.length());
		}
		
		set.clear();
		System.out.println(set.isEmpty());
		System.out.println(set.size());
	}

}
