package com.training.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Main3 {

	public static void main(String[] args) {
		
		Set<String> set = new HashSet<>();
		
		set.add("Ganesh");
		set.add("Ravi");
		set.add("Chandru");
		set.add("Munish");
		set.add("Sundar");
		set.add("Ravi");
		
		System.out.println(set);
		System.out.println("Contains ? "+set.contains("Chandru"));
		
		set.remove("Ravi");
		
		Iterator<String> it = set.iterator();
		while(it.hasNext()) {
			String s = it.next();
			System.out.println(s.toUpperCase()+"\t"+s.length());
		}
		
		set.clear();
		System.out.println(set.isEmpty());
		System.out.println(set.size());

	}

}
