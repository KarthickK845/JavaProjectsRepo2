package com.training.ui;

import java.util.Set;
import java.util.TreeSet;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;

public class Main10 {

	public static void main(String[] args) {
		BillItemPriceComparator comparator = new BillItemPriceComparator();
		Set<BillItem> billItemSet = new TreeSet<>(comparator);
		
		billItemSet.add(new BillItem("Redmi", 10, 10000.00));
		billItemSet.add(new BillItem("Oppo", 15, 15000.00));
		billItemSet.add(new BillItem("Lenovo", 12, 12000.00));
		billItemSet.add(new BillItem("Redmi", 20, 40000.00));
		billItemSet.add(new BillItem("OnePlus", 25, 50000.00));
		billItemSet.add(new BillItem("VIVO", 50, 25000.00));
		
		System.out.println(billItemSet.size());
		System.out.println(billItemSet);

	}

}
