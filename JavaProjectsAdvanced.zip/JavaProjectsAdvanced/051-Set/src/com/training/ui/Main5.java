package com.training.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;

public class Main5 {

	public static void main(String[] args) {
		Set<BillItem> billItemSet = new HashSet<>();
		
		billItemSet.add(new BillItem("Redmi", 10, 10000.00));
		billItemSet.add(new BillItem("Oppo", 15, 15000.00));
		billItemSet.add(new BillItem("Lenovo", 12, 12000.00));
		billItemSet.add(new BillItem("Redmi", 20, 40000.00));
		billItemSet.add(new BillItem("OnePlus", 25, 50000.00));
		billItemSet.add(new BillItem("VIVO", 50, 25000.00));
		
		System.out.println(billItemSet.size());
		System.out.println(billItemSet);
		
		BillItem searchbillItem = new BillItem("Oppo", 1, 1000.00);
		System.out.println(billItemSet.contains(searchbillItem));
		
		billItemSet.remove(new BillItem("Lenovo", 10, 20000.00));
		System.out.println(billItemSet);
		
		double total = 0.0;
		Iterator<BillItem> it = billItemSet.iterator();
		while(it.hasNext()) {
			BillItem billItem = it.next();
			total=total+billItem.getItemValue();
		}
		System.out.println(total);
		
		BillItemPriceComparator comparator = new BillItemPriceComparator();
		BillItem lowestPricedBillItem = new BillItem("", 0, 0.00);
		for(BillItem b : billItemSet) {
			int r = comparator.compare(b, lowestPricedBillItem);
			if(r<0)
				lowestPricedBillItem=b;
		}
		
		System.out.println(lowestPricedBillItem);
		
		billItemSet.clear();
		System.out.println(billItemSet.isEmpty());
	}

}
