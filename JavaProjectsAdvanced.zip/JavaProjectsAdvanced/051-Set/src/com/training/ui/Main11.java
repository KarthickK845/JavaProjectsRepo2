package com.training.ui;

import com.training.model.Bill;

public class Main11 {

	public static void main(String[] args) {
		Bill bill = new Bill(1065, "Atul Kulkarni");
		bill.addBillItem("Dell", 3, 32000.00);
		bill.addBillItem("HP", 2, 30000.00);
		bill.addBillItem("SONY", 1, 14000.00);
		bill.addBillItem("Lenovo", 5, 23000.00);
		bill.addBillItem("Acer", 6, 50000.00);
		
		bill.printBill();
	}

}
