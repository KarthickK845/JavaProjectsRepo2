package com.training.ui;

import java.util.ArrayList;
import java.util.List;

public class Main3 {

	public static void main(String[] args) throws InterruptedException {
		List<Integer> ilist = new ArrayList<>();
		
		Runnable runnable1 = () -> {
			synchronized (ilist) {
				for(int i = 1; i<=10; i++) 
					ilist.add(i);
				try {
					Thread.sleep(300);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			}
		};
		
		Runnable runnable2 = () -> {
			synchronized (ilist) {
				for(int i = 11; i<=20; i++) 
					ilist.add(i);
				 try {
					Thread.sleep(300);
				 } catch (InterruptedException e) {
					e.printStackTrace();
				 }
				
			}
		};
		
		Thread t1 = new Thread(runnable1, "t1");
		Thread t2 = new Thread(runnable2, "t2");
		t1.start();
		t2.start();
		
		t1.join();
		t2.join();
		
		System.out.println(ilist);
		System.out.println(ilist.size());
	}

}
