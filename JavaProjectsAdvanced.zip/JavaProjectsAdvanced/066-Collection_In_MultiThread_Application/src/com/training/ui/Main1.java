package com.training.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main1 {

	public static void main(String[] args) throws InterruptedException {
		//List<Integer> ilist = new ArrayList<>();
		List<Integer> ilist = Collections.synchronizedList(new ArrayList<>());
		
		Runnable runnable1 = () -> {
			for(int i = 0; i<1000; i++) {
				ilist.add(i);
			}
			System.out.println(ilist);
		};
		
		Runnable runnable2 = () -> {
			for(int i = 1000; i<2000; i++) {
				ilist.add(i);
			}
			System.out.println(ilist);
		};
		
		Thread t1 = new Thread(runnable1, "T1");
		Thread t2 = new Thread(runnable2, "T2");
		
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		
		System.out.println(ilist.size()); //main thread executes this
	}

}
