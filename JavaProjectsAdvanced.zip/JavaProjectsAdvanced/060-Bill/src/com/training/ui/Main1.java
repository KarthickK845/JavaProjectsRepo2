package com.training.ui;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import com.training.model.Bill;
import com.training.util.ConsoleIO;

public class Main1 {

	public static void main(String[] args) throws IOException {
		int billNumber;
		String customerName;

		System.out.print("Enter Bill Number : ");
		billNumber = ConsoleIO.inputInt();

		System.out.print("Enter Customer Name : ");
		customerName = ConsoleIO.inputString();

		char anymore;

		Bill bill = new Bill(billNumber, customerName);

		do {
			String itemName;
			int quantity;
			double price;

			System.out.print("Enter item name : ");
			itemName = ConsoleIO.inputString();

			System.out.print("Enter quantity : ");
			quantity = ConsoleIO.inputInt();

			System.out.print("Enter Price : ");
			price = ConsoleIO.inputDouble();

			bill.addBillItem(itemName, quantity, price);

			System.out.print("Add More Items ? : ");
			anymore = ConsoleIO.inputChar();
		} while (anymore == 'Y' || anymore == 'y');

		bill.printBill();
		
		//serialize the bill object to a file
		OutputStream os = new FileOutputStream("bill.dat");
		ObjectOutputStream oos = new ObjectOutputStream(os);
		
		oos.writeObject(bill);
		
		oos.flush();
		oos.close();
		os.close();
	}

	
}
