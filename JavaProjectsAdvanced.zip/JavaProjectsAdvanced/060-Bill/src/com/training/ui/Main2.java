package com.training.ui;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;

import com.training.model.Bill;

public class Main2 {

	public static void main(String[] args) {

		try {
			Bill bill = null;

			// deserialize the bill object from file
			InputStream is = new FileInputStream("bill.dat");
			ObjectInputStream ois = new ObjectInputStream(is);

			bill = (Bill) ois.readObject();

			bill.printBill();

			ois.close();
			is.close();
		} catch (Throwable e) {
			System.err.println(e);
			System.exit(0);
		}

	}

}
