package com.training.ui;

import java.util.LinkedList;
import java.util.List;

public class Main7 {

	public static void main(String[] args) {
		List<Integer> list = new LinkedList<>();
		
		list.add(Integer.valueOf(200));
		list.add(Integer.valueOf(40));
		list.add(Integer.valueOf(100));
		list.add(Integer.valueOf(20));
		list.add(Integer.valueOf(500));
		list.add(Integer.valueOf(800));
		list.add(Integer.valueOf(410));
		list.add(Integer.valueOf(100));
		list.add(Integer.valueOf(205));
		list.add(Integer.valueOf(500));
		
		list
			.stream()
			.limit(7)
			.forEach(i -> System.out.println(i));
		System.out.println("-------------------------------------");
		list
			.stream()
			.distinct()
			.forEach(i -> System.out.println(i));
		
	}

}
