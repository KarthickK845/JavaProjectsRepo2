package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.Circle;

public class Main1 {

	public static void main(String[] args) {
		List<Integer> list = new LinkedList<>();
		
		list.add(Integer.valueOf(200));
		list.add(Integer.valueOf(400));
		list.add(Integer.valueOf(100));
		list.add(Integer.valueOf(300));
		list.add(Integer.valueOf(500));
		
//		Consumer<Integer> printAction;
//		printAction = (i) -> System.out.println(i);
		
		list.forEach((i) -> System.out.println(i));
		
		List<String> cities = new LinkedList<>();
		cities.add("Pune");
		cities.add("Patna");
		cities.add("Kolkata");
		cities.add("Cochin");
		
//		Consumer<String> upperCaseAction;
//		upperCaseAction = (s) -> System.out.println(s.toUpperCase());
		
		cities.forEach((s) -> System.out.println(s.toUpperCase()));
		cities.forEach((s) -> System.out.println(s.length()));  //pass a consumer which prints the length of each city
	
		List<Circle> circles = new LinkedList<>();
		circles.add(new Circle(10));
		circles.add(new Circle(20));
		circles.add(new Circle(30));
		
		circles.forEach((c)->System.out.println(c.toString()));
		circles.forEach((c)->System.out.println(c.getRadius()+","+c.getArea()));
	}

}
