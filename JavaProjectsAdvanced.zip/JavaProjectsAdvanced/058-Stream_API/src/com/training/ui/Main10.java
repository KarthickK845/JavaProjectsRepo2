package com.training.ui;

import com.training.model.Course;

public class Main10 {

	public static void main(String[] args) {
		Course course=new Course("Diploma in Web Development");
		
		course.addCourseItem("Angular", 30, 4000.00);
		course.addCourseItem("HTML", 40, 4500.00);
		course.addCourseItem("CSS", 20, 2500.00);
		course.addCourseItem("jQuery", 35, 6000.00);
		course.addCourseItem("Knockout js", 15, 1500.00);

		System.out.println("Longest Duration Course : "+course.getLongestDurationCourseItem());
		System.out.println("Shortest Duration Course : "+course.getShortestDurationCourseItem());
		
		System.out.println("---------------------------------");
		
		System.out.println("Highest Priced Course : "+course.getHighestPricedCourseItem());
		System.out.println("Lowest Priced Course : "+course.getLowestPricedCourseItem());
	}

}
