package com.training.ui;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.training.model.Employee;
import com.training.model.comparators.EmployeeBasicSalaryAscendingComparator;

public class Main13 {

	public static void main(String[] args) {
		Employee e1 = new Employee(10, "Rama", "Male", "Bangalore", 10000.00);
		Employee e2 = new Employee(11, "Sumanth", "male", "Chennai", 15000.00);
		Employee e3 = new Employee(12, "Pruthvi", "Male", "Cochin", 11000.00);
		Employee e4 = new Employee(13, "Santhoshi", "Female", "Pune", 32000.00);
		Employee e5 = new Employee(14, "Manu", "feMALE", "Mumbai", 23000.00);
		Employee e6 = new Employee(15, "Renu", "female", "Chennai", 14000.00);
		Employee e7 = new Employee(16, "Sundari", "FEMALE", "Chennai", 16000.00);
		Employee e8 = new Employee(17, "Maheshwari", "Female", "Cochin", 20000.00);
		Employee e9 = new Employee(19, "Venky", "MALE", "Pune", 42000.00);
		Employee e10 = new Employee(18, "Vicky", "Male", "Mumbai", 41000.00);
		
		List<Employee> allEmployees = new LinkedList<>();
		allEmployees.add(e1);
		allEmployees.add(e2);
		allEmployees.add(e3);
		allEmployees.add(e4);
		allEmployees.add(e5);
		allEmployees.add(e6);
		allEmployees.add(e7);
		allEmployees.add(e8);
		allEmployees.add(e9);
		allEmployees.add(e10);
		
		List<Employee> maleEmps = allEmployees
			.stream()
			.sorted()
			.filter((e)->e.getGender().equalsIgnoreCase("Male"))
			.collect(Collectors.toList());
		
		
		
		System.out.println(maleEmps);
		System.out.println("-------------------------------------------");
		List<String> allNames = allEmployees
			.stream()
			.map(e->e.getName())
			.sorted()
			.collect(Collectors.toList());
		System.out.println(allNames);
		
		System.out.println("-------------------------------------------");
		
		List<Double> allBasicSalary = allEmployees
				.stream()
				.map(e->e.getBasic())
				.sorted()
				.collect(Collectors.toList());
		System.out.println(allBasicSalary);
		
		System.out.println("-------------------------------------------");
		
		List<String> allCities = allEmployees
				.stream()
				.map(e -> e.getCityName())
				.distinct()
				.collect(Collectors.toList());
		
		System.out.println(allCities);
		
		System.out.println("-------------------------------------------");
		
		double totalSalary;
		totalSalary = allEmployees
							.stream()
							.collect(Collectors.summingDouble(e -> e.getBasic()));
		System.out.println(totalSalary);
		
		System.out.println("-------------------------------------------");
		
		String result = allEmployees
							.stream()
							.map(Employee::toString)
							.collect(Collectors.joining(","));
		System.out.println(result);
		
		System.out.println("-------------------------------------------");
		
		Map<String,List<Employee>> map1 = allEmployees
			.stream()
			.collect(Collectors.groupingBy(Employee::getCityName));
		
		for(Map.Entry<String, List<Employee>> entry: map1.entrySet()) {
			System.out.println(entry.getKey());
			System.out.println("-------------------------------------------");
			List<Employee> empsInCity = entry.getValue();
			for(Employee e:empsInCity) {
				System.out.println(e.toString());
			}
			System.out.println("-------------------------------------------");
		}
		
		Map<String, Long> map2 = allEmployees
				.stream()
				.collect(Collectors.groupingBy(Employee::getCityName,Collectors.counting()));
		
		System.out.println(map2);
		
		Map<String, Double> map3 = allEmployees
				.stream()
				.collect(Collectors.groupingBy(Employee::getCityName, Collectors.summingDouble(Employee::getBasic)));
	
		System.out.println(map3);
		
		Map<Integer, String> map4;
		map4 = allEmployees
				.stream()
				.collect(Collectors.toMap(Employee::getId, Employee::getName));
		System.out.println(map4);
		
		allEmployees
			.stream()
			.forEach(System.out::println); //Terminal operation
		
		
	}

}
