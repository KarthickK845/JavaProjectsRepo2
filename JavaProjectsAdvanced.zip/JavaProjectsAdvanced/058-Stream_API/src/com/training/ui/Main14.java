package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.Employee;

public class Main14 {

	public static void main(String[] args) {
		Employee e1 = new Employee(10, "Rama", "Male", "Bangalore", 10000.00);
		Employee e2 = new Employee(11, "Sumanth", "male", "Chennai", 15000.00);
		Employee e3 = new Employee(12, "Pruthvi", "Male", "Cochin", 11000.00);
		Employee e4 = new Employee(13, "Santhoshi", "Female", "Pune", 32000.00);
		Employee e5 = new Employee(14, "Manu", "feMALE", "Mumbai", 23000.00);
		Employee e6 = new Employee(15, "Renu", "female", "Chennai", 14000.00);
		Employee e7 = new Employee(16, "Sundari", "FEMALE", "Chennai", 16000.00);
		Employee e8 = new Employee(17, "Maheshwari", "Female", "Cochin", 20000.00);
		Employee e9 = new Employee(19, "Venky", "MALE", "Pune", 42000.00);
		Employee e10 = new Employee(18, "Vicky", "Male", "Mumbai", 41000.00);
		
		List<Employee> allEmployees = new LinkedList<>();
		allEmployees.add(e1);
		allEmployees.add(e2);
		allEmployees.add(e3);
		allEmployees.add(e4);
		allEmployees.add(e5);
		allEmployees.add(e6);
		allEmployees.add(e7);
		allEmployees.add(e8);
		allEmployees.add(e9);
		allEmployees.add(e10);
		
		double r = allEmployees
						.stream()
						.map(e->e.getBasic())
						.reduce(0.0, (b1,b2)->b1+b2);
		System.out.println(r);

	}

}
