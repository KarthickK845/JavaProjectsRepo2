package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.Circle;

public class Main2 {

	public static void main(String[] args) {
		List<Integer> list = new LinkedList<>();
		
		list.add(Integer.valueOf(200));
		list.add(Integer.valueOf(40));
		list.add(Integer.valueOf(100));
		list.add(Integer.valueOf(20));
		list.add(Integer.valueOf(500));

		list
			.stream()
			.sorted()
			.filter((i)->i>=100)
			.forEach((i)->System.out.println(i)); //creating Stream and sorting(intermediate) applying forEach that is terminal
	
		List<String> cities = new LinkedList<>();
		cities.add("Pune");
		cities.add("Patna");
		cities.add("Kolkata");
		cities.add("Cochin");
		
		cities
			.stream()
			.sorted()
			.filter((c)-> c.length()>=6)
			.forEach((c)-> System.out.println(c));
		
		List<Circle> circles = new LinkedList<>();
		circles.add(new Circle(10));
		circles.add(new Circle(20));
		circles.add(new Circle(130));
		circles.add(new Circle(150));
		circles.add(new Circle(240));
		
		circles
			.stream()
			.sorted()
			.filter((cr) -> cr.getRadius()>=100)
			.forEach((cr) -> System.out.println(cr));
		
		
	}

}
