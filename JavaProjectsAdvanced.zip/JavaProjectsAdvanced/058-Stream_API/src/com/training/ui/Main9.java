package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import com.training.model.Person;
import com.training.model.comparators.PersonNameComparator;

public class Main9 {

	public static void main(String[] args) {
		
		List<Person> allPersons = new LinkedList<>();
		allPersons.add(new Person("Ram", 24));
		allPersons.add(new Person("Manu",34));
		allPersons.add(new Person("Ranjan", 44));
		allPersons.add(new Person("Siva",35));
		allPersons.add(new Person("Dinesh", 25));
		allPersons.add(new Person("Xavier",33));
		
		Optional<Person> optionalResult =  allPersons
			.stream()
			.min(new PersonNameComparator());
		
		if(optionalResult.isPresent()) {
			System.out.println(optionalResult.get());
		}
		else {
			System.out.println("Collection is empty");
		}
		
		System.out.println("-------------------------------------");
		
		Optional<Person> optionalResult2 = allPersons
			.stream()
			.min((p1,p2)->p1.getAge()-p2.getAge());
		
		if(optionalResult2.isPresent()) {
			System.out.println(optionalResult2.get());
		}
		else {
			System.out.println("Collection is empty");
		}
		
		System.out.println("-------------------------------------");
		
		Optional<Person> optionalResult3 = allPersons
			.stream()
			.max((p1,p2)->p1.getAge()-p2.getAge());
		
		if(optionalResult3.isPresent()) {
			System.out.println(optionalResult3.get());
		}
		else {
			System.out.println("Collection is empty");
		}
		
		System.out.println("-------------------------------------");
		
		Optional<Person> optionalResult4 =  allPersons
				.stream()
				.max(new PersonNameComparator());
		
		if(optionalResult4.isPresent()) {
			System.out.println(optionalResult4.get());
		}
		else {
			System.out.println("Collection is empty");
		}
	}

}
