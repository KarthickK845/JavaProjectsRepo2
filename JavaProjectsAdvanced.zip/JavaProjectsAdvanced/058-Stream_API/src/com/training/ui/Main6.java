package com.training.ui;

import java.util.Set;
import java.util.TreeSet;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;
import com.training.model.comparators.BillItemQuantityComparator;

public class Main6 {

	public static void main(String[] args) {
		Set<BillItem> billItemSet = new TreeSet<>();
		
		billItemSet.add(new BillItem("Redmi", 10, 10000.00));
		billItemSet.add(new BillItem("Oppo", 15, 15000.00));
		billItemSet.add(new BillItem("Lenovo", 12, 12000.00));
		billItemSet.add(new BillItem("Redmi", 20, 40000.00));
		billItemSet.add(new BillItem("OnePlus", 25, 50000.00));
		billItemSet.add(new BillItem("VIVO", 50, 25000.00));

		billItemSet
			.stream()
			.mapToInt(bi -> bi.getQuantity())
			.forEach(q -> System.out.println(q));
		
		System.out.println("-------------------------------------");
		
		billItemSet
			.stream()
			.sorted(new BillItemPriceComparator())
			.forEach(bi -> System.out.println(bi));
		
		System.out.println("-------------------------------------");
		
		billItemSet
			.stream()
			.sorted(new BillItemQuantityComparator())
			.forEach(bi -> System.out.println(bi));
	}

}
