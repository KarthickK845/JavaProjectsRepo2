package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.training.model.Payment;

public class Main16 {

	public static void main(String[] args) {
		List<Payment> allPayments = new LinkedList<>();
		
		allPayments.add(new Payment("Jan",1000.00));
		allPayments.add(new Payment("Jan",2000.00));
		allPayments.add(new Payment("Jan",1500.00));
		
		allPayments.add(new Payment("Feb",250.00));
		allPayments.add(new Payment("Feb",100.00));
		allPayments.add(new Payment("Feb",150.00));
		allPayments.add(new Payment("Feb",300.00));
		
		allPayments.add(new Payment("Mar",1000.00));
		allPayments.add(new Payment("Mar",1500.00));
		
		/*
		 * Jan - 3
		 * Feb - 4
		 * Mar - 2
		 */
		
		Map<String, Long> map1 =  allPayments
									.stream()
									.collect(Collectors.groupingBy(Payment::getMonth, Collectors.counting()));
		
		System.out.println(map1);
		System.out.println("-------------------------------------------");
		
		/*
		 * Jan - 4500
		 * Feb - 750
		 * Mar - 2500
		 */
		Map<String, Double> map2 = allPayments
										.stream()
										.collect(Collectors.groupingBy(Payment::getMonth, Collectors.summingDouble(Payment::getPaymentAmount)));
		System.out.println(map2);
		System.out.println("-------------------------------------------");
		
		/*
		 * Jan - List<Payment>
		 * Feb - List<Payment>
		 * Mar - List<Payment>
		 */
		Map<String, List<Payment>> map3 = allPayments
				.stream()
				.collect(Collectors.groupingBy(Payment::getMonth));
		
		//System.out.println(map3);
		//System.out.println("-------------------------------------------");
		for(Map.Entry<String, List<Payment>> entry: map3.entrySet()) {
			System.out.println(entry.getKey());
			System.out.println("-------------------------------------------");
			List<Payment> pymtsInMonth = entry.getValue();
			for(Payment p:pymtsInMonth) {
				System.out.println(p.toString());
			}
			System.out.println("-------------------------------------------");
		}
	}

}
