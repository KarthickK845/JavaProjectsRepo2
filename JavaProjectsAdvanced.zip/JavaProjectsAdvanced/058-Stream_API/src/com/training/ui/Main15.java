package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.BillItem;

public class Main15 {

	public static void main(String[] args) {
		List<BillItem> billItems = new LinkedList<>();
		
		billItems.add(new BillItem("Redmi", 10, 1000.00));
		billItems.add(new BillItem("Oppo", 15, 1500.00));
		billItems.add(new BillItem("Lenovo", 12, 1200.00));
		billItems.add(new BillItem("Redmi", 20, 4000.00));
		billItems.add(new BillItem("OnePlus", 25, 5000.00));
		billItems.add(new BillItem("VIVO", 50, 2500.00));
		
		//total item value (reduce)
		double r = billItems
			.stream()
			.map(bi -> bi.getItemValue())
			.reduce(0.0, (iv1, iv2)->iv1+iv2);
		System.out.println(r);
	}

}
