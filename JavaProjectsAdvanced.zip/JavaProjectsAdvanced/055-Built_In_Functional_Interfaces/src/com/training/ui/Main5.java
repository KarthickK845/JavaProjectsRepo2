package com.training.ui;

import java.util.function.Function;

import com.training.model.Circle;
import com.training.model.Employee;
import com.training.model.Payment;
import com.training.model.Person;
import com.training.model.Square;

public class Main5 {

	public static void main(String[] args) {
		Function<Integer, Circle> function1;
		function1 = (Integer i)->{
			return new Circle(i.intValue());
		};
		Circle c = function1.apply(5);
		System.out.println(c);
		
		Function<Integer, Square> function2;
		function2 = i -> new Square(i.intValue());
		Square s = function2.apply(6);
		System.out.println(s);
		
		Function<Employee, String> function3;
		function3 = e -> e.getName();
		
		Employee e = new Employee(101, "Harish", "Male", "Delhi", 32000.00);
		
		String ename = function3.apply(e);
		System.out.println(ename);
		
		Function<Employee, String> function4;
		function4 = emp -> emp.getCityName();
		
		String ecity = function4.apply(e);
		System.out.println(ecity);
		
		Function<Employee, Double> function5;
		function5=(emp)-> emp.getBasic();
		Double ebasic = function5.apply(e);
		System.out.println(ebasic);
		
		Payment payment = new Payment("Feb", 45000.00);
		
		Function<Payment, String> function6;
		function6 = p -> p.getMonth();
		String month = function6.apply(payment);
		System.out.println(month);
		
		Function<Payment, Double> function7;
		function7 = p -> p.getPaymentAmount();
		Double pmtAmt = function7.apply(payment);
		System.out.println(pmtAmt);
		
		Person person = new Person("Karan", 35);
		
		Function<Person, String> function8;
		function8 = ps -> ps.getName();
		String pname = function8.apply(person);
		System.out.println(pname);
		
		Function<Person, Integer> function9;
		function9 = ps -> ps.getAge();
		Integer page = function9.apply(person);
		System.out.println(page);
	}

}
