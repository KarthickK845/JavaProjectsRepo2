package com.training.ui;

import java.util.function.Supplier;

import com.training.model.Bill;
import com.training.model.BillItem;
import com.training.model.Circle;
import com.training.model.Department;
import com.training.model.Employee;

public class Main4 {

	public static void main(String[] args) {
		Supplier<Circle> supplier1;
		supplier1=()-> new Circle(10);
		System.out.println(supplier1.get());
		
		Supplier<BillItem> supplier2;
		supplier2 = () -> new BillItem("Sony", 3, 32000.00);
		System.out.println(supplier2.get());
		
		Supplier<Employee> supplier3;
		supplier3 = () -> new Employee(102, "Ranjith", "male", "Kochi", 4000.00);
		System.out.println(supplier3.get());
		
		Supplier<Bill> supplier4;
		supplier4 = () -> {
			Bill bill = new Bill(554, "Abhi");
			bill.addBillItem("IPhone", 2, 35000.00);
			bill.addBillItem("Oppo", 2, 47000.00);
			return bill;
		};
		Bill latestBill = supplier4.get();
		latestBill.printBill();
		
		Supplier<Department> supplier5;
		supplier5 = () -> {
			Department department = new Department("IT", "Kiran");
			department.addEmployee(101, "Narmada", "Female", "Pune", 4000.00);
			department.addEmployee(102, "Sangavi", "Female", "Kochi", 3000.00);
			department.addEmployee(104, "Nirmala", "Female", "Chennai", 8000.00);
			department.addEmployee(103, "Sita", "Female", "Mysore", 9000.00);
			return department;
		};
		Department ITdepartment = supplier5.get();
		ITdepartment.printReport();
		
	}

}
