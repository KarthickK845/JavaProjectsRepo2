package com.training.ui;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import com.training.model.Employee;
import com.training.model.comparators.EmployeeBasicSalaryAscendingComparator;

public class Main1 {

	public static void main(String[] args) {
		Employee e1 = new Employee(10, "Rama", "Male", "Bangalore", 10000.00);
		Employee e2 = new Employee(11, "Sumanth", "male", "Chennai", 15000.00);
		Employee e3 = new Employee(13, "Prithviraj", "Male", "Cochin", 11000.00);
		Employee e4 = new Employee(12, "Santhoshi", "Female", "Pune", 32000.00);
		Employee e5 = new Employee(14, "Manu", "feMALE", "Mumbai", 23000.00);
		Employee e6 = new Employee(16, "Renu", "female", "Chennai", 14000.00);
		Employee e7 = new Employee(15, "Sundari", "FEMALE", "Chennai", 16000.00);
		Employee e8 = new Employee(17, "Maheshwari", "Female", "Cochin", 20000.00);
		Employee e9 = new Employee(19, "Venky", "MALE", "Pune", 42000.00);
		Employee e10 = new Employee(18, "Vicky", "Male", "Mumbai", 41000.00);
		
		List<Employee> allEmployees = new LinkedList<>();
		allEmployees.add(e1);
		allEmployees.add(e2);
		allEmployees.add(e3);
		allEmployees.add(e4);
		allEmployees.add(e5);
		allEmployees.add(e6);
		allEmployees.add(e7);
		allEmployees.add(e8);
		allEmployees.add(e9);
		allEmployees.add(e10);

		System.out.println(allEmployees);
		Collections.sort(allEmployees);
		System.out.println("---------------------------------------------------");
		System.out.println(allEmployees);
		
		Collections.sort(allEmployees, new EmployeeBasicSalaryAscendingComparator());
		System.out.println("---------------------------------------------------");
		System.out.println(allEmployees);
		
		Employee minEmployee = Collections.min(allEmployees, new EmployeeBasicSalaryAscendingComparator());
		System.out.println("---------------------------------------------------");
		System.out.println(minEmployee);
		
		Employee maxEmployee = Collections.max(allEmployees, new EmployeeBasicSalaryAscendingComparator());
		System.out.println("---------------------------------------------------");
		System.out.println(maxEmployee);
		
		System.out.println("---------------------------------------------------");
		Object[] empArr=allEmployees.toArray();
		for(Object obj : empArr) {
			System.out.println(obj.toString());
			Employee e = (Employee) obj;
			System.out.println(e.getNetSalary());
		}
		
	}

}
