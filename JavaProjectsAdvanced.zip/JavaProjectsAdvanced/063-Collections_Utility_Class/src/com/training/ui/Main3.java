package com.training.ui;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;

public class Main3 {

	public static void main(String[] args) {
		List<BillItem> billItems = Arrays.asList(new BillItem("Pencil", 20, 5.00),
										new BillItem("Pen", 20, 100.00),
										new BillItem("Whitener", 25, 65.00),
										new BillItem("Color paper", 15, 10.00),
										new BillItem("Bril Ink", 12, 50.00));
		
		System.out.println(billItems);
		Collections.sort(billItems);
		System.out.println("---------------------------------------------------");
		System.out.println(billItems);
		
		BillItem minBillItem= Collections.min(billItems, new BillItemPriceComparator());
		System.out.println("---------------------------------------------------");
		System.out.println("Minimum Priced BillItem : "+minBillItem);
		
		BillItem maxBillItem= Collections.max(billItems, new BillItemPriceComparator());
		System.out.println("---------------------------------------------------");
		System.out.println("Maximum Priced BillItem : "+maxBillItem);

		System.out.println("---------------------------------------------------");
		Object[] biArr=billItems.toArray();
		for(Object obj : biArr) {
			System.out.println(obj.toString());
			BillItem e = (BillItem) obj;
			System.out.println(e.getItemValue());
		}
	}
}
