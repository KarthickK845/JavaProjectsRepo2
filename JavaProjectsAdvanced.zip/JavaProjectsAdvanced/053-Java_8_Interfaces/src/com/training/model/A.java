package com.training.model;

public interface A {
	void f1();
	//change method to default if we give body
	default void f2() {
		System.out.println("f2 in A interface");
	}
	
	//interface in Java 8 can have any number of default methods
	default void f3() {
		System.out.println("f3 in A interface");
	}
	
	default void f4() {
		System.out.println("f4 in A interface");
	}
	
	static void f5() {
		System.out.println("static f5 in A interface");
	}
}
