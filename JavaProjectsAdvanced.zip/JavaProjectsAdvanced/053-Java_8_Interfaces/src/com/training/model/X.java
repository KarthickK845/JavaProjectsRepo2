package com.training.model;

public interface X {
	
	default void method1() {
		System.out.println("default method1 in X interface");
	}
	
	static void method2() {
		System.out.println("static method2 in X interface");
	}
	
	void method3();
	
	static void method4() {
		System.out.println("static method2 in X interface");
	}
}
