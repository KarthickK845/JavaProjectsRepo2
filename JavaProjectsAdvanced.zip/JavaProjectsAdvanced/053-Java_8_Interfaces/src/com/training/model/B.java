package com.training.model;

public interface B {
	default void f4() {
		System.out.println("f4 in B interface");
	}
}
