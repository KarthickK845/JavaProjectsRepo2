package com.training.model;

public class D implements A,B,X{

	@Override
	public void f1() {
		System.out.println("f1 in D class");
		
	}
	
	//if needed we can override the default method of A interface but not mandatory
	@Override
	public void f2() {
		System.out.println("f2 in D class");
		
	}

	@Override
	public void f4() {
		System.out.println("f4 in D class");
	}

	@Override
	public void method3() {
		System.out.println("method3 in D class");
		
	}
}
