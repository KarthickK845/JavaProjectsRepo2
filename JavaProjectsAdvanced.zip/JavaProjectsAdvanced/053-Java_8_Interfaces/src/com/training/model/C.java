package com.training.model;

public class C implements A,B,X{

	@Override
	public void f1() {
		System.out.println("f1 in C class");
		
	}

	//must override default method
	@Override
	public void f4() {
		System.out.println("f4 in C class");
	}

	@Override
	public void method3() {
		System.out.println("method3 in C class");
		
	}

	

}
