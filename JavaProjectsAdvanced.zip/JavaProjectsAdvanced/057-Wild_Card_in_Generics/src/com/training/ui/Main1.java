package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.CarLoan;
import com.training.model.CollegeEducationLoan;
import com.training.model.EducationLoan;
import com.training.model.HomeLoan;
import com.training.model.Loan;

public class Main1 {
	
	static void print1(List<? extends Loan> loans) {
		System.out.println(loans);
	}

	static void print2(List<? extends CarLoan> loans) {  //"? extends" denotes Wild Card Generics i.e. CarLoan and any of the subclasses of CarLoan
		System.out.println(loans);
	}
	
	static void print3(List<? extends EducationLoan> loans) {
		System.out.println(loans);
	}
	
	static void print4(List<? super EducationLoan> loans) { //any super class of EducationLoan
		System.out.println(loans);
	}
	
	static void print5(List<?> loans) { //List of any type of objects
		System.out.println(loans);
	}
	
	static void print6(List<? extends HomeLoan> loans) {
		System.out.println(loans);
	}
	
	public static void main(String[] args) {
		List<Loan> loans = new LinkedList<>();
		print1(loans);
		
		List<CarLoan> cloans = new LinkedList<>();
		print2(cloans);
		
		List<EducationLoan> eloans = new LinkedList<>(); //EducationLoan allowed
		print3(eloans);
		
		List<CollegeEducationLoan> celoans = new LinkedList<>();  //CollegeEducationLoan allowed
		print3(celoans);
		
		print1(cloans);
		print1(eloans);
		print1(celoans);
		
		print4(loans);
		print4(eloans);
		
		print5(loans);
		print5(cloans);
		print5(celoans);
		print5(eloans);
		
		List<Integer> iList = new LinkedList<>();
		print5(iList);
		
		List<HomeLoan> hloans = new LinkedList<>();
		print1(hloans);
		
//		print2(hloans);
//		print3(hloans);
//		print4(hloans);
		
		print5(hloans);
		print6(hloans);
	}

}
