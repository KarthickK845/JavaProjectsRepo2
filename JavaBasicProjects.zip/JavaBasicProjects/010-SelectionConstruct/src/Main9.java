
public class Main9 {

	public static void main(String[] args) {
		String city="Delhi";
		switch(city)
		{
			case "Delhi":System.out.println("Welcome 1");
					break;
			case "Chennai":System.out.println("Welcome 2");
					break;
			case "Bangalore":System.out.println("Welcome 3");
			 		break;
			case "Mumbai":System.out.println("Welcome Mumbai");
		}
	}

}
