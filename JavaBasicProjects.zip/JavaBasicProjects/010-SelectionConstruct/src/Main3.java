
public class Main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age = 14;
		if(age>=18) {
			System.out.println("Your age is above 18");
			System.out.println("You are eligible for voting");
		}
		else {
			System.out.println("Your age is below 18");
			System.out.println("You have to wait to become eligible for voting");
		}
	}

}
