
public class Main7 {

	public static void main(String[] args) {
		char grade='C';
		switch(grade) {
			case 'A':System.out.println("The scholarship amount is Rs.50000.00");
					break;
			case 'B':System.out.println("The scholarship amount is Rs.40000.00");
					break;
			case 'C':System.out.println("The scholarship amount is Rs.30000.00");
					break;
			case 'D':System.out.println("The scholarship amount is Rs.0.00");
					break;
			default : System.out.println("Invalid Grade");
					break;
		}
	}

}
