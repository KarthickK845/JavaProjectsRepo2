
public class Main4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int marks;
		marks = 66;
		char grade;
		
		if(marks>=90)
		{
			grade='A';
			System.out.println("You are Eligible for Scholarship");
		}
		else if(marks>=70)
		{
			grade='B';
			System.out.println("You are Eligible for Scholarship");
		}
		else if(marks>=50)
		{
			grade='C';
			System.out.println("You are NOT Eligible for Scholarship");
		}
		else {
			grade = 'D';
			System.out.println("You are Eligible for Scholarship");
		}
		
		System.out.println(grade);
	}

}
