import java.util.Scanner;

public class Main6 {

	public static void main(String[] args) {
		int mark1,mark2;
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter your mark1 : ");
		mark1=sc.nextInt();
		System.out.print("Enter your mark2 : ");
		mark2=sc.nextInt();
		
		float average;
		char grade;
		
		//average 80-100, grade is 'A'
		//average 60-79, grade is 'B'
		//average 40-59, grade is 'C'
		//average 0-39, grade is 'D'
		
		//grade=='A', print message Scholarship is Rs.50000.00
		//grade=='B', print message Scholarship is Rs.40000.00
		//grade=='C', print message Scholarship is Rs.30000.00
		//grade=='D', print message Scholarship is Rs.0.00
		
		average=(mark1+mark2)/2.0f;		//multi mode expression, implicitly result will be float
		
		if(average>80)
			grade = 'A';
		else if(average>=60)
			grade = 'B';
		else if(average>=40)
			grade = 'C';
		else
			grade = 'D';
		
		if(grade=='A')
			System.out.println("Your Scholarship is Rs.50000.00");
		else if(grade=='B')
			System.out.println("Your Scholarship is Rs.40000.00");
		else if(grade=='C')
			System.out.println("Your Scholarship is Rs.30000.00");
		else
			System.out.println("Your Scholarship is Rs.0.00");
	}

}
