
public class Main2 {

	public static void main(String[] args) {
		//Selection Construct - statements selected for execution based on a condition
		int age = 14;
		if(age>=18) {
			System.out.println("Your age is above 18");
			System.out.println("You are eligible for voting");
		}
	
	}

}
