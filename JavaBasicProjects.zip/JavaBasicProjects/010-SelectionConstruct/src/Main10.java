import java.util.Scanner;

public class Main10 {

	public static void main(String[] args) {
		int currentQuantity;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter current quantity");
		currentQuantity = sc.nextInt();
		
		final int veryLowStock = 10;
		final int lowStock1 = 20;
		final int lowStock2 = 30;
		final int okLevel = 50;
		
		switch(currentQuantity) {
		
			case veryLowStock : System.out.println("Stock Level Very Low");
								break;
			case lowStock1 :
			case lowStock2 :
				System.out.println("Stock Level Low");
				break;
			case okLevel :
				System.out.println("Stock Level OK");
				break;
			default : 
				System.out.println("Invalid Stock Level");
		}
	}

}
