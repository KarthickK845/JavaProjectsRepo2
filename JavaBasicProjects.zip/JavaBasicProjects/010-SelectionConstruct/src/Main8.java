
public class Main8 {

	public static void main(String[] args) {
		byte size=20;
		final int bvalue=120;
		switch(++size)
		{
			case 50:System.out.println("Welcome 1");
					break;
			case 100:System.out.println("Welcome 2");
					break;
			case 126:System.out.println("Welcome 3");
			 		break;
			case bvalue:System.out.println();
		}
	}

}
