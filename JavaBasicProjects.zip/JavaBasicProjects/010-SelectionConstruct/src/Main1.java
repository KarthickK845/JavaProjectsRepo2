
public class Main1 {

	public static void main(String[] args) {
		//Sequential Construct
//		System.out.println(1);
//		System.out.println(2);
//		System.out.println(3);
//		System.out.println('A');
//		System.out.println('B');
		
		//Selection Construct - statements selected for execution based on a condition
		int age = 44;
		if(age>=18) {
			System.out.println("Your age is above 18");
			System.out.println("You are eligible for voting");
		}
	}

}
