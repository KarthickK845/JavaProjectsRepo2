package kochi;

import bangalore.BLROffice1;

public class KOCOffice2 extends BLROffice1{
	public String operate5() {
//		System.out.println(plotNumber);
//		System.out.println(streetName);
		return areaName+"-"+zipCode;    //protected and public resp.
	}
	
	public long operate6()
	{
		BLROffice1 blro1 = new BLROffice1();
//		System.out.println(blro1.plotNumber);
//		System.out.println(blro1.streetName);
//		System.out.println(blro1.areaName);
		return zipCode;  //public
	}
}
