package kochi;

import bangalore.BLROffice1;

public class KOCOffice3 {
	public void operate7() {
		BLROffice1 blro1 = new BLROffice1();
		System.out.println(blro1.zipCode);
	}
	
	public void operate8() {
		KOCOffice1 kofc = new KOCOffice1();  //default level constructor
	}
}
