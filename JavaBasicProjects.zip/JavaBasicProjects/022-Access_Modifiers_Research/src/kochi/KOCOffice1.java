package kochi;

import bangalore.BLROffice1;

class KOCOffice1 {
	KOCOffice1(){
		
	}
	public void operate4() {
		BLROffice1 blro1 = new BLROffice1();	
//		System.out.println(blro1.plotNumber);
//		System.out.println(blro1.streetName);
//		System.out.println(blro1.areaName);
		System.out.println(blro1.zipCode);   //public level
		
		
	}
}
