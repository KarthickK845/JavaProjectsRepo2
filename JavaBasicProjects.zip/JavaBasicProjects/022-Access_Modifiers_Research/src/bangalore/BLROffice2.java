package bangalore;

public class BLROffice2 {
	public void operate1() {
		BLROffice1 ofc = new BLROffice1();
		//System.out.println(ofc.plotNumber);  //inaccessible as it is private
		System.out.println(ofc.streetName);
		System.out.println(ofc.areaName);
		System.out.println(ofc.zipCode);
		
	}
}
