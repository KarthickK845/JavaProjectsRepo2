package bangalore;

public class BLROffice1 {
	private int plotNumber;
	public long zipCode;
	String streetName;
	
	protected String areaName;
	
	public BLROffice1() {
		System.out.println("Bangalore Office");
	}
	
	public BLROffice1(int plotNumber,long zipCode,String streetName,String areaName) {
		this.plotNumber=plotNumber;
		this.streetName=streetName;
		this.areaName=areaName;
		this.zipCode=zipCode;
	}
	
	public void printAddress() {
		System.out.println(plotNumber+","+streetName);
		System.out.println(areaName);
		System.out.println("Bangalore -"+zipCode);
	}
}
