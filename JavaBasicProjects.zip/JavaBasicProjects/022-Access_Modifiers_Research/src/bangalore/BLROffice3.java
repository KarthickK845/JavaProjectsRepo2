package bangalore;

public class BLROffice3 extends BLROffice1{
	public void operate2() {
		//System.out.println(plotNumber); //private
		System.out.println(streetName);
		System.out.println(areaName);
		System.out.println(zipCode);
	}
	
	public void operate3() {
		BLROffice1 ofc = new BLROffice1();
		//System.out.println(ofc.plotNumber);	//private
		System.out.println(ofc.streetName);
		System.out.println(ofc.areaName);
		System.out.println(ofc.zipCode);
	}
}
