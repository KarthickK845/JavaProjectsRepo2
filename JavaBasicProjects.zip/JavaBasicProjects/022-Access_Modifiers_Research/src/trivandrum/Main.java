package trivandrum;

import bangalore.BLROffice1;

public class Main {

	public static void main(String[] args) {
		BLROffice1 blro1 = new BLROffice1(359,560066,"ITPL Main Road","Whitefield");
		blro1.printAddress();
	}

}
