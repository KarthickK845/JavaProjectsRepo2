
public class CClient {

	public static void main(String[] args) {
		C obj = new C();
		obj.display(100);   //int literal 100 so it calls int type parameter method
		
		int v=900;
		
		short v1=800;
		obj.display(v1);	//if there is no method with short type, it will invoke next available type i.e. int
		
		byte v2=77;
		
		char v3 = 'A';
		
		long v4 = 900;
		
		float v5 = 9.0f;
		double v6 = 90.0;
		
		obj.display((byte) 60);
		
		obj.display(v);	//widening conversion happens and invokes that available type
		obj.display(v1);
		obj.display(v2);
		obj.display(v3);
		obj.display(v4);
		obj.display(v5);	//compile error as float greater than long type
		obj.display(v6);	//compile error as double also greater
		
		obj.display(10,20,30);
		obj.display(new int[] {21,31,41});
		
		
	}

}
