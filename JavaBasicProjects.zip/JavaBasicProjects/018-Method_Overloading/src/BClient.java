
public class BClient {

	public static void main(String[] args) {
		B obj = new B();
		obj.calculate();
		System.out.println("RESULT is "+obj.calculate(4, 7));
		System.out.println("RESULT is "+obj.calculate(30.0, 51.0));
		
		//static methods
		B.calculate(53, 20.0);
		B.calculate(2.0f, 5.0f, 9.0f);
	}

}
