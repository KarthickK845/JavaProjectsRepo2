
public class B {
	// overload a method 5 times
	void calculate() {
		System.out.println("calculate no arguments");
	}
	
	static void calculate(int a, double b) {
		System.out.println("calculate add "+a+ ", "+b+ " and result = "+ (a+b));
	}
	
	int calculate(int a, int b) {
		System.out.println("calculate subtract "+a+ ", "+b);
		return a-b;
	}
	
	static void calculate(float a, float b, float c) {
		System.out.println("calculate multiply "+a+", "+b+", "+c+" and result = "+(a*b*c));
	}
	
	double calculate(double a, double b) {
		System.out.println("calculate divide "+a+" and "+b);
		return a/b;
	}
}
