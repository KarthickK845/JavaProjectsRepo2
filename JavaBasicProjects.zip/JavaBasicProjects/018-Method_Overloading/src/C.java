import java.util.Arrays;

public class C {
	void display(int p) {
		System.out.println("display with int "+ p);
	}
	
//	void display(short p) {
//		System.out.println("display with short "+ p);
//	}
	
	void display(double p) {
		System.out.println("display with long "+ p);
	}
	
	//int array as parameter 
//	void display(int[] arr) {
//		System.out.println("display with int array "+ Arrays.toString(arr));
//	}
	
	//int variable arguments
	//better than above method since we can pass both array and any number of arguments directly
	void display(int... arr) {
		System.out.println("display with long "+ Arrays.toString(arr));
	}
	
	void display(byte a) {
		System.out.println("display with byte "+a);
	}
}
