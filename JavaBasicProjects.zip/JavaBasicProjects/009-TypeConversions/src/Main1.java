
public class Main1 {

	public static void main(String[] args) {
		byte v1=100;
		short v2=v1;	//byte to short storage => 1 byte to 2 bytes => widening implicitly
		
		int c=v1;	//type conversion, implicit, widening conversion
		long d = c;	   //type conversion, implicit, widening conversion
		float e=d;
		double f=e;
		
		char r='A';
		int s=r;
		
	}

}
