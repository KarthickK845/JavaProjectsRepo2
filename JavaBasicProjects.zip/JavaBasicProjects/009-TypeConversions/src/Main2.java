
public class Main2 {

	public static void main(String[] args) {
		int v1=100;
		short v2=(short)v1;		//explicit, narrow conversion
		byte v3=(byte) v2;
		
		char d='p';
		v3=(byte)d;		//explicit, narrow
		
		double v4=90.0;
		
		//narrow conversions
		int v5=(int)v4;
		short v6=(short)v4;
		byte v7=(byte)v4;
		float v8=(float)v4;
		long v9=(long)v4;
		char v10=(char)v4;
		boolean v11=(boolean)v4;	//can't cast double to boolean
	}

}
