
public class Main3 {
	public static void main(String[] args) {
		int v1=30;
		int v2=40;
		long v3=50;
		double v4=60;
		
		int result = v1+v2;		//single mode expression, cannot do narrow conversion
		
		long result2 = v1+v2+v3;		//mixed mode expression (int and long type variables), result takes highest type of variable in the expression i.e. long
		//cannot do narrow conversion
		
		double result3=v1+v2+v3+v4;
		
		byte v5=6;
		short v6=7;
		int result4=v5+v6;	//though types are short and byte, result is always int type only as those types are very small
		
		int result5 = (int) (v1+v2+v3);
		float result6 = (float) (v1+v2+v3+v4);
	}
}
