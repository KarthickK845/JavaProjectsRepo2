
public class Main4 {

	public static void main(String[] args) {
		int v1=40;
		long v2=900;
		
		long result1 = v1+v2+100;	//mixed mode exprs.., 100 is int literal, long is highest type so long result
		
		float result4 = v1+v2+10.0f;	//float is highest type
		
		byte v3 = 88;
		short v4 = 99;
		double result3 = v3+v4+v2+10.0;
		
		int result2 = v3+10+20*40;
		
		
		
		
	}

}
