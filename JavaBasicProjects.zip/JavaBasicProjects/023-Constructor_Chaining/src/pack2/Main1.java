package pack2;

import pack1.A;

public class Main1 {

	public static void main(String[] args) {
		A obj = new A(5,10,15);
		obj.display();

	}

}
