package pack1;

public class C extends B{
	int z;
	
	public C(int x,int y,int z) {
		super(x,y);	//also constructor chaining - calling super class constructor
		//avoiding code redundancy
//		this.x=x;
//		this.y=y;
		this.z=z;
		System.out.println("C Constructor with 3 arguments "+x+", "+y+", "+z);
	}
	
	public C(int x,int y) {
		super(x,y);
		System.out.println("C Constructor with 2 arguments "+x+", "+y);
	}
	
	public C(int x) {
		super(x);
		System.out.println("C Constructor with 1 argument "+x);
	}
	
	public C() {
		super();
		System.out.println("C constructor without arguments");
	}
}
