package pack1;

public class A {
	int x,y,z;
	
	public A(){
		System.out.println("A object created without arguments");
	}
	
	public A(int x) {
		this();  //calling explicit constructor
		System.out.println("A object created with 1 argument "+x);
		this.x=x;	//this can be in any line
	}
	
	public A(int x,int y) {
		this(x);
		this.y=y;
		System.out.println("A object created with 2 arguments "+x+","+y);
		//this.x=x; //we will follow constructor chaining
		
	}
	
	public A(int x,int y,int z) {
		this(x,y);
		this.z=z;
		System.out.println("A object created with 3 arguments "+x+","+y+","+z);
		//instead of setting the values redundantly since we do in the above constructor
		// we will call that constructor - concept is constructor chaining
//		this.x=x;
//		this.y=y;
		
	}
	
	public void display() {
		System.out.println(this.x+","+this.y+","+this.z);
	}
}
