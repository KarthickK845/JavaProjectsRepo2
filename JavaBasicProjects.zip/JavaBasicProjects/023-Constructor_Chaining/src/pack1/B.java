package pack1;

public class B {
	int x,y;
	
	public B() {
		System.out.println("B constructor without arguments");
	}
	
	public B(int x) {
		this();
		System.out.println("B constructor with 1 argument "+x);
		this.x=x;
	}

	public B(int x,int y) {
		this(x);
		this.y=y;
		System.out.println("B constructor with 2 arguments "+x+", "+y);
	}
}
