
public class Client {

	public static void main(String[] args) {
		Manager manager = new Manager();
		manager.setId(101);
		manager.setName("Ram");
		manager.setGender("MALE");
		manager.setBasicSalary(1000);
		manager.setEmployeeCount(50);
		
		System.out.println("ID : " +manager.getId());
		System.out.println("NAME : " +manager.getName());
		System.out.println("GENDER : "+manager.getGender());
		System.out.println("BASIC SALARY : "+manager.getBasicSalary());
		System.out.println("EMPLOYEE COUNT : "+manager.getEmployeeCount());
		System.out.println("NET SALARY : "+manager.getNetSalary());
		
		SalesEmployee salesemployee = new SalesEmployee();
		salesemployee.setId(151);
		salesemployee.setName("Mano");
		salesemployee.setGender("MALE");
		salesemployee.setBasicSalary(750);
		salesemployee.setSalesAreaName("Bangalore");
		
		System.out.println("ID : " +salesemployee.getId());
		System.out.println("NAME : " +salesemployee.getName());
		System.out.println("GENDER : "+salesemployee.getGender());
		System.out.println("BASIC SALARY : "+salesemployee.getBasicSalary());
		System.out.println("SALES AREA NAME : "+salesemployee.getSalesAreaName());
		System.out.println("NET SALARY : "+salesemployee.getNetSalary());
	}

}
