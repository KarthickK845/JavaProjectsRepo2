
public class RegionalManager extends Manager{

}
