
public class SalesEmployee extends Employee{
	private String salesAreaName;

	String getSalesAreaName() {
		return salesAreaName;
	}

	void setSalesAreaName(String salesAreaName) {
		this.salesAreaName = salesAreaName;
	}
	
	
}
