package model;

public class CurrentAccount {

}
