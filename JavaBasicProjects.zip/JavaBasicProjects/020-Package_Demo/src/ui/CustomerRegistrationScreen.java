package ui;

public class CustomerRegistrationScreen {

}
