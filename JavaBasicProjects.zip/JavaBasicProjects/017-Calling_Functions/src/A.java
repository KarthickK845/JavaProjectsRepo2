
public class A {
	int x;	//instance variable
	static int y;	//static variable (or global variable)
	
	void printX()	//instance variable
	{
		System.out.println(this.x);
		this.printWelcome();
		System.out.println(y);
		printGoodBye();
		new A();
	}
	
	void printWelcome() {	//instance method
		System.out.println("Welcome");
	}
	
	static void printY()  //static method
	{
		//System.out.println(x);
		//printWelcome();
		System.out.println(y);
		printGoodBye();
		new A();
		//System.out.println(this.x);	//error since x is instance
	}
	
	static void printGoodBye() {   //static method
		System.out.println("Good Bye");
	}
	
	A(){
		this(10);
		System.out.println("A object created");
		System.out.println(this.x);
		printWelcome();
		System.out.println(y);
		printGoodBye();
	}
	
	A(int x)
	{
		//this();
		System.out.println("A object created with "+x);
		this.x=x;
	}
}
