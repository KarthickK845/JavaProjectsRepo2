
public class Employee {
	int id;
	String name;
	int age;
	
	void display() {
		System.out.print("ID = "+id);
		System.out.print("---");
		System.out.print("NAME = "+name);
		System.out.print("---");
		System.out.print("AGE = "+age);
		System.out.println();
	}
}
