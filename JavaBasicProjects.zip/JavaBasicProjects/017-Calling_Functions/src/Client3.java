
public class Client3 {
	
	public static void test3(Employee e) {
		System.out.println("In test3 Before Changes");
		e.display();
		
		e.id=e.id+1;
		e.name="Karthik";
		e.age=18;
		
		System.out.println("In test3 after changes");
		e.display();
	}

	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.id = 1001;
		emp.name = "Ram";
		emp.age = 50;
		
		System.out.println("In Main before function call");
		emp.display();
		
		test3(emp);
		
		System.out.println("In Main after function call");
		emp.display();
	}

}
