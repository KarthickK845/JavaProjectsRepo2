
public class Square {
	private int size;

	void setSize(int size) {
		if(size<0) {
			System.out.println("Invalid data");
			return ; //to exit the method
		}
		this.size=size;
	}
	
	int getSize() {
		return this.size;
	}
}
