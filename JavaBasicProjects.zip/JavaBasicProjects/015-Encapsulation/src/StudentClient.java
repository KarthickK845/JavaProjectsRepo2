
public class StudentClient {

	public static void main(String[] args) {
		//Task 2
		Student student = new Student();
		
		student.setRollNumber(0);
		student.setName(null);
		student.setMark1(-9);
		student.setMark2(919);
		student.setGender("imale");
		
		System.out.println(student.getRollNumber());
		System.out.println(student.getName());
		System.out.println(student.getMark1());
		System.out.println(student.getMark2());
		System.out.println(student.getGender());
	}

}
