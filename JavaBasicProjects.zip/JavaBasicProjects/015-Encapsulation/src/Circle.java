
public class Circle {
	private int myRadius;
	
	void setRadius(int r) {
		if(r<0) {
			System.out.println("Invalid Radius");
			return ;
		}
		myRadius=r;
	}
	
	int getRadius() {
		return myRadius;
	}
	
	double getArea() {
		return 3.14*myRadius*myRadius;
	}
}
