
public class Main01 {

	public static void main(String[] args) {
		int age=50;
		int years[];
		years=new int[3];
		
		System.out.println(years.length);
		
		years[0]=1991;
		years[1]=2000;
		
		for(int i=0;i<years.length;i++)
		{
			System.out.println(years[i]);
		}
		
		years=null;		//deallocating memory, array becomes garbage
	}

}
