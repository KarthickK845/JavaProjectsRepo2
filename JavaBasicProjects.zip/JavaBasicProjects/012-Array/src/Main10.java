import java.util.Arrays;

public class Main10 {

	public static void main(String[] args) {
		int[] array= {1,2,3};		//inline initialization
		int[] array2 = new int[3];
		int[] array3 = new int[] {4,5,6,7};
		
		byte b=10;
		short s = 20;
		int i1=100;
		char c='A';
		
		//lesser types can be stored in a single array like above 4 types
		//below types cannot be stored in an int array, we can typecast and store
		long l=800;
		double d=80.0;
		
		int[] array4= {b,s,i1,c,(int)l,(int)d};
		
		int[] array5 = {b,s,i1,c,100,800,200};
		
		String str="[";
//		for(int e:array4) {
//			str+=e+",";
//		
//		}
//		str+="]";
//		System.out.println(str);
		
		for(int i=0;i<array4.length;i++) {
			if(i==array4.length-1)
				str+=array4[i];
			else
				str+=array4[i]+",";
		}
		str+="]";
		System.out.println(str);
		
		System.out.println(Arrays.toString(array4));
	}

}
