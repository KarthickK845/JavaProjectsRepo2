import java.util.Arrays;

public class Main11 {

	public static void main(String[] args) {
		
		int size=4;
		int[] array=new int[size];
//		array[0]=50;
//		array[1]=80;
//		array[2]=100;
//		array[3]=200;
		
		//accessing element of index outside of the above list of indexes throws exception
		//possible to create any array with size 0
		//if size = -4; NegativeArraySizeException thrown
		
		int[] array1= {};
		array=null;
		//after nullifying the array if we try getting the length or 
		// the elements of the array, we get NullPointerException
		System.out.println(array.length);
		System.out.println(Arrays.toString(array));
		
	}

}
