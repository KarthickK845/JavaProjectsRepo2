
public class Main08 {

	public static void main(String[] args) {
		//Task 2
		int[] array = {14,20,30,10};
		//find min value and print
		int min=array[0],max=0;
		for(int e:array)
		{
			if(min>e) {
				min=e;
			}
			//find max value and print
			if(max<e) {
				max=e;
			}
		}
		
		System.out.println("Minimum value : "+min);		
		System.out.println("Maximum value : "+max);
	}

}
