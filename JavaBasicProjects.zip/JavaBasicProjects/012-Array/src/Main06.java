import java.util.Scanner;

public class Main06 {

	public static void main(String[] args) {
		long[] profits;
		int arraySize;
		//take input size at runtime
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter array size : ");
		arraySize=sc.nextInt();
		profits=new long[arraySize];
		for(int i=0;i<profits.length;i++) {
			profits[i]=sc.nextLong();
		}
		
		for(long e:profits)
			System.out.println(e);
		
	}

}
