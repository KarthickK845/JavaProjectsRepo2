
public class Main07 {

	public static void main(String[] args) {
		//Task 1
		int[] array = {14,20,30,10};
		//find the sum of elements and average, print each
		int sum=0;
		for(int e:array) {
			sum+=e;
		}
		System.out.println("Sum : "+sum);
		
		float average = sum/array.length;
		
		System.out.println("Average : " + average);
	}

}
