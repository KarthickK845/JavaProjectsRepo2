package pack2;

import pack1.A;

public class E extends A{
	public void test4() {
		//E is not friend of A, so cannot access default level
		//trying to access instance variables as a sub class directly
		//below are private and default hence error
//		System.out.println(v1);
//		System.out.println(v2);	//non friendly subclass, so default not accessible
		//below are accessible since protected and public levels
		System.out.println(v3);
		System.out.println(v4);
	}
	
	public void test5() {
		A obj = new A();
//		System.out.println(obj.v1);
//		System.out.println(obj.v2);
//		System.out.println(obj.v3);  //accessing as a client using object of A, is inaccessible
		System.out.println(obj.v4);		//only public is visible
	}
}
