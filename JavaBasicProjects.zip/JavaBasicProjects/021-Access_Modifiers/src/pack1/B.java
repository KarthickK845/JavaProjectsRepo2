package pack1;

public class B {
	public void test2() {
		A obj = new A();
		//System.out.println(obj.v1);	//cannot be accesses as it is private
		//all below levels accessibility in same package
		System.out.println(obj.v2);
		System.out.println(obj.v3);
		System.out.println(obj.v4);
	}
}
