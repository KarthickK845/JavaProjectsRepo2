package pack1;

public class C extends A{
	//C is friendly sub class of A
	public void test6() {
		System.out.println(v1);
		System.out.println(v2);
		System.out.println(v3);
		System.out.println(v4);
	}
	
	public void test7() {
		A obj = new A();
		//System.out.println(obj.v1);
		System.out.println(obj.v2);		//since C is a friend of A
		System.out.println(obj.v3);
		System.out.println(obj.v4);
	}
}
