package pack3;

import pack1.A;
//import pack2.F;	//not accessible as it is default level
import pack2.D;
import pack2.E;

public class Main {

	public static void main(String[] args) {
		A obj = new A();
		obj.display();
	}

}
