package pack2;

import pack1.Circle;
import pack1.Employee;
import pack1.Manager;
import pack1.SalesEmployee;

public class Main2 {

	public static void main(String[] args) {
		byte b=90;
		int i = b;
		
		Employee emp = new Manager();
		
		Employee e;
		e=new Manager();	//Reference casting, Up casting
		//subclass object stored in superclass reference
		//Manager IS-A Employee (Relationship)
		
		e=new SalesEmployee();  //Reference casting, Up casting
		//advantage is we can have only one variable and store super class object itself or any of the sub class objects 
		//disadvantage is that we cannot access any subclass members
		
		Object obj;
		obj = new Employee();  //Reference casting, Up casting, implicit
		
		obj = new Manager();  //Reference casting, Up casting, implicit
		
		obj = new SalesEmployee();  //Reference casting, Up casting, implicit
		
		obj=new Circle();  //Reference casting, Up casting, implicit
		
		
	}

}
