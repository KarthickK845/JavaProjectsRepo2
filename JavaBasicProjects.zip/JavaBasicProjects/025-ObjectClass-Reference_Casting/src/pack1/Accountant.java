package pack1;

public class Accountant extends Employee{

	public boolean auditor;

	public boolean isAuditor() {	//as it is boolean variable, we get isAudible() instead of getAuditor()
		return auditor;
	}

	public void setAuditor(boolean auditor) {
		this.auditor = auditor;
	}
	
	
}
