package pack2;

import pack1.Student;

public class Main4 {

	public static void main(String[] args) {
		Student student=new Student(121, "Amrita", 95, 93);
		System.out.println(student);
		
		Student student1=new Student(121, "Ashok", 70, 60);
		System.out.println(student1);
		
		System.out.println(student.equals(student1));
	}

}
