package pack2;

import pack1.Circle;

public class Main1 {

	public static void main(String[] args) {
		int a=100;
		
		
		System.out.println(a);  //op 100
		
		Circle c1 = new Circle(10);
		Circle c2 = new Circle(10);
		
		System.out.println(c1);   //hash String output of object if we don't override toString()
		//Data in Circle is printed if we had overridden
		System.out.println(c1.toString());
		
		System.out.println(c1.equals(c2));
	}

}
