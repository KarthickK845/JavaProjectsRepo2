package pack2;

import pack1.Employee;

public class Main3 {

	public static void main(String[] args) {
		Employee employee=new Employee(101, "Karthi", 5000.00, 'A');
		
		//System.out.println(employee);
		Employee employee1=new Employee(102, "Karthi", 5000.00, 'A');
		System.out.println(employee.equals(employee1));
	}

}
