package pack2;

import pack1.Student;

public class Main8 {

	public static void main(String[] args) {
		Student st1 = new Student(121, "Ramu", 79, 77);
		Student st2 = new Student(122, "Renu", 79, 77);
		Student st3 = new Student(121, "Ramu", 79, 77);
		
		System.out.println(st1.equals(st2));
		System.out.println(st1.equals(st3));
		System.out.println(st2.equals(st3));
	}

}
