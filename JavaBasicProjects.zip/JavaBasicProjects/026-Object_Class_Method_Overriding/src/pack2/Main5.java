package pack2;

import pack1.Circle;
import pack1.Square;

public class Main5 {

	public static void main(String[] args) {
		int a=100;
		int b=100;
		System.out.println(a==b); //returns true
		
		Circle c1=new Circle(10);
		Circle c2=new Circle(10);
		System.out.println(c1==c2);  //returns false as both are different objects memory locations
		//use '==' for primitive and 'equals()' for Object references
		System.out.println(c1.equals(new Square(10)));   //designed for Object class not for Circle class, so it returns false
		System.out.println(c1.equals(c2));
		System.out.println(c1.hashCode());
		System.out.println(c2.hashCode());
	}

}
