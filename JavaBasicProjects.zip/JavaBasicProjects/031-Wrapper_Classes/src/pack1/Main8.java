package pack1;

public class Main8 {

	public static void main(String[] args) {
		//Auto Boxing, Auto Unboxing for a Double Type
		double y = 61.0;
		Double d = y;  //Auto Boxing
		
		double obj = d;  //Auto Unboxing
		
		System.out.println(obj);
		obj++;
		System.out.println(obj);
	}

}
