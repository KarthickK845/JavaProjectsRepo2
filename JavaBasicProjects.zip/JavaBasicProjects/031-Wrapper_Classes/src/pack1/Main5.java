package pack1;

public class Main5 {

	public static void main(String[] args) {
		// Float
		float f=2.0f;
		Float obj = Float.valueOf(f); //boxing
		
		byte v1=obj.byteValue();   
		System.out.println(v1);
		
		short v3 = obj.shortValue();  
		System.out.println(v3);
		
		int v2 = obj.intValue();
		System.out.println(v2);
		
		long v4 = obj.longValue();
		System.out.println(v4);
		
		float v5 = obj.floatValue();  //unboxing
		System.out.println(v5);
		
		double v6 = obj.doubleValue();
		System.out.println(v6);
		
		String str = "20.0f";
		float x = Float.parseFloat(str);
		System.out.println(++x);
		
		System.out.println(Float.MIN_VALUE);
		System.out.println(Float.MAX_VALUE);

	}

}
