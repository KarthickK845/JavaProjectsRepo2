package pack1;

public class Main7 {

	public static void main(String[] args) {
		Integer obj=Integer.valueOf(200);   //boxing

		int x=500;
		//Integer obj2 = Integer.valueOf(x);  //not required
		
		Integer obj1 = x;   //Auto Boxing, directly assign x to Integer, both are int and Integer so this is correct
		//cannot store double type into Integer
		
		int y=obj1; //auto unboxing
		
		System.out.println(obj1);
		obj1++;   //calls obj1.intValue() i.e. unboxing, then increment the extracted value, new Object... Integer.valueOf(incrementedData), obj1
		
		//object that was already in obj1 will be garbage collected, new incremented Object stored in obj1
		System.out.println(obj1);
	}

}
