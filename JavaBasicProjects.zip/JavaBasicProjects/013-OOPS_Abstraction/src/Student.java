
public class Student {
	String name;
	int mark1, mark2;
	
	int computeTotal() {
		return mark1+mark2;
	}
	
	int getAverage() {
		return computeTotal()/2;
	}
	
	char determineGrade() {
		int average=getAverage();
		if(average>=80)
			return 'A';
		else if(average>=60)
			return 'B';
		else if(average>=40)
			return 'C';
		else
			return 'D';
	}
}
