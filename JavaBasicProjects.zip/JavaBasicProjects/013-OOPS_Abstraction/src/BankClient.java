
public class BankClient {

	public static void main(String[] args) {
		BankAccount account=new BankAccount();
		System.out.println(account.balance);
		
		account.deposit(1000.0);
		account.deposit(200.0);
		account.deposit(400.0);
		
		//System.out.println(account.getBalance());
		account.printBalance();
		
		account.withdraw(500);
		account.printBalance();
	}

}
