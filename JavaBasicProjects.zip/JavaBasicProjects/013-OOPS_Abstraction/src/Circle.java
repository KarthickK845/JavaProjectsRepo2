
public class Circle {
	
	int radius;
	
	double computeArea() {
		double PI=3.14;
		double area=PI*radius*radius;
		return area;
	}
}
