
public class StudentClient {

	public static void main(String[] args) {
		Student s1=new Student();
		s1.name="Ashwin";
		s1.mark1=95;
		s1.mark2=97;
		System.out.println("Student1 : "+s1.name);
		System.out.println("TOTAL : "+s1.computeTotal()+", AVERAGE : "+s1.getAverage()+", GRADE : "+s1.determineGrade());
		
		Student s2=new Student();
		s2.name="Balaji";
		s2.mark1=74;
		s2.mark2=79;
		System.out.println("Student2 : "+s2.name);
		System.out.println("TOTAL : "+s2.computeTotal()+", AVERAGE : "+s2.getAverage()+", GRADE : "+s2.determineGrade());
	}

}
