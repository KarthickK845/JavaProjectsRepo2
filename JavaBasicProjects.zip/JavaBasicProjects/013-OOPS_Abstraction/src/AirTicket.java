
public class AirTicket {
	String name;
	int numberOfTickets;
	String destination;
	
	double calculateTicketPrice() {
		return 3000.0*numberOfTickets;
	}
	
	void printTicket() {
		System.out.println("-------- YOUR AIR TICKET --------");
		System.out.println("BOOKED UNDER: "+name);
		System.out.println("DESTINATION : "+ destination);
		System.out.println("TICKET PRICE: "+calculateTicketPrice());
	}
}
