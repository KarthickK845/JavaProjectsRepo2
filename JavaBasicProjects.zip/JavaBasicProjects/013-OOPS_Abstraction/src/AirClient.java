import java.util.Scanner;

public class AirClient {

	public static void main(String[] args) {
		AirTicket a1 = new AirTicket();
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter your name : ");
		a1.name=sc.nextLine();
		System.out.print("Enter your destination : ");
		a1.destination=sc.nextLine();
		System.out.print("Enter the number of tickets to book : ");
		a1.numberOfTickets=sc.nextInt();
		
		//a1.calculateTicketPrice();
		
		a1.printTicket();
	}

}
