package pack1;

public class C {

	//Constructor overloading
	public C() {
		System.out.println("C object created without arguments");
	}
	
	public C(int a) {
		System.out.println("C object created with 1 arguments "+a);
	}
	
	public C(int a, String b) {
		System.out.println("C object created with 2 arguments "+a+", "+b);
	}
	
	//private methods overloaded
	//parameter should change
	private void display() {
		System.out.println("Welcome");
	}

	private void display(String name) {
		System.out.println("Welcome " + name);
	}

	// static methods can be redefined
	// parameter should change
	//static method can be overloaded
	public static int getInfo(int id) {
		return id;
	}

	public static String getInfo(int id, String name) {
		return "ID : " + id + " NAME : " + name;
	}
	
	//static method overloaded as instance method
	public String getInfo(int id, String name, String address) {
		return "ID : " + id + " NAME : " + name+ " ADDRESS : "+address;
	}

	// return type may or may not be the same when overloading
	// parameter should change
	//function name is name
	//access level can change
	protected String sayHello() {
		return "Hello";
	}

	private void sayHello(String hello) {
		System.out.println(hello);
	}
	
	//instance method redefined as static
	public static void sayHello(String hello,String name) {
		System.out.println(hello+","+name);
	}
	
	//final methods can be overloaded
	public final void sayHi() {
		System.out.println("Hi");
	}
	
	public final void sayHi(String hi) {
		System.out.println("Hi");
	}
}
