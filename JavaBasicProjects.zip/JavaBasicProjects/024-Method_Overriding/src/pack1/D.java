package pack1;

public class D extends C{
	
	//Constructor cannot be overridden
	public C(int a) {
		System.out.println(" You cannot override constructor from super class");
	}
	
	public D() {
		System.out.println("D class constructor");
	}
	
	//redefined method from class D
	private void display() {
		System.out.println("class C method is redefined in class D");
	}
	
	//return type must be same for overriding
	//access level should be same or increased
	@Override
	public String sayHello() {
		return "Hello";
	}
	
	//static method cannot be redefined as instance method and vice versa
	public static void printID(int id)
	{
		System.out.println("ID : "+id);
	}
	
	public void printID(int id)
	{
		System.out.println("ID : "+id);
	}
	
	//static method cannot be overridden
	@Override
	public static void sayHello(String hello,String name) {
		System.out.println(hello+","+name);
	}
	
	//final method cannot be overridden
	@Override
	public final void sayHi() {
		System.out.println("Hi");
	}
}
