import java.util.Scanner;

public class Main4 {

	public static void main(String[] args) {
		//Menu display
		//1. Add Employee
		//2. Search Employee
		//3. Display All Employees
		//4. Delete An Employee
		//5. Exit
		
		int menuChoice;
		
		do
		{
			System.out.println("1. Add Employee");
			System.out.println("2. Search Employee");
			System.out.println("3. Display All Employees");
			System.out.println("4. Delete An Employee");
			System.out.println("5. Exit");
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter your choice");
			menuChoice = sc.nextInt();
			System.out.println(menuChoice);
		}while(menuChoice!=5);
	
	}

}
