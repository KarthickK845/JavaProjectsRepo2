
public class Main6 {

	public static void main(String[] args) {
		//multiples of 10 between 500 to 1000
		for(int num=500;num<1000;num++) {
			if(num%10==0)
			{
				System.out.println(num);
			}
		}
		
		System.out.println("----------------------------------");
		//multiples of 5 between 2000 to 1000
		for(int num1=2000;num1>=1000;num1--) {
			if(num1%5==0)
			{
				System.out.println(num1);
			}
		}
	}
}
