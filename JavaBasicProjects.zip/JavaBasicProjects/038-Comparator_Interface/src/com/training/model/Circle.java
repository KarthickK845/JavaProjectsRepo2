package com.training.model;

public class Circle {
	private int radius;

	public Circle(int radius) {
		super();
		this.radius = radius;
	}
	
	
}
