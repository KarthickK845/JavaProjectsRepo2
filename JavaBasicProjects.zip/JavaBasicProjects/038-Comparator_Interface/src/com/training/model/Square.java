package com.training.model;

public class Square {

	private int size;

	public Square(int size) {
		super();
		this.size = size;
	}
	
	
}
