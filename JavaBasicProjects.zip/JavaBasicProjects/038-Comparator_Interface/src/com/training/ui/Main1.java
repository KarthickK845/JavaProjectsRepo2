package com.training.ui;

public class Main1 {

	public static void main(String[] args) {
		

	}

}
