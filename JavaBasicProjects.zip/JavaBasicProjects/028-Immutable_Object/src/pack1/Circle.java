package pack1;

public class Circle {
	//immutable object class
	
	private final int radius;

	public Circle(int radius) {
		super();
		this.radius = radius;
	}

	public int getRadius() {
		return radius;
	}

	@Override
	public String toString() {
		return "Circle [radius=" + radius + ", getArea()=" + getArea() + "]";
	}

	public double getArea() {
		return 3.14*this.radius*this.radius;
	}
	
	public Circle enLarge(int byRadius) {
		Circle temp = new Circle(this.radius+byRadius);
		return temp;
	}
}
