package pack1;

public class Accountant extends Employee{
	boolean auditor;

	public Accountant(double basicSalary, boolean auditor) {
		super(basicSalary);
		this.auditor = auditor;
	}
	
	@Override
	public double computeNetSalary() {
		double net = super.computeNetSalary();
		if(auditor)
			net=net+10000.00;
		return net;
	}
	
	@Override
	public double computeNetSalary(int extraHours) {
		double net = super.computeNetSalary(extraHours);
		if(auditor)
			net=net+10000.00;
		return net;
	}
	
	@Override
	public double computeNetSalary(int extraHours, double perHourPayment) {
		double net = super.computeNetSalary(extraHours, perHourPayment);
		if(auditor)
			net=net+10000.00;
		return net;
	}

	@Override
	public String toString() {
		return "Accountant [auditor=" + auditor + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (auditor ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (!(obj instanceof Accountant))
			return false;
		Accountant other = (Accountant) obj;
		if (auditor != other.auditor)
			return false;
		return true;
	}
	
	
}
