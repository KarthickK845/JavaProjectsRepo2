package pack2;

import pack1.Employee;

public class Main1 {

	public static void main(String[] args) {
		Employee employee = new Employee(1000.00);
		//compile time polymorphism, static binding, early binding - all below
		System.out.println(employee.computeNetSalary());	
		System.out.println(employee.computeNetSalary(10));
		System.out.println(employee.computeNetSalary(10, 1000));

	}

}
