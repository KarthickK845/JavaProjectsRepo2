package pack1;

public abstract class A {
	public void test1() {
		System.out.println("A test1");
	}
	
	public final void test2() {   //final methods cannot be overridden
		System.out.println("A test2");
	}
	
	public abstract void test3();
}
