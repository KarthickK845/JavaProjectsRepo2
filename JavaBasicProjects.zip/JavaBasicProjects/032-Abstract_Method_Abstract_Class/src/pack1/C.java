package pack1;

public class C extends A{

	@Override
	public void test3() {
		System.out.println("C test3");
	}
	
	
}
