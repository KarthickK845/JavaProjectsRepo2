package pack2;

public class HomeLoan extends Loan{

	private String location;

	public HomeLoan(double loanAmount, int tenure, String customerName, String location) {
		super(loanAmount, tenure, customerName);
		this.location = location;
	}

	@Override
	public double getInterestRate() {
		return 0.11;
	}
	
	//if we miss to override the super class method getInterestRate(), it will take super class value
	//in order to force the user to override super class method
	
}
