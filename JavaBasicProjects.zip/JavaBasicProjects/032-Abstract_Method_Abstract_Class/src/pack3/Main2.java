package pack3;

import pack2.BusinessLoan;
import pack2.CarLoan;
import pack2.EducationLoan;
import pack2.HomeLoan;
import pack2.Loan;
import pack2.PersonalLoan;
import pack2.RetailBusinessLoan;
import pack2.WholeSaleBusinessLoan;

public class Main2 {
	public static void main(String[] args) {
		Loan loan;
		//loan  = new Loan(100000,12,"Ram");
		
		//System.out.println(loan.getInterestRate());
		
		loan=new CarLoan(100000,12,"Kiran","KL5");
		System.out.println(loan.getInterestRate());
		
		loan=new HomeLoan(100000,12,"Reshmi","Cochin");
		System.out.println(loan.getInterestRate());
		
		loan=new PersonalLoan(100000,12,"Ram",40000);
		System.out.println(loan.getInterestRate());
		
		loan=new EducationLoan(200000,12,"Karthi",48);
		System.out.println(loan.getInterestRate());
		
		System.out.println("------Business Loans-------");
		
		BusinessLoan loan1;
		loan1 = new RetailBusinessLoan(400000, 12, "Ramesh", "KST Company");
		System.out.println(loan1.getInterestRate());
		
		loan1 = new WholeSaleBusinessLoan(450000, 12, "Suresh", "ReadyGo Company");
		System.out.println(loan1.getInterestRate());
	}
}
