
public class CClient {

	public static void main(String[] args) {
		C.count=0;
		C.printCount();
		
		C obj=new C();
		obj.name = "Karthi";
		obj.printName();
		C.count++;
		C.printCount();
		
		C obj1 = new C();
		obj1.name = "Bala";
		obj1.printName();
		C.count++;
		C.printCount();
		
		C obj2 = new C();
		obj2.name = "Bhavya";
		obj2.printName();
		C.count++;
		C.printCount();
	}

}
