
public class BClient {

	public static void main(String[] args) {
		System.out.println(B.companyName);
		
		B obj = new B();
		obj.location="BLR";
		System.out.println(obj.location);
		
		B.greet();	//static method
		
		obj.goodbye();	//instance method
	}

}
