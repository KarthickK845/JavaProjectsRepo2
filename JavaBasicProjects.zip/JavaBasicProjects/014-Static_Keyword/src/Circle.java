
public class Circle {
	int radius;
	static double PI=3.14;
	
	double getArea() {
		//double PI = 3.14;		//each object will have this PI variable created, though it has same value
		//instead create as a single copy that can be accessed by all the objects
		double area=PI*radius*radius;
		return area;
	}
}
