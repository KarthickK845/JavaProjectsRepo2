
public class AClient {

	public static void main(String[] args) {
		
		
		A.welcome();
		
		A obj=new A();
		System.out.println(obj.x);
		obj.display1();
		//obj.welcome();	//not recommended to use object reference
	}

}
