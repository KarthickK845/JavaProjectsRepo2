
public class C {
	static int count=0;
	
	String name;
	
	static void printCount() {
		System.out.println("Number of objects "+ count);
	}
	
	void printName() {
		System.out.println(name);
	}
}
