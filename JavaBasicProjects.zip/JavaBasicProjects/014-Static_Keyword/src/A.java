
public class A {
	int x;
	static int y=90;
	
	void display1() {
		System.out.println(x);
		System.out.println(y);
	}
	
	static void welcome() {
		System.out.println("Welcome");
		System.out.println(y);   //accessing static variable is allowed
	}
}
