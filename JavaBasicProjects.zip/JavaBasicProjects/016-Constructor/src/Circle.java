
public class Circle {
	
	Circle(){
		//Constructor Method
		System.out.println("Circle Object Created");
	}
	//Constructor overloading
	Circle(int radius) {
		this.myRadius=radius;
		System.out.println("Circle object created with radius "+ radius);
	}
	
	private int myRadius;
	
	void setRadius(int r) {
		if(r<0) {
			System.out.println("Invalid Radius");
			return ;
		}
		myRadius=r;
	}
	
	int getRadius() {
		return myRadius;
	}
	
	double getArea() {
		return 3.14*myRadius*myRadius;
	}
}
