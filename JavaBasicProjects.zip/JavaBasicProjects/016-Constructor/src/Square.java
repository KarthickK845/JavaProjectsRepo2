
public class Square {
	private int size;
	
	Square() {
		System.out.println("Square Created");
	}
	
	Square(int size) {
		//this.size = size;
		//we can call the setter method here so we validate and set the value
		setSize(size);
		System.out.println("Square Created with size "+size);
	}
	
	void setSize(int size) {
		if(size<0) {
			System.out.println("Invalid data");
			return ; //to exit the method
		}
		this.size=size;
	}
	
	int getSize() {
		return this.size;
	}
}
