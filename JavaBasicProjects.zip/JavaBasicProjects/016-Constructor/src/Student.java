
public class Student {
	private int rollNumber;
	private String name;
	private int mark1,mark2;
	private String gender;
	
	Student() {
		System.out.println("Student Created No-arg");
	}
	
	Student(int rollNumber, String name, int mark1, int mark2, String gender) {
		setRollNumber(rollNumber);
		setName(name);
		setMark1(mark1);
		setMark2(mark2);
		setGender(gender);
	}



	//Task 1
	int getRollNumber() {
		return rollNumber;
	}
	void setRollNumber(int rollNumber) {
		if(rollNumber<=0) {
			System.out.println("Invalid Roll Number");
			return ;
		}
		this.rollNumber = rollNumber;
	}
	String getName() {
		return name;
	}
	void setName(String name) {
		if(name==null) {
			System.out.println("Invalid name");
			return ;
		}
		this.name = name;
	}
	int getMark1() {
		return mark1;
	}
	void setMark1(int mark1) {
		if(mark1<0 || mark1>100) {
			System.out.println("Invalid mark 1");
			return ;
		}
		this.mark1 = mark1;
	}
	int getMark2() {
		return mark2;
	}
	void setMark2(int mark2) {
		if(mark2<0 || mark2>100) {
			System.out.println("Invalid mark 2");
			return ;
		}
		this.mark2 = mark2;
	}
	String getGender() {
		return gender;
	}
	void setGender(String gender) {
		if(gender!="male" && gender!="female") {
			System.out.println("Invalid data for gender");
			return ;
		}
		this.gender = gender;
	}	
	
}
