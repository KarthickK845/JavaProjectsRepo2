
public class SquareClient {

	public static void main(String[] args) {
		Square s1 = new Square();
		s1.setSize(100);
		System.out.println(s1.getSize());
		
		Square s2 = new Square(300);
		//setter call not required
		System.out.println(s2.getSize());
	}

}
