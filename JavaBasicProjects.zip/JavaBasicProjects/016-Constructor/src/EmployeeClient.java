
public class EmployeeClient {

	public static void main(String[] args) {
		//create emp object using no-arg constructor
		// set and print the data
		
		Employee emp = new Employee();
		emp.setId(101);
		emp.setName("Roshan");
		emp.setCityName("Bangalore");
		emp.setBasic(10000.0);
		emp.setGrade('A');
		
		System.out.println("Employee ID : "+emp.getId());
		System.out.println("Employee Name : "+emp.getName());
		System.out.println("Employee City : "+emp.getCityName());
		System.out.println("Emp Basic : "+emp.getBasic());
		System.out.println("Emp Grade : "+emp.getGrade());
		
		System.out.println("------------------------------");
		System.out.println("Employee Created Parameterized");
		//create emp object using parameterized constructor
		// print the data
		
		Employee emp1 = new Employee(102, "Rakesh", "Mumbai", 20000.0, 'E');
		
		System.out.println("Employee ID : "+emp1.getId());
		System.out.println("Employee Name : "+emp1.getName());
		System.out.println("Employee City : "+emp1.getCityName());
		System.out.println("Emp Basic : "+emp1.getBasic());
		System.out.println("Emp Grade : "+emp1.getGrade());
	}

}
