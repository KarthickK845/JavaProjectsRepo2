
public class StudentClient {

	public static void main(String[] args) {
		Student s1 = new Student();
		s1.setRollNumber(151);
		s1.setName("Partha");
		s1.setMark1(95);
		s1.setMark2(97);
		s1.setGender("male");
		
		System.out.println("Student roll number : "+s1.getRollNumber());
		System.out.println("Student name : "+s1.getName());
		System.out.println("Student Mark 1 : "+s1.getMark1());
		System.out.println("Student Mark 2 : "+s1.getMark2());
		System.out.println("Student Gender : "+s1.getGender());
		
		System.out.println("------------------------");
		System.out.println("Student Created Parameterized");
		
		Student s2=new Student(161, "Saradha", 96, 93, "female");
		
		System.out.println("Student roll number : "+s2.getRollNumber());
		System.out.println("Student name : "+s2.getName());
		System.out.println("Student Mark 1 : "+s2.getMark1());
		System.out.println("Student Mark 2 : "+s2.getMark2());
		System.out.println("Student Gender : "+s2.getGender());
	}

}
