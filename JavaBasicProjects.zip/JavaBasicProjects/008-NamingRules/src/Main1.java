
public class Main1 {

	public static void main(String[] args) {
		int a = 0;
		System.out.println(a);
		
	
	}

}
